#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <ctype.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>

int parseCommand(char* line, char* words[]);

void runExit(char* words[], int count);

void runCd(char* words[], int count);

void runCommand(char* words[], int count);

int main(int argc, char *argv[]) {

    int active = 1;
    
    while(active) {

        // Terminal output
        printf("stash> ");

        char line[1026];

        // do this so the string will be terminated or run out of space
        for(int i = 0; i <= 1025; i++) {
            line[i] = '\0';
        }

        // // the final \n will not be in line[i], so the last word is already null terminated
        // scanf("%[^\n]", line);
        // while((getchar()) != '\n');

        // try fgets() instead
        fgets(line, 1025, stdin);

        // array of pointers for each word (null incicates the end of the words)
        char* words[513];
        for(int i = 0; i <= 512; i++) {
            words[i] = '\0';
        }

        int numWords = parseCommand(line, words);

        // check for built-in empty
        // nothing was entered
        if(numWords == 0) {
            // do nothing (reprompt)
        } else if(strcmp(words[0], "exit") == 0) {
            // check for built-in exit
            runExit(words, numWords);
        } else if(strcmp(words[0], "cd") == 0) {
            // check for built-in cd
            runCd(words, numWords);
        } else {
            runCommand(words, numWords);            
        }

    }

}

int parseCommand(char* line, char* words[]) {

    // counts the number of words
    int wordCounter = 0;

    // flag for looking for a character
    int lookingForChar;

    // flag for looking for whitespace
    int lookingForWhite;

    // can be any amount of white space at the beginning, are we looking for char or whitespace
    if(isspace(line[0])) {
        // need to find start of first word
        lookingForChar = 1;
        lookingForWhite = 0;
    } else {
        // need to find end of first word
        lookingForChar = 0;
        lookingForWhite = 1;
        // go ahead and set words[0] to point to input[0] and 
        words[0] = &line[0];
    }

    for(int i = 0; i <= 1023 && line[i] != '\0'; i++) {

        if(lookingForChar) {
            // need to find a character (aka not whitepsace)
            if(!isspace(line[i])) {
                // find first open space in term to store the word
                int count = 0;

                while(words[count] != '\0') {
                    count++;
                }

                // add pointer to word
                words[count] = &line[i];

                // now looking for terminating whitespace and say there is a possible word
                lookingForChar = 0;
                lookingForWhite = 1;

            }

        } else if(lookingForWhite) {
            // need to find whitespace (aka not character)

            if(isspace(line[i])) {
                // terminate the word
                line[i] = '\0';

                // increment word counter
                wordCounter++;

                // now looking for character
                lookingForChar = 1;
                lookingForWhite = 0;

            }


        }

    }

    // NOTE: this was needed for the scanf version of stash.c
    // since the implementation now uses fgets, all of this code in unnecessary
    // the problem was that wordCounter would not be incremented for the last word
    // read in by scanf because it would not include the '\n'
    // this created a big problem for entering 0 words that had to be addressed
    // since fgets includes the '\n', wordCounter increments as intended without these extra steps

    // increment wordCounter one more time because the last word is not terminated by the method
    // wordCounter++;

    // incrementing wordCounter has a flaw
    // wordCounter is 1 for both 0 and 1 words here because the last word (the first and only word)
    // is terminated by scanf()
    // so, the only way to tell if there is actually a word is to see if there are any
    // characters in line that are not '\0'

    // start by assuming there are actually zero words
    // int actuallyZero = 1;
    // for(int i = 0; i <= 1025; i++) {
    //     // if any character is not '\0', then there is at least 1 word
    //     if(line[i] != '\0') {
    //         actuallyZero = 0;
    //     }
    // }

    // if(actuallyZero == 1) {
    //     wordCounter = 0;
    // }

    return wordCounter;

}

void runExit(char* words[], int count) {

    if(count > 2 || count == 1) {
        // cannot have more than 2 arguments or exactly 1 for exit
        printf("Invalid command\n");
    } else {

        int exitNum = atoi(words[1]);

        // make sure all characters in words[1] are digits
        int allDigits = 1;

        int countForAllDigits = 0;

        while(words[1][countForAllDigits] != '\0') {

            if(!isdigit(words[1][countForAllDigits])) {
                allDigits = 0;
            }

            countForAllDigits++;

        }

        // // special case, atoi returns 0 if it failed, so to see if there was a failure
        // // or if the exit code was actually zero, we can hard compare the value of words[1] to "0"
        // if(exitNum == 0 && strcmp(words[1], "0") != 0) {
        //     printf("Invalid command\n");
        // } else {
        
        // not all numbers are digits, the argument is invalid
        if(!allDigits) {
            printf("Invalid command\n");
        } else {
            exit(exitNum);
        }

    }

}

void runCd(char* words[], int count) {

    if(count > 2) {
        // cannot have more than 2 arguments or exactly 1 for cd
        printf("Invalid command\n");
    } else {

        int chDirRet = chdir(words[1]);

        // a return value of -1 from chdir() means there was an error
        if(chDirRet == -1) {
            printf("Invalid command\n");
        }

    }

}

void runCommand(char* words[], int count) {

    // see if any child processes have finished
    pid_t finishedProcess = waitpid(-1 , NULL, WNOHANG);

    // given a child process has finished, see if there are any more than have finished
    while(finishedProcess > 0) {
        printf("[%d done]\n", finishedProcess);
        finishedProcess = waitpid(-1 , NULL, WNOHANG);
    }

    // flag to know if the command is a background command
    int isBackgroundCommand = 0;

    // determine if the command is a background command
    if(strcmp(words[count - 1], "&") == 0) {
        isBackgroundCommand = 1;
        // remove "&" from words
        words[count - 1] = '\0';
    }

    // we now have an external command
    pid_t pidChild = fork();

    // needs to be set to zero each time the method runs
    // if not if any excvp fails it will remain -1 and say there is an error
    int execvpError = 0;

    // work with the child
    if(pidChild == 0) {
        // if the child, execute the command
        execvpError = execvp(words[0], words);
    } else {
        // interactions with parent
        // wait if not background command
        if(!isBackgroundCommand) {
            // make the parent wait until the child is done processing
            wait(NULL);
        }
        
    }

    // an error has occured during execvp()
    if(execvpError == -1) {
        printf("Can't run command %s\n", words[0]);

        // end the child process with an error
        if(pidChild == 0) {
            exit(1);
        }

    }

    // print child pid if the command is a background command
    if(isBackgroundCommand) {
        printf("[%d]\n", pidChild);
    }

}
