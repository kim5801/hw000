 #include <sys/types.h>
 #include <sys/stat.h>
 #include <fcntl.h>
 #include <unistd.h>
 
 int main(int argc, char *argv[]) {

    char usage[] = "usage: exclude <input-file> <output-file> <line-number>\n";

    // used to calculate the size of the usage message for write
    int usageSize = 0;

    while(usage[usageSize] != '\0') {
        usageSize++;
    }

    // the arguments are invalid if there are not exactly 4 of them
    // name of program is the first argument so the size is one more than you would think
    if(argc != 4) {
        write(STDERR_FILENO, usage, usageSize);
        _exit(1);
    }

    char* in = argv[1];

    char* out = argv[2];

    char* num = argv[3];

    // used to keep track of where you are in the num array
    int numTrans = 0;

    while(num[numTrans] != '\0') {

        // if any of the characters are not decimal numbers 0-9 then the argument is invalid
        if((num[numTrans] - 48) < 0 || (num[numTrans] - 48) > 9) {
            // STDERR_FILENO = 2
            write(STDERR_FILENO, usage, usageSize);
            _exit(1);
        }

        numTrans++;

    }

    // open the input file
	int inputFile = open(in, O_RDONLY);

    // inputFile being -1 means there was an error opening it and therefore the argument is invalid
    if(inputFile == -1) {
        write(STDERR_FILENO, usage, usageSize);
        _exit(1);
    }

    // open the output file
    int outputFile = open(out, O_WRONLY | O_TRUNC, 0700);

    // outputFile being -1 means there was an error opening it and therefore the argument is invalid
    if(outputFile == -1) {
        write(STDERR_FILENO, usage, usageSize);
        _exit(1);
    }

    // Being converting string number to int
    // if line was empty, the length would be 0
    // if there was 1 character, len would be incremented once, then the while loop would terminate
    // etc.

    int len = 0;

    while(num[len] != '\0') {
        len++;
    }

    // base for creating the integer
    int numInt = 0;
    // will need to multiply by an additional power of 10 each time the loop executes
    int multi = 1;

    for(int i = len - 1; i >= 0; i--) {
        // ASCII values for decimals are 48 higher than their actual value
        numInt += (num[i] - 48) * multi;

        multi *= 10;
    }

    // numInt must be a positive integer
    if(numInt <= 0) {
        write(STDERR_FILENO, usage, usageSize);
        _exit(1);
    }

    char buff[64];

    // need to count how many times there is a new line so you know when to remove text
    int count = 0;

    // 1 if you are writing 0 if you are not writing
    int writing = 1;

    // before the loop check to see if the first line is the one being removed
    // if it is, writing needs to start as 0 (not writing) because you do not write until line 2
    if(numInt == 1) {
        writing = 0;
    }

    while(read(inputFile, buff, 64) > 0) {

        for(int i = 0; i < 64; i++) {

            // check if you are writing, and if you are do so
            if(writing) {
                if(buff[i] != '\0') {
                    write(outputFile, &buff[i], 1);
                }
            }

            // if the current character is \n increment the counter
            if(buff[i] == '\n') {
                count++;
            }

            // do not write if count == numInt (numInt is the line to be removed, this line starts after the line - 1 \n)
            if(count == numInt - 1) {
                writing = 0;
            }
            
            // resume writing
            if(count == numInt) {
                writing = 1;
            }

        }

        for(int j = 0; j < 64; j++) {
            buff[j] = '\0';
        }

    }

    // close inputFile
    close(inputFile);

    // close outputFile
    close(outputFile);

    _exit(0);
 
 }