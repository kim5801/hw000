/**
    A program that emulates shell commands using fork()
    @file stash.c
    @author Jaden Abrams (jlabrams)
*/

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>
#define MAX_CMD_LEN 1024
#define MAX_WORDS 513
/**
    Given a user command as input, add null termination between words,
    and fill the array that points to the start of each word.
    @param line the command from the user
    @param words where to put the location of each word
    @return the number of words in the line
*/
int parseCommand( char *line, char *words[] ) {
    //checks if the command is empty
    if( line[0] == '\n' ) {
        return 0;
    }
    int pos = 0;
    int wordct = 0;
    char fromCmd = line[0];
    // goes through the command and changes the spaces to null terminators
    while( fromCmd != '\n' ) {
        if( fromCmd == ' ' ) {
            line[pos] = '\0';
        }
        pos++;
        fromCmd = line[pos];
    }
    // resets trackers
    pos = 0;
    fromCmd = line[pos];
    // skip through blank space at the start of the command
    if( fromCmd != '\0' ) {
        words[wordct] = &(line[pos]);
        wordct++;
        pos++;
        fromCmd = line[pos];
    }
    // finds the words and filters out excess empty space in between arguments
    while( fromCmd != '\n' ) {
        if( fromCmd == '\0' && line[pos+1] != '\0' && line[pos + 1 ] != '\n' ) {
            words[wordct] = &( line[pos+1] );
            wordct++;
        }
        pos++;
        fromCmd = line[pos];
    }
    // replaces the end character with a null terminator
    if( line[pos] == '\n' ) {
        line[pos] = '\0';
    }
    return wordct;

}

/**
    Runs the exit command.
    @param words the words from the user
    @param count the number of words
*/
void runExit( char *words[], int count ) {
    // checks that we got the right amount of arguments
    if( count != 2 ) {
        printf("Invalid command\n");
    }
    else {
        // checks that we were given an actual integer
        int eStatus = 0;
        if( sscanf( words[1], "%d", &eStatus ) == 0 ) {
            printf("Invalid command\n");
        }
        else {
            exit(eStatus);
        }
    }
}

/**
    runs the cd command.
    @param words the words from the user
    @param count the number of words
*/
void runCd( char *words[], int count ) {
    // checks that we received the right amount of parameters
    if( count != 2 ) {
        printf("Invalid command\n");
    }
    // checks that the command was successful
    if( chdir(words[1]) == -1 ) {
        printf("Invalid command\n");
    }
}

/**
    runs non-built-in commands.
    @param words the words from the user
    @param count the number of words
*/
void runCommand( char *words[], int count ) {
    // forks the process and adds null to end of words array
    int childId = fork();
    words[count] = NULL;
    if( childId == 0 ) {
        // if we are the child, do the command and exit
        if( execvp( words[0], words ) == -1 ) {
            printf( "Can't run command %s\n", words[0] );
            exit(EXIT_FAILURE);
        }
    }
    else { // waits for the child to do its thing
        wait(&childId);
    }
}


/**
    The main function for operating the program
    @return the exit staus
*/
int main() {
    // initialize parameters
    char command[MAX_CMD_LEN] = "";
    int cmdlen = 0;
    char *words[MAX_WORDS];
    char fromCmd = '\0';
    while(1) {
        printf("stash> ");
        // get characters from the terminal and prevent buffer overflow
        while( fromCmd != '\n' && fromCmd != EOF && cmdlen < MAX_CMD_LEN ) {
            fromCmd = getchar();
            command[cmdlen] = fromCmd;
            cmdlen++;
        }
        // trips if there was an attempted overflow
        if( cmdlen == MAX_CMD_LEN && command[cmdlen - 1] != '\n' ) {
            cmdlen = 0;
            fromCmd = '\0';
            printf("Invalid command\n");
            continue;
        }
        int numwords = parseCommand( command, words );
        if(numwords != 0) {
            // use the first word to decide what to do
            if( !strcmp( "exit", words[0] ) ) {
                runExit( words, numwords );
            }
            else if( !strcmp( "cd", words[0] ) ) {
                runCd( words, numwords );
            }
            else {
                runCommand( words, numwords );
            }
        }
        // reset tracking variables
        cmdlen = 0;
        fromCmd = '\0';
    }
    exit(EXIT_SUCCESS);
}