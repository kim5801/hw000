/**
    Given a text file, create a new file with a specific
    line of text from the first removed.
    @file exclude.c
    @author Jaden Abrams (jlabrams)
*/

#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>

// the standard buffer size
#define BUF_SIZE 64
/**
    Convert a number expressed as a char to a number
    expressed as an integer
    @param ch the character to convert
    @return the corresponding integer
*/
int chToInt( char ch ) {
    int integer = ch - '0';
    if( integer > 9  || integer < 0 ) {
        return -1;
    }
    return integer;
}
/**
    Sends a custom error to the terminal and exits.
*/
static void usage() {
    char buffer[] = "usage: exclude <input-file> <output-file> <line-number>\n";
    //55 chars long
    write( STDERR_FILENO, buffer, 56 );
    _exit(1);
}

/**
    The method that controls the execution,
    verifies user input, and manipulates the files.
    @param argc the number of arguments passed to the program
    @param argv the arguments passed to the program
    @return exit status
*/
int main( int argc, char* argv[] ) {
    // checks that we received the right params
    if( argc != 4 ) {
        usage();
    }
    // reads the first number and sets up for the loop
    int pos = 0;
    int linenum = chToInt( argv[3][pos] );
    if( linenum == -1 ) {
        usage();
    }
    pos++;
    //convers the numbers in the loop until finished
    while( argv[3][pos] != '\0') {
        linenum = linenum * 10;
        int newnum = chToInt( argv[3][pos] );
        if( newnum == -1 ) {
            return 1;
        }
        linenum = linenum + newnum;
        pos++;
    }

    // opens up the files for reading and writing
    int input = open( argv[1], O_RDONLY );
    if( input == -1 ) {
        usage();
    }
    int output = open( argv[2], O_WRONLY|O_CREAT, 0600 );
    if( input == -1 ) {
        usage();
    }

    char buffer[BUF_SIZE];
    char outBuffer[BUF_SIZE];
    int outBufferSize;
    int foundEOF = 0;
    int currLine = 1;
    int charsRead = 0;
    // reads through the file until EOF is found
    while( !foundEOF ) {
        charsRead = read( input, buffer, BUF_SIZE );
        if( charsRead < BUF_SIZE ) {
            foundEOF = 1;
        }
        if( charsRead == -1 ) {
            return 1;
        }
        outBufferSize = 0;
        // goes through the bytes we took in and filters out the  line
        for( int i = 0; i < charsRead; i++ ){
            if( currLine != linenum ) {
                outBuffer[outBufferSize] = buffer[i];
                outBufferSize++;
            }
            if( buffer[i] == '\n' ) {
                currLine++;
            }
        }
        write( output, outBuffer, outBufferSize );
    }
    close(input);
    close(output);
    return 0;
}
