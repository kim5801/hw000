/**
 * @file stash.c
 * @author William Bishop
 * File for Q4 on HW0, shell program that prompts the user for commands
 */
//Necessary includes
#include <sys/wait.h>
#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>
#include <string.h>
#include <fcntl.h>

/** The correct number of argumenets for the runCD and runExit commands */
#define CORRECT_ARGS 2

/** The maximum number of chars allowed in a line */
#define MAXIMUM_CHARS 1024

/** The maximum number of strings allowed in a line */
#define MAXIMUM_STRINGS 513

/**
 * Starting point of the program.
 * @return EXIT_SUCCESS if successful, EXIT_FAILURE if not
 
int main()
{
  int count = 0;
  char character;
  int characterCount = 0;
  char *words[MAXIMUM_STRINGS];
  char userCommand[MAXIMUM_CHARS];

  while(1) {
    //Start the loop
    printf("stash> ");
    character = getchar();
    
    //Reset values
    characterCount = 0;
    count = 0;
       
    //Get all the characters from the line
    while (character != '\n') {
      //if the number of characters is too great, exit
      if (characterCount >= MAXIMUM_CHARS) invalidInput();
      
      //Add the character to the string
      userCommand[characterCount] = character;
      characterCount++;
      
      //Get the next character, and continue the loop
      character = getchar();
    }
    
    //If there was an empty line, just restart the loop
    if (characterCount == 0) continue;
  
    int count = parseCommand(userCommand, words);

    if (words[0] == "cd") runCd(words, count);
    else if (words[0] == "exit") runExit(words, count);
    else runCommand(words, count);

    for (int i = 0; i < characterCount; i++) {
      words[i] = NULL;
      comand[i] = '\0';
    }
  }
  return EXIT_SUCCESS;

}


 * Helper method to exit from an invalid input
 
static void invalidInput() 
{
  exit(EXIT_FAILURE);
}
*/

/**
 * Takes a user command as input, breaks the line into individual words and adds null termination
 * @param *line char pointer of the user's command line
 * @param *words the char array to put the user's words into
 * @return returns the number of words found in the line
 */
int parseCommand(char *line, char *words[])
{ 
  //Set the initial count of words
  int count = 0;
  
  //Set the initial skip of the words array to 0
  int isSkip = 0;


  //Iterate through a given line, stopping whenever we reach null
  for (int i = 0; line[i]; i++) {
    if (i == 0) {
      words[0] = line;
      count++;
    }
    
    //If we reach a space, we need to insert a null terminator
    if (line[i] == ' ') {
      line[i] = '\0';
      isSkip = 1;    
    }
    
    //Otherwise we need to skip to the next place for the word
    else if (isSkip) {
      words[count] = line + i;
      count++;
      isSkip = 0;
    }
  }

  //return our count of words
  return count;
}

/**
 * Function to exit from an invalid commands
 */
static void invalidCMD() {
  printf("Invalid command\n");
}

/*
 * Function to exit from an invalid runCommand
 * @param *words the command that was invalid
 */
void invalidCommand(char *words[])
{
  printf("Can't run command %s\n", words[0]);
}


/** 
 * Performs the built-in exit command
 * @param *words[] pointer to the words in the command
 * @param count the number of words in the array
 */
void runExit(char *words[], int count)
{
  //int status = atoi(words[1]);
  //Check to see if the correct number of words are used
  if (count != CORRECT_ARGS) invalidCMD();

  //Check for special case when exiting with 0, since atoi will return 0 on an error
  else if (!strcmp(words[1],"0")) exit(EXIT_SUCCESS);

  //Convert the string to an integer, exit if unsuccessful
  int status = atoi(words[1]);
  if (status == 0) invalidCMD();

  //Correctly exit the program with the given status
  else exit(status);

}

/**
 * Performs the built-in CD command
 * @param *words[] pointer to the words in the command
 * @param count the number of words in the array
 */
void runCd(char *words[], int count) 
{
  int check = chdir(words[1]);
  //Check if the correct number of words are used
  if (count != CORRECT_ARGS) invalidCMD();

  //Change the directory, check that it was successful
  //int check = chdir(words[1]);
  else if (check == -1) invalidCMD();
}


/** 
 * Runs a command by creating a child process
 * @param *words[] the pointer to the words in the command
 * @param count the number of words in the array
 */
void runCommand(char *words[], int count)
{
  int pid = fork();

  if (pid == 0) {
    //Need to add a null terminator at the end
    words[count] = NULL;

    //Call execvp, check to see if it was successful
    int process = execvp(words[0], words);
    if (process == -1) invalidCommand(words);
    exit(EXIT_SUCCESS);
  }
  wait(NULL);

}

/**
  * Starting point of the program.
  * @return EXIT_SUCCESS if successful, EXIT_FAILURE if not
  */
int main()
{ 

  //Create a count of words, the character, a count of the character, and necessary arrays
  char character;
  int characterCount = 0;
  char *words[MAXIMUM_STRINGS];
  char userCommand[MAXIMUM_CHARS];
  
  //Infinite loop used to continuously query the user
  while (1) {

    //Start the loop
    printf("stash> ");
    character = getchar();

    //Reset Arrays
    for (int i = 0; i < MAXIMUM_STRINGS; i++) {
      words[i] = NULL;
    }
    for (int i = 0; i < MAXIMUM_CHARS; i++) {
      userCommand[i] = '\0';
    }

    //Reset values
    characterCount = 0;
    
    
    //Get all the characters from the line
    while (character != '\n') {

      //if the number of characters is too great, exit
      if (characterCount >= MAXIMUM_CHARS) exit(EXIT_FAILURE);

      //Add the character to the string
      userCommand[characterCount] = character;
      characterCount++;

      //Get the next character, and continue the loop
      character = getchar();
    }

    //If there was an empty line, just restart the loop
    if (characterCount == 0) continue;
    int count = parseCommand(userCommand, words);
    
    //Run our functions, checking the words array to see which to call
    
    //if (words[0] == "cd") runCd(words, count);
    if (!strcmp(words[0], "cd")) runCd(words, count);

    //else if (words[0] == "exit") runExit(words, count);
    else if (!strcmp(words[0], "exit")) runExit(words, count);
    else runCommand(words, count);
  }

  //Return successfully
  return EXIT_SUCCESS;
}



