/**
 * @file exclude.c
 * @author William Bishop
 * File for Q3 on HW0, copies everything from an input file to an output, excluding a specified line
 */

//Include two necessary functions
#include <unistd.h>
#include <fcntl.h>

//Constant in order to return the argv of 3 back to the correct int, since it takes the ascii value of 3 instead of the actual int 3. No clue how else to do this
#define ZERO_ASCII 48

//The correct number of command line args
#define CORRECTARGS 4

//The number of arg that the int to tell which line to exclude should be 
#define INTARG 3

//The number of bytes in the buffer
#define BUFFER 64

//Constant to switch digits when converting the argument to an int
#define TEN 10

//Constant to use to create permissions
#define CREATEPERMISSIONS 0700  

/**
 * Function to exit if the command line arguments are invalid
 */
static void invalidArgs() 
{
  write(STDERR_FILENO, "usage: exclude <input-file> <output-file> <line-number>", BUFFER);
  _exit(1);
}


/**
 * Starting point of our program
 * @param argc the number of command line args
 * @param argv[] char arrays representing individual args
 * @return EXIT SUCCESS if successful, failure if not
 */
int main(int argc, char *argv[]) 
{ ;

  int count = 0;
  //checking for correct args
  if (argc != CORRECTARGS) invalidArgs();
  while(argv[INTARG][count]) count++;

  int decimalPlace = 1;
  int excludeLine = 0;
  //converting the number in argv to a usable int
  for (int i = count - 1; argv[INTARG][i]; i--) {
    if (argv[INTARG][i] <= '9' && argv[INTARG][i] >= '0') {
      excludeLine += (int)(argv[INTARG][i] - ZERO_ASCII) * decimalPlace;
      decimalPlace *= TEN;
    }
    else invalidArgs();
  }
  
  //open our file to read
  int readFD = open(argv[1], O_RDONLY);
  if (readFD == -1) invalidArgs();

  //open our file to write
  int writeFD = open(argv[2], O_WRONLY | O_CREAT, CREATEPERMISSIONS);
  if (writeFD == -1) invalidArgs();
  
  int currentLine = 0;
  int skipLine = 0;
  //int length = 1;
  /*
  int length = read(readFD, charBuffer, sizeof(charBuffer));
  do {
    int length = read(readFD, charBuffer, sizeof(charBuffer));
    if (length == -1) invalidArgs();
    for (int i = 0; i < length; i++) {
      if (charBuffer[i] == '\n') currentLine++;
      if (currentLine == excludeLine) skipLine = 1;
      if (skipLine == 1) {
        currentLine++;
        skipLine = 0;
      }
      else {
        write(writeFD, charBuffer + i, 1);
      }
    }
  }
  while (length > 0);
  */


  char charBuffer[BUFFER];

  int length = read(readFD, charBuffer, sizeof(charBuffer));
  if (length == -1) invalidArgs();
  
  //dowhile loop to get all the lines, and write them.
  do {
    for (int i = 0; i < length; i++) {
      
      //Skips the line if that line is coming next
      if (currentLine == excludeLine - 1) skipLine = 1;
      if (skipLine == 1) {
        if (charBuffer[i] == '\n') {
          currentLine++;
          skipLine = 0;
        }
      }
      else write(writeFD, charBuffer + i, 1);
    if (charBuffer[i] == '\n') currentLine++;
    }
    
    //re-read the chars into buffer
    length = read(readFD, charBuffer, sizeof(charBuffer));
  }
  while (length >= 1);
  
  //Close the file descriptors. 
  close(readFD);
  close(writeFD);

  return 0;

}
