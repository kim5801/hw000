#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>

void failed()
{
    char *msg = "usage: exclude <input-file> <output-file> <line-number>\n";
    write(STDERR_FILENO, msg, sizeof(msg) );
    _exit(1);
}

int toInt(char *str)
{
    int val = 0;
    for (int i = 0; str[i] != '\0'; i++ ) {
        val = val * 10 + str[i] - '0';
    }
    return val;
}

int main(int argc, char *argv[])
{
    // check validity of the last line command
    char *str = argv[3];
    int i = 0;
    while ( str != NULL && str != '\0' ) {
        if ( str[i] >= '0' && str[i] <= '9' )
            i++;
        else if ( str[i] == '\0')
            break;
        else
            failed();   
    }
    
    // open a file for reading and writing
    int fi = open( argv[1], O_RDONLY, 0600 );
    int fo = open( argv[2], O_WRONLY|O_CREAT|O_TRUNC, 0600 );
    if ( fi < 0 || fo < 0 || argc != 4 )
        failed();
        
    int lineCount = 0; // track the number lines read
    int lineNumEx = toInt(str);
    char buff[ 64 ];
    
    int len = read( fi, buff, sizeof( buff ) );
    while ( len > 0 ) { 
        for ( int i = 0; i < sizeof(buff); i++ ) {
            if ( buff[i] == '\n' ) {
                lineCount++; 
                break; 
            }
        }
        
        // make sure to overwrite file, O_TRUNC flag
         if ( lineCount != lineNumEx )
                write( fo, &buff, sizeof(buff));   
            
        // read up to 64 more bytes from the file
        len = read( fi, buff, sizeof( buff ) );
    }
    close( fi );
    close( fo );
    return 0;
}
