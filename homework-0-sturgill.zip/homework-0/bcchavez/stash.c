#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <ctype.h>
#include <unistd.h>

/*
    Takes user command (line) as input. Breaks the line into words, adds \0 terminator and
    fills in a pointer in the words array to point to the start of each word. 
    returns the number of words found in the line
*/
int parseCommand( char *line, char *words[] ) 
{
    int count = 0;
    int idx = 0; 
    line[sizeof(line)] = '\0';
      
    while ( line != '\0' ) { // while the line is not empty
        if ( line[idx] == '\0')
            break;
    
        // skip space
        while ( isspace( line[idx] ) && line[idx] != '\0') {
            idx++;
        }
       
        // check for non-whitespace chars
        while ( !isspace( line[idx] ) && line[idx] != '\0' ){
            idx++; 
        }    
        // space is found, replace with null terminator 
        line[idx] = '\0';
        count++;
        
        // restart with the next word in the list
    }
    
    // loop through the line to fill in words pointer. 
    for ( int i = 0; i < count; i++ ) {
        // find null terminator
        if ( i == 0 ) {
            *words[0] = line[0];
        }
        else {
            if ( line[i] == '\0' && i + 1 != count) {
                *words[i] = line[i + 1];
            }
        }
    }
    return count;
}

/*
    Performs built in exit command.
    @param words list of pointers to words in the user's command
    @param count number of words in the array
*/
void runExit( char *words[], int count )
{
    // check validity of status
    int status = atoi( words[1] );
    if ( count > 2 || status == 0 ) 
        printf("%s", "Invalid command\n");
    else
        exit( status );
}

/*
    Built in cd command. 
*/
void runCd( char *words[], int count ) 
{
    // pass argument to chdir() system call to change directory, return value is for validity
    if ( chdir( words[1] ) != 0 || count > 2 )
        printf("%s", "Invalid command\n"); 
}

/*
    Creates a child process and having it call execvp() to run the given command. 
*/
void runCommand( char *words[], int count )
{
    char **args = (char **)malloc(sizeof(char) * count + 1);
    memcpy(args, words, sizeof(char) * count + 1);
    args[count] = NULL;
    fork(); // create child process
    int status = execvp( words[0], words ); // runs different executable in child
    if ( status == -1 )
        printf("Can't run command %s", words[0] );
}

int main( int argc, char *argv[] )
{
    char *words[513];
    int count;
    char line[1024]; 
    while ( argv != NULL ) {
        printf("%s", "stash> ");
        scanf("%s", line);
        count = parseCommand( line, words ); // MNF
        // check first word in the list
        if ( strcmp( *words, "exit" ) == 0 ) {
            runExit( words, count );
        }
        else if ( strcmp( *words, "cd" ) == 0 ) {
            runCd( words, count );
        } 
        else if ( count > 0 )
            runCommand( words, count );
        // else empty line, just ignore and restart
    }
    return 0;
}
