/*
 * Reads a file and copies it to an output file
 * excludes given line number by user in output
 * @author Nolan Peters (ntpeter2)
 * @file exclude.c
 */
#include <unistd.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/stat.h>

/**
 * parses the given input as an integer if able to
 * @param input input to be parsed as int
 * @return value value of string as an int
 */
int parseValue(char* input)
{
    /** value currently read by program */
    int value = 0;
    
    /** char count */
    int count = 0;
    
    /** used to increase significance of numbers */
    int powerRaise = 10;
    
    int i = 0;
    
    /** counting the number of chars within input */
    while (input[i] != '\0') {
        count++;
        i++;
    }
    
    
    for (int j = 0; j < count; j++) {
        int actualVal = input[j] - '0';
        
        /** checking if values received is beteen 0 and 9, as each character should fall in that range when converted to int */
        if (actualVal < 0 || actualVal > 9) {
            write(STDERR_FILENO, "usage: exclude <input-file> <output-file> <line-number>\n", 60);
           _exit(1);
        }
        
        /** multiplying more significant numbers */
        for (int k = count - j - 1; k > 0; k--) {
            actualVal = actualVal * powerRaise;
        }
        value += actualVal;
    }

    return value;
}

/*
 * read in bytes from an input file and output them 
 * except for bytes in specified line
 *
 */
int main (int argc, char* argv[]) {
    if (argc != 4) {
        write(STDERR_FILENO, "usage: exclude <input-file> <output-file> <line-number>\n", 60);
        _exit(1);
    }
    int lineToSkip = parseValue(argv[3]);
    
    /** open input and output files */
    int inputFile = open(argv[1], O_RDONLY);
    
    int outputFile = open(argv[2], O_WRONLY | O_CREAT | O_TRUNC, 0600);
    
    /** an array to hold input of up to 64 bits */
    char inputArray[64];
    
    /** first round of bytes */
    int bytesRead = read(inputFile, &inputArray, 64);
    
    /** used to keep track of the line number while reading in bytes */
    int lineNum = 1;
    
    /** while there are still bytes to read... */
    while (bytesRead != 0) {
        for (int i = 0; i < bytesRead; i++) {
            //printf("%c\n", inputArray[i]);
            
            /** check for newline characters and omit as needed */
            if (inputArray[i] == '\n') {
               if (lineToSkip == 1 && lineNum == 1) {
                   lineNum++;
                   continue;
               }
                lineNum++;
            }
            
            /** assuming we aren't on the line to be skipped, write out the character to output */
            if (lineNum != lineToSkip) {
               write(outputFile, &inputArray[i], 1);
            } 
        }
        
        /** try to read in more bytes when done */
        bytesRead = read(inputFile, &inputArray, 64);
    }
    _exit(0);
}
