/**
 * this program serves as a mini-shell script that has
 * some built in commands. A new process will be ran to
 * execute commands not built-in
 * @file stash.c
 * @author Nolan Peters
 */
#include <stdio.h>
#include <stdlib.h>
#include "string.h"
#include <unistd.h>
#include <sys/types.h>
#include<sys/wait.h>

/**
 * parses command from the user
 * @param line line of input from user
 * @param words array to be filled with words from line input
 * @return number of words parsed and added to array
 */
int parseCommand(char *line, char *words[]) {

    char *delim = strtok (line, " ");
    
    int i = 0;
    
    while (delim != NULL) {
        words[i++] = delim;
        delim = strtok(NULL, " ");
    }
    int wordCount = 0;
    while (words[wordCount] != NULL) {
        wordCount++;
    }
    
    return wordCount;
}

/**
 * runs the exit command
 * @param words word array to be used in command
 * @param count number of words in array
 */
void runExit( char *words[], int count ) {

    if (count != 2) {
            printf("Invalid command\n");
            return;
        }
        int status = atoi(words[1]);
        
        exit(status);
}

/**
 * runs the cd command
 * @param words word array to be used in command
 * @param count number of words in array
 */
void runCd( char *words[], int count ) {
    if (count != 2 || chdir(words[1]) == -1) {
            printf("Invalid command\n");    
    }
}

/**
 * runs an external command
 * @param words word array to be used in command
 * @param count number of words in array
 */
void runCommand( char *words[], int count ) {
    pid_t pid = fork();
    if (pid == 0) {
        if (execvp(words[0], words) == -1) {
            printf("Can't run command %s\n", words[0]);
        }
        exit(1);
    } else {
        wait(NULL);
    }
}

/** reads in a line from a source
 * @param fp source of input
 * @return a buffer that contains the input
 * this function is made by me in the previous semester for 230
 */
char *readLine( FILE *fp ) {
  
  char ch = 0;
  int capacity = 10;
  int len = 0;
  char *word = (char *) malloc((capacity + 1) * sizeof(char));
  for (int i = 0; i < capacity + 1; i++){
      word[i] = '\0';
  }

  while ((ch = fgetc(fp)) != EOF && ch != '\n') {
    if (len >= capacity) {
        capacity *= 2;
        char *buffer2 =  (char *) malloc( (capacity + 1) * sizeof(char));
        for (int i = 0; i < capacity + 1; i++){
            buffer2[i] = '\0';
        }
        memcpy( buffer2, word, (len + 1) * sizeof( char ) );
        free(word);
        word = buffer2; 
        
    }
    word[len++] = ch;
  }
  if (len == 0 && ch == EOF) {
      free(word);
      return NULL;
  }
  if (len == 0 && ch == '\n') {
      word[0] = '\n';
  }

  return word;
}

/**
 * main driver for stash, takes in user input and passes it appropriately
 */
int main() {

    /** flag set to maintain loop while exit has not been called */
    int exitFlag = 0;
    
    /** keeps track of words in input */
    int wordCount = 0;
    do {
        //buffer for input
        char *input;
        //array of words that can be found from input
        char *words[1024];
        printf("stash> ");
        input = readLine(stdin);
    
        wordCount = parseCommand(input, words);
    
        //depending on the first word, call a particular function
        if (strcmp(words[0], "cd") == 0) {
            runCd(words, wordCount);
        }
    
        else if (strcmp(words[0], "exit") == 0) {
            runExit(words, wordCount);
        
        } else if (strcmp(input, "\n") != 0 && strcmp(input, "\r") != 0) {
            runCommand(words, wordCount);
        
        }
    
        // when done, free the input buffer and reset the word array to NULL
        free (input);
        int k = 0;
        while(words[k] != NULL) {
            words[k++] = NULL;
        }
    } while (exitFlag == 0);
}
