/**
  @file exclude.c
  @author Lane Nickson (ldnickso)
  Homework 1 Problem 3
*/

/** Headers to support system calls */
#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>

/** ASCII Value for 0 */
#define ASCII_ZERO 48
/** ASCII Value for 9 */
#define ASCII_NINE 57

/** Codes for program success/failure */
#define EXIT_FAILURE 0
#define EXIT_SUCCESS 1

#define MAX_READ_BYTES 64

/** Ends program execution with error.*/
void invalid();

/**
   Main function of the program.
   @param argc Number of arguments
   @param argv[] String array of arguments
   @return program exit status
 */
int main(int argc, char *argv[])
{
  // Check for invalid number of args
  if (argc != 4)
  {
    invalid();
  }

  // Open input file for reading (only)
  int fdr = open(argv[1], O_RDONLY);
  if (fdr == -1)
  {
    close(fdr);
    invalid();
  }

  // Open input file for writing (only)
  int fdw = open(argv[2], O_WRONLY | O_CREAT, S_IRWXU);
  if (fdw == -1)
  {
    close(fdr);
    close(fdw);
    invalid();
  }

  // Get length of the argument string
  int count = 0;
  while (argv[3][count++] != '\0')
    ;

  // Convert the arg to a number, fail if the arg is invalid
  int convertedNumber = 0;
  int tensPlace = 1;
  for (int i = (count - 2); i >= 0; i--)
  {
    // Check for invalid symbols
    if (argv[3][i] < ASCII_ZERO || argv[3][i] > ASCII_NINE)
    {
      close(fdr);
      close(fdw);
      invalid();
    }
    else
    {
      // Convert the string into an integer
      convertedNumber += (argv[3][i] - ASCII_ZERO) * tensPlace;
      tensPlace *= 10;
    }
  }

  char buffer[MAX_READ_BYTES];
  int currentLine = 1;
  int numRead = read(fdr, buffer, MAX_READ_BYTES);

  char bufferWithoutLine[MAX_READ_BYTES];

  // Read until end of file, write as the buffer fills up
  do
  {
    int withoutIndex = 0;
    // Take the buffer and put all but the removed line into bufferWithoutLine
    for (int i = 0; i < numRead; i++)
    {
      if (buffer[i] == '\n')
      {
        // Edge case where the first line's newline should not be saved
        if (convertedNumber == 1 && currentLine == 1)
        {
          i++;
        }
        currentLine++;
      }
      if (currentLine != convertedNumber)
      {
        bufferWithoutLine[withoutIndex++] = buffer[i];
      }
    }

    // Write the buffer with removed line
    write(fdw, bufferWithoutLine, withoutIndex);
    numRead = read(fdr, buffer, MAX_READ_BYTES);
  } while (numRead != 0);

  // Close file descriptors to prevent memory leakage
  close(fdr);
  close(fdw);
  _exit(EXIT_SUCCESS);
}

/**
   Ends program with generic usage message upon initilization error.
 */
void invalid()
{
  write(STDERR_FILENO, "usage: exclude <input-file> <output-file> <line-number>\n", sizeof("usage: exclude <input-file> <output-file> <line-number>\n"));
  _exit(EXIT_FAILURE);
}