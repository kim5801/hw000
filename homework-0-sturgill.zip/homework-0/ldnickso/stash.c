/**
  @file stash.c
  @author Lane Nickson (ldnickso)
  Homework 1 Problem 4
*/

/** C Standard Libraries */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>

/** System call includes */
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>

/** Stash prompt (displayed every command) */
#define PROMPT "stash> "

/** Maximum number of characters a command can be */
#define MAX_COMMAND_LENGTH 1024

/** Invalid Command Message */
#define STASH_INVALID "Invalid command"

/** Exit command */
#define STASH_EXIT "exit"

/** cd command */
#define STASH_CD "cd"

/** Newline character */
#define NEWLINE '\n'

/** Space character */
#define SPACE ' '

/** Null Terminator */
#define NULLTERM '\0'

/**
   Main function of the program.
   @param argc Number of arguments
   @param argv[] String array of arguments
   @return program exit status
 */
int main(int argc, char *argv[])
{
  bool isExitCommand = false;
  int exitStatus = EXIT_SUCCESS;

  //Main Loop
  while (!isExitCommand)
  {
    // Char array to store the entire line of input
    char command[MAX_COMMAND_LENGTH];
    // Array of char pointers to each word in command
    char *words[MAX_COMMAND_LENGTH];
    printf("%s", PROMPT);

    // Starting index when reading command
    int commandIndex = 0;
    // Current number of words
    int numWords = 0;

    //Get the first character in the command and mark it as a new word
    char current = getchar();
    bool newWord = true;

    // Read and parse the entire command
    if (current != NEWLINE && current != SPACE)
    {
      while (current != EOF && current != NEWLINE)
      {
        // Replace spaces with null terminators
        if (current == SPACE)
        {
          command[commandIndex++] = NULLTERM;
          newWord = true;
        }
        else
        {
          command[commandIndex] = current;
          // Add pointer to character if it is the start of a new word
          if (newWord)
          {
            words[numWords++] = &command[commandIndex];
            newWord = false;
          }
          commandIndex++;
        }

        current = getchar();

        // Add null terminator for edge case of last word
        if (current == EOF || current == NEWLINE)
        {
          command[commandIndex++] = NULLTERM;
        }
      }

      // // DEBUG
      // printf("COMMAND: %s\n", words[0]);
      // printf("ARGS: ");
      // for (int i = 1; i < numWords; i++)
      // {
      //   printf("-%s ", words[i]);
      // }
      // printf("\n");

      //"exit" command
      if (strcmp(words[0], STASH_EXIT) == 0 && numWords == 2)
      {
        int val;
        // Make sure that the argument is a valid number
        if (sscanf(words[1], "%d", &val) == 1)
        {
          isExitCommand = true;
          exitStatus = val;
        }
        else
        {
          printf("%s\n", STASH_INVALID);
        }
      }
      //"cd" command
      else if (strcmp(words[0], STASH_CD) == 0 && numWords == 2) {
        int validDir = chdir(words[1]);
        if(validDir == -1) {
          printf("%s\n", STASH_INVALID);
        }
      }
      // Fork anything else to another process (if it is a valid shell command/program)
      else if (strcmp(words[0], STASH_EXIT) != 0 && strcmp(words[0], STASH_CD) != 0)
      {
        //Add Null pointer to the end for execvp to recognize arguments
        words[numWords++] = NULL;

        // Make a child process
        pid_t id = fork();

        // ID error checking
        if (id == -1) {
          printf("%s\n", STASH_INVALID); 
        }
  
        // Child functionality
        if (id == 0)
        {
          int err = execvp(words[0], words);

          // If the command was in anyway invalid, exit the child
          if (err == -1) {
            printf("%s\n", STASH_INVALID);
            exit(EXIT_SUCCESS);
          }
        }
        else
        {
          // Wait for the child to finish.
          wait(NULL);
        }
      }
      else {
        printf("%s\n", STASH_INVALID);
      }

      
    }

    //Don't display the SHASH_INVALID message if there was no command entered, but display it if there's extra spaces
    else
    {
      // Show invalid input and clear out getchar past the newline return (if the command started with a space)
      if (current != NEWLINE)
      {
        printf("%s\n", STASH_INVALID);
      }
      while (current != NEWLINE)
      {
        current = getchar();
      }
    }
  }

  exit(exitStatus);
}
