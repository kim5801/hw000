#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <fcntl.h>

int main( int argc, char *argv[] ) {

  // Declaration of all the variables needed.
  // Using long for strlon purposes later on
  long excludeLine;
  char *filename;
  char *filename2;
  int fp;
  int fp2;
  

  // Checks to make sure that there are 4 arguments in the given line from the user
  if ( argc != 4 ) {
      write( 2, "usage: exclude <input-file> <output-file> <line-number>\n", 70 );
      _exit( EXIT_FAILURE );
  }

  // Loops through the arguments
  for (int i = 0; i < argc; i++) {

      // Checks the "first" argument, (past the ./exclude) to make sure that
      // the file is called input.txt
      if ( strcmp( argv[i], "1" ) == 0 ) {
          filename = argv[i];
          fp = open( filename, O_RDONLY );

          // Generic error check and message printout
          if ( fp < 0 ) {
              write( 2, "usage: exclude <input-file> <output-file> <line-number>\n", 70 );
              _exit( EXIT_FAILURE );
          }
      }

      // Checks the next argument for proper output.txt filename
      if ( strcmp( argv[i], "2" ) == 0 ) {
          filename2 = argv[i];
          fp2 = open( filename2, O_WRONLY | O_CREAT, 0600 );

          // Generic error check
          if ( fp < 0 ) {
              write( 2, "usage: exclude <input-file> <output-file> <line-number>\n", 70 );
              _exit( EXIT_FAILURE );
          }
      }

      // Checks the last argument to make sure that there is a number
      if ( strcmp( argv[i], "3" ) == 0 ) {

          // Converts the string to a long so that we can compare it to our counter later
          excludeLine = strtol( argv[i], NULL, 10 );
      }

  }

  // A count of how many null-terminated characters we have found
  long terminatedCount = 0;

  // Checks whether we have hit the line we need to exclude
  if ( terminatedCount == excludeLine ) {
      return EXIT_SUCCESS;
  }

  // Closes file
  close( fp );
  close( fp2 );

  return EXIT_SUCCESS;

}
