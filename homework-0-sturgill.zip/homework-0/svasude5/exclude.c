#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>

int convertToInt(char *val, int errSize, char *err) {
    
    char *curr = val;
    int mult = 1;
    while (*curr != '\0') {
        if (*curr < 48 || *curr > 57) {
            write(STDERR_FILENO, err, errSize);
            _exit(1);
        }
        mult *= 10;
        curr += 1;
    }
    mult /= 10;
    curr = val;
    int total = 0;
    while (mult != 0) {
        int value = *curr - 48;
        total += (mult * value);
        mult /= 10;
    }
    
    return total;
}

int main(int argc, char *argv[]) {
    char err[57] = "usage: exclude <input-file> <output-file> <line-number>\n";
    int errSize = 57;

    if (argc < 4) {
        write(STDERR_FILENO, err, errSize);
        _exit(1);
    }
    
    int input = open(argv[1], O_RDONLY);
    
    if (input == -1) {
        write(STDERR_FILENO, err, errSize);
        _exit(1);
    }
    
    int output = open(argv[2], O_WRONLY | O_CREAT | O_TRUNC, 0600);
    
    if (output == -1) {
        write(STDERR_FILENO, err, errSize);
        _exit(1);
    }
    
    int line = convertToInt(argv[3], errSize, err);

    char *curr = argv[3];
    int currLine = 1;
    while (read(input, curr, 1) != 0) {

        if (currLine != line) {
            write(output, curr, 1);
        }
        if (*curr == '\n') {
            currLine++;
        }
    }
    close(input);
    close(output);
    return 0;
}

