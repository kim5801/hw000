#include <sys/types.h>
#include <sys/stat.h>
#include <sys/wait.h>
#include <fcntl.h>
#include <unistd.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <ctype.h>
#include <stdbool.h>
#include <errno.h>

#define LINE_SIZE 1025

int parseCommand(char *line, char *words[]) {
    int count = 0;
    bool flag = false;
    
    int startWhitespace = 0;

    while (isspace(line[startWhitespace])) {
        startWhitespace++;
    }

    char *start = line + startWhitespace;
    for (int pos = startWhitespace; pos < LINE_SIZE; pos++) {
        if (isspace(line[pos])) {
            if (!flag) {
                line[pos] = '\0';
                words[count] = start;
                count++;
                flag = true;

            }
        } else {
            if (flag) {
                start = line + pos;
            }
            flag = false;
        }
    }
    return count;
}

void runExit(char *words[], int count) {
    if (count != 2) {
        printf("%s\n", "Invalid command");
        return;
    }

    for (int i = 0; words[1][i] != '\0'; i++) {
        if (!isdigit(words[1][i])) {
            printf("%s\n", "Invalid command");
            return;
        }
    }
    int code = atoi(words[1]);
    
    exit(code);
}

void runCd(char *words[], int count) {
    if (count != 2) {
        printf("%s\n", "Invalid command");
        return;
    }
    if (chdir(words[1]) == -1) {
        printf("%s\n", "Invalid command");
        return;
    }

}

void runCommand(char *words[], int count) {
    words[count] = NULL;
    if (fork() == 0) {
        execvp(words[0], words);
        exit(errno);
    } else {
        int exit;
        wait(&exit);
        if (exit != 0) {
            printf("%s%s\n", "Can't run command ", words[0]);
        }
    }
}


int main() {
    char prompt[8] = "stash> ";
    char *words[514] = {};
    int count = 0;

    printf("%s", prompt);

    char curr[LINE_SIZE] = {};
    fgets(curr, LINE_SIZE, stdin);
    while (curr != NULL) {
        count = parseCommand(curr, words);

        if (count > 0) {
            if (strcmp(words[0], "exit") == 0) {
                runExit(words, count);
            } else if (strcmp(words[0], "cd") == 0) {
                runCd(words, count);
            } else {
                runCommand(words, count);
            }
        } 
        printf("%s", prompt);
        
        fgets(curr, LINE_SIZE, stdin);
    }
    
    return EXIT_SUCCESS;
}