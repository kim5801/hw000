//C calls
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

//System calls
#include <sys/types.h>
#include <sys/wait.h>
#include <unistd.h>

//the size of a cmd + the string terminator
#define BUFFER 1025
//if every word was one character this is the max words possible
#define MAX_WORDS 513
//maximum amount of commands that can be run asynciously
#define MAX_ASYNC 512

/**
 * called when a command is invalid
 */
void invalidCommand() {
    printf("Invalid Command\n");
}


/**
 * Validates if a word is a positive number
 * @param  word the word to valide
 * @return      the number if it exists, -1 else
 */
int isNum( char *word ) {
    int ret = 0;
    for(int i = 0; word[i] != '\0'; i++) {
        if(isdigit(word[i])) {
            ret = ret * 10 + (word[i] - '0');
        } else {
            return -1;
        }
    }
    return ret;
}

/**
 * Take a command line as input and format words in the command
 * @param  line  the command to process
 * @param  words the words from the command
 * @return       the number of words
 */
int parseCommand( char *line, char *words[] ) {
    char w_in_mem = 0;
    int wordnum = 0;

    for(int i = 0; line[i] != '\0'; i++) {
        if(isspace(line[i])) {
            if(w_in_mem) {
                wordnum++;
            }
            w_in_mem = 0;
            line[i] = '\0';
        } else if(!w_in_mem) {
            words[wordnum] = (line + i);
            w_in_mem = 1;
        }
    }

    words[wordnum] = NULL;

    return wordnum;
}

/**
 * Handles the exit case
 * @param words the words in the command
 * @param count the number of words in the command
 */
void runExit( char *words[], int count ) {
    if(count == 2 && isNum(words[1]) != -1) {
        exit(isNum(words[1]));
    } else {
        invalidCommand();
    }
}

/**
 * run the change directory command
 * @param words the words in the command
 * @param count the number of words in command
 */
void runCd( char *words[], int count ) {
    if(count == 2) {
        if(chdir(words[1]) == 1) {
            invalidCommand();
        }
    } else {
        invalidCommand();
    }
}

/**
 * runs a command from the path
 * @param words the words in the command
 * @param count the number of words in command
 */
void runCommand( char *words[], int count ) {
    int child = fork();
    if(child == 0) { //child process
        int ret = execvp(words[0], words);
        if(ret == -1) {
            printf("Can’t run command %s\n", words[0]);
            exit(1); // have to exit or we get a shell in a shell, etc...
        }
    } else {
        waitpid(child,NULL,0);
    }
}

/**
 * runs a command but continues back to shell without waiting on command
 * @param  words      the words in the command
 * @param  count      the number of words in the command
 * @param  backlog    the backlog of current running children
 * @param  backlogLen the length of the backlog
 * @return            the new length of the backlog
 */
int runCommandAsync( char *words[], int count, int backlog[], int backlogLen) {
    if(backlogLen+1 >= MAX_ASYNC) {
        printf("Can’t run command %s, backlog full\n", words[0]);
        return backlogLen;
    }
    int childid = fork();
    if(childid == 0) { //child process
        int ret = execvp(words[0], words);
        if(ret == -1) {
            exit(127); // exit with 127 error, cmd not found
        }
    } else {
        printf("[%d]\n", childid);
        backlog[backlogLen] = childid;
        backlogLen++;
    }
    return backlogLen;
}


int main(int argc, char *argv[]) {
    int backlog[MAX_ASYNC] = {0};
    int backlogLen = 0;

    while(1) {
        //get user input for shell
        printf("stash> ");
        char cmd[BUFFER] = {0};

        fgets(cmd, BUFFER-1, stdin);
        //end

        //display tasks that have finished on backlog
        for(int i = 0; i < backlogLen; i++) {
            int status;

            if(waitpid(backlog[i],&status,WNOHANG) != 0) {
                printf("[%d done]\n", backlog[i]);
                for(int j = i; j < backlogLen; j++) {
                    backlog[j] = backlog[j+1];
                }
                backlog[backlogLen-1] = 0;
                backlogLen--;
                i--; //because we brought everything backwards we need to move index back as well
            }
        }

        //format input into words
        char *words[MAX_WORDS];

        int wordnum = parseCommand(cmd, words);

        //check words for keywords
        if(wordnum == 0) { //make sure we actually have commands
            continue;
        } else if(strcmp(words[0], "exit") == 0) {
            runExit(words, wordnum);
        } else if(strcmp(words[0], "cd") == 0) {
            runCd(words, wordnum);
        } else {
            if(strcmp(words[wordnum-1], "&") == 0) {
                words[wordnum-1] = NULL;
                backlogLen = runCommandAsync(words, wordnum, backlog, backlogLen);
            } else {
                runCommand(words, wordnum);
            }
        }
    }
}
