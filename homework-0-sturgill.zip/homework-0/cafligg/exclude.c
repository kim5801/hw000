#include <unistd.h>
#include <fcntl.h>
#include <stdio.h>
/**
 * function to control exits in error states
 */
void errorExit() {
    write(STDERR_FILENO, "usage: exclude <input-file> <output-file> <line-number>\n", 56);
    _exit(1);
}

/**
 * checks if a number is positive integer, if so return it. If it is not a positive number return -1
 * @param  a the string to convert
 * @return   the number from the string
 */
int numFromString(char *a) {
    int ret = 0;

    for(int i = 0; a[i] != '\0'; i++) {
        //if its not within the digit range its probably not a digit
        if(a[i] - '0' > 9 || a[i] - '0' < 0) {
            return -1;
        } else {
            ret = ret * 10 + a[i] - '0';
        }
    }

    return ret;
}


int main(int argc, char *argv[]) {
    if(argc != 4 || numFromString(argv[3]) < 0) {
        errorExit();
    } else {
        //get file descriptors
        int fp_read = open(argv[1], O_RDONLY);
        int fp_write = open(argv[2], O_WRONLY | O_CREAT, 0600);

        int num = numFromString(argv[3]) - 1; // because arrays start at 0 and lines start with 1

        //make sure both files opened correctly
        if(fp_read == -1 || fp_write == -1) {
            close(fp_read);
            close(fp_write);
            errorExit();
        }

        char act;
        int nL = 0;
        while(read(fp_read, &act, 1) != 0) {
            //if we are on newlines equal to argv[3] skip till new newline
            if(nL != num) {
                write(fp_write, &act, 1);
            }
            //check newlines
            if(act == '\n') {
                nL++;
            }

        }

        close(fp_read);
        close(fp_write);
    }
}
