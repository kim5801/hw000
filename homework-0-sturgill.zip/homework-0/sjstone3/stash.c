/**
  A program that prompts the user for commands
  @author sjstone3
*/

#include <ctype.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>

/** Maximum number of words that can be in the word array */
#define MAX_ELEMENTS 512

/** Maximum ammount of chars that can be on one line of stdin */
#define MAX_CHARS 1024

void invalid() {
  printf( "Invalid command\n" );
}

/**
  Takes a user command as input. 
  Breaks line into individual words and adds \0 at end of each word and fills in an array of word pointers
  @param line the user's command line input
  @param words array of each word from the cmd line
  @return number of words in the line
*/
int parseCommand( char *line, char *words[] ) {

  //if theres a newline character, no words in the line
  if( line[ 0 ] == '\n' ) {
    return 0;
  }

  int i = 0;  
  int numWords = 0;

  int firstChar = 0;
  
  //read until end of line is reached
  while( line[ i ] ) {
    //when there's a space, replace it with a null terminator
    //point the current word to the start of that word in the list
    //increment the word count and set the array number to the next word 
    if( isspace( line[ i ]  ) ) {
      line[ i ] = '\0';               
      words[numWords] = &line[ firstChar ];
      numWords++;
      firstChar = i + 1;
    }

    i++;
  }
  return numWords;
}

/**
  Performs the built-in exit command. 
  @param words list of pointers to words in users cmd
  @param count num words in the array
*/
void runExit( char *words[], int count ) {
  //incorrect number of arguments
  if( count != 2 ) { //exit status
    invalid();    
  } else {
    int status = atoi( words[ 1 ] );

    //if the status is not a valid int
    //atoi will return 0 if unsuccessful- so we must make sure the actual int isn't 0
    if( status == 0 && strcmp( words[ 1 ], "0" ) != 0 ) {
      invalid();    
    } else {
      //freeWords( words );
      exit( status );
    }
  }
}

/**
  Performs build-in cd cmd
*/
void runCd( char *words[], int count ) {
  //incorrect number of arguments
  if( count != 2 ) { //cd path
    invalid();  
  } else {
    char *path = words[ 1 ];
    int valid = chdir( path );
    //error for path
    if( valid == -1 ) {      
      invalid();
    }
  }
}

/**
  Runs a non-built-in cmd by creating a child process and having it call execvp() to run given cmd
*/
void runCommand( char *words[], int count ) {
  int id = fork();

  if( id == 0 ) { //child process
    //command line arguments
    //used as second param in execvp
    //last element should be a NULL pointer
    char *commands[ count + 1 ];
    for( int i = 0; i < count; i++ ) {
      commands[ i ] = ( char * )malloc( 1024 );
      strcpy( commands[ i ], words[ i ] );
    }
    commands[ count ] = NULL;

    execvp( words[ 0 ], commands );
    
    printf( "Can't run command %s\n", words[ 0 ] );
    exit( 0 );
    
  } else if( id != -1 ) { //parent process- wait for child to be done
    wait( NULL );
  } else {
    printf( "error using fork()\n" );
  }
  
}

int main( int argc, char *argv[] ) {
  char line[ MAX_CHARS ];  //max 1024 chars on a line
  char *words[ MAX_ELEMENTS ]; //max 512 elements  
 
  //loops until exit is called (handled in runExit function)
  while( 1 ) {
    printf( "stash> ");
    fgets( line, MAX_CHARS, stdin);

    //seperate line into individual word    
    int count = parseCommand( line, words );
    char *command = words[ 0 ];

    //match first word with a shell command
    if( strcmp( command, "cd" ) == 0 ) {
      runCd( words, count );
    } else if( strcmp( command, "exit" ) == 0 ) {
      runExit( words, count );
    } else if( count == 0 ) { //empty line, shell ignores it
      continue;
    } else {
      runCommand( words, count );
    }
  } 
  
}