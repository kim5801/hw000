/**
  A program that uses only system calls to copy everything from the input file to the output file except for the line that the user specifies.
  @author Sam Stone sjstone3
*/

#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>


/**
  Prints a usage error to stderr 
*/
void invalid() {
  char *errMsg = "usage: exclude <input-file> <output-file> <line-number>\n";
  int i = 0;
  //writes the error message one character at a time
  while( *( errMsg + i ) != '\0' ) {
    write( STDERR_FILENO, errMsg + i, 1 );
    i++;
  }  
  _exit( 1 );
}

/**
  Converts a string to its equivalent int value
*/
int convertToInt( char *string ) {
  int num = 0;   

  //cont number of digits
  int i = 0;
  char digit = string[ i ];
  while( digit ) {
    //only digits are allowed 
    if( digit > '9' || digit < '0' ) {
      invalid();
    }    
    i++;
    digit = string[ i ];
  }
  int numDigits = i;

  //loop through string to convert each digit to a number depending on its decimal place
  //start at leftmost digit
  i = 0;
  while( numDigits > 0 ) {
    //each digit must be muliplied to the power of its placement - 1
    // example: the 3 in 300 must be multiplied with 10^2
    int multiply = 1;
    for( int j = 1; j < numDigits; j++ ) {
      multiply *= 10;      
    }
    num += ( string[ i ] - '0' ) * multiply;

    //move to the next decimal place and decrement digits left
    i++;
    numDigits--;
  }

  return num; 
}

/**
  @param argc number of arguments
  @param argv  name of the input file, name of the output file, line of text that will be skipped (starting at 1)
  @return exit status
*/
int main( int argc, char *argv[] ) {
  //program should only have 4 arguments
  if( argc != 4 ) {
    invalid();
  } 

  //convert arg3 ( line number ) to an int
  //the line being skipped should be a positive integer
  char *stringSkip = argv[ 3 ];
  int skipLine = convertToInt( stringSkip );
  if( skipLine == 0 ) {
    invalid();
  }

  //open the file being read and file being written to
  int fdR = open( argv[ 1 ], O_RDONLY );
  int fdW = open( argv[ 2 ], O_WRONLY | O_CREAT, 0600 );

  //file couldn't be opened
  if( fdR < 0  || fdW < 0 ) {
    invalid();
  }

  //start reading the lines in 64 bytes
  //once no more chars are left, stop reading
  char buffer[ 64 ];
  int amtRead = 1;
  int currLine = 1;
  while( amtRead > 0 ) {
    amtRead = read( fdR, buffer, 64 );

    //print out each "chunks" of text byte by byte
    for( int i = 0; i < amtRead; i++ ) {   

      //write each byte as long as it isn't on the excluded line
      if( currLine != skipLine ) {
        write( fdW, buffer + i, 1 );
      }

      //when theres a new line, increament the current line the program's on
      if( *( buffer + i )  == '\n' ) {
        currLine++;
      }
    }
  }

  close( fdW );
  close( fdR );
  return 0;
}
