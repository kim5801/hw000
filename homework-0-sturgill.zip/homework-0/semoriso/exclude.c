#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>

/** Required # of arguments in command line */
#define ARG_VAL 4

/**
 Prints an error message based on invalid arguments and exits the program with a code of 1
 */
static void fail() {
  char str[] = "usage: exclude <input-file> <output-file> <line-number>\n";
  write(STDERR_FILENO, str, sizeof(str) - 1);
  _exit( 1 );
}

int main(int argc, char *argv[]) {
    //check for valid # of arguments first
    if (argc != ARG_VAL) {
        fail();
    }
    
    //try to open a file for reading
    int fd = open( argv[1], O_RDONLY );
    if ( fd < 0 ) {
        fail();
    }
    
    //try to open output file for writing
    int fo = open(argv[2], O_WRONLY | O_CREAT | O_TRUNC, 0600);
    if (fo < 0) {
        close(fd);
        fail();
    }
    
    //convert third arg to number
    int skipVal = 0;
    int count = 0; //keeps track of # of digits in string
    int numVal = 1; //initalize hundreds, tens, ones place
    char ch = *argv[3];
    if (ch == ' ' || ch == '\0') { //ensure the third argument has content
        close(fd);
        close(fo);
        fail();
    }
    while (ch != ' ' && ch != '\0') {
        if (ch < '0' || ch > '9') { //check to see if input contains a # or not
            close(fd);
            close(fo);
            fail();
        } 
        count++;
        ch = *(argv[3] + count); //iterate to next character in string
    }
    count--; //decrement to get back to last number, not space/null term
    
    for (int i = count; i >= 0; i--) { //add the number all together 
        skipVal += (*(argv[3] + i) - 48) * numVal; 
        numVal *= 10;
    }
    
    //read the file & store into array, keep track of where newlines occur for line count
    int lineCount = 1;
    char input[64]; //stores read call
    int readCount = read(fd, input, 64);    
    
    //write to output properly
    while (readCount != 0) { //ensure content was read
        for (int i = 0; i < readCount; i++) {
            if (input[i] == '\n') {
                lineCount++;
            }
            if (skipVal != lineCount) { //make sure line you're on is not line to be skipped
                write(fo, input + i, 1);   
            }
        }          
        readCount = read(fd, input, 64); //try to read in more input
    }
    
    //close all files before exiting 
    close(fd);
    close(fo);
    return 0;
}