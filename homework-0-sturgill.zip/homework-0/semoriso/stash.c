#include <string.h>
#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>
#include <ctype.h>
#include <sys/wait.h>

/** Command line capacity */
#define CAP 1025
/** The max # of words in pointer array */
#define WORD_COUNT 513

/**
 Reads in line of user input, processes into a string of length 1025, to account for null
 terminator.
 @param fp the file being read from (stdin)
 @return str the string processed from input
 */
char *readLine(FILE *fp)
{    
    char ch = fgetc(fp);
    if (ch == EOF || ch == '\n') {
        return NULL;
    }
    char *str = malloc(CAP * sizeof(char)); //allocates a string of size 1025
    int count = 0;
    while (ch != EOF && ch != '\n' && count != CAP) {  
        str[count] = ch;
        ch = fgetc(fp);
        count++; //increments # of letters in string
    }
    if (strlen(str) == 0) {
        free(str); //frees string if it was unused
        return NULL;
    }
    str[count] = '\0'; //add null terminator to end
    return str;
}

/**
 Takes a user command as input, breaks line into individual words, adds null terminators
 between words, fills in pointer in words array to point to start of each word
 @param line the user command to be parsed
 @param words the array to keep track of each word
 @return number of words found in the line
 */
int parseCommand(char *line, char *words[]) {
    if (!line) {
        return 0;
    }
    int count = 0; //number of words parsed
    int charCount = 0; //keeps track of where in line we are
    int nullCount = 0; //keeps track of where in individual word to place null term
    words[0] = line; //originally set up word pointer
    while (line[charCount] != '\n' && line[charCount] != EOF && line[charCount] != '\0') {
        if (isspace(line[charCount])) {
            words[count][nullCount] = '\0'; //set last val to null terminator
            words[++count] = line + charCount + 1;
            nullCount = 0;
            charCount++;
        }
        else {
            charCount++;
            nullCount++;
        }
    }
    //set last val to null terminator since while loop won't iterate again
    words[count][charCount] = '\0'; 
    count++;
    return count;
}

/** 
 Performs built-in exit command, exits with given exit status
 @param words the list of pointers to words in command
 @param count number of words in array
 */
void runExit(char *words[], int count) {
    if (count > 2 || count == 0) {
        printf("Invalid command\n");
        return;
    }
    //parse for exit status
    int status = 0;
    if (count != 1) {
        status = atoi(words[1]); 
    } 
    else if(count == 2 && !isdigit(*words[1])) { //check to see if second command is a #
        printf("Invalid command\n");
        return;
    }
    exit(status);
}

/**
 Performs built-in cd command
 @param words the list of pointers of words in command line
 @param count number of words in array
 */
void runCd(char *words[], int count) {
    if (count != 2) {
        printf("Invalid command\n");
        return;
    }
    if (chdir(words[1]) == -1) {
        printf("Invalid command\n");
    }  
} 

/**
 Runs a command by creating child process and having it call execvp to run given command
 @param words the list of pointers of words in command line
 @param count number of words in array
 */
void runCommand(char *words[], int count) {
    int id = fork();
    if (id == -1) {
        printf("Can't run command %s\n", words[0]);
        return;
    }
    if (id == 0) {
        words[count] = NULL;
        if (execvp(words[0], words) == -1) {
            printf("Can't run command %s\n", words[0]);
        }
        exit(EXIT_SUCCESS);
    }
    wait(NULL);
} 

/**
 Main function of stash, helps decide what command is being entered and calls the proper
 function to execute it.
 @return 0 if the program exits successfully
 */
int main() {
    char *words[WORD_COUNT]; //words array to parse lines into
    char *str; //command line to hold max #
    printf("stash> ");
    str = readLine(stdin);
    int num = parseCommand(str, words); //original parse of line
    while (!str) { //ensure we start longer while loop with a real command
        printf("stash> ");
        str = readLine(stdin);
        num = parseCommand(str, words);
    }
    while (strcmp(words[0], "exit") != 0) { //runs as long as user does not command exit
        if (strcmp(words[0], "cd") == 0) {
            if (num != 2) {
                printf("Invalid command\n");
            }
            else {
                printf("cd\n");
                runCd(words, num);
            }
        }
        else {
            runCommand(words, num);
        }
        free(str);
        printf("stash> ");
        str = readLine(stdin);
        num = parseCommand(str, words);
        while (!str) { //ensure we start longer while loop with a real command
        printf("stash> ");
            str = readLine(stdin);
            num = parseCommand(str, words);
        }
    } 
    runExit(words, num);
    return EXIT_SUCCESS;
}