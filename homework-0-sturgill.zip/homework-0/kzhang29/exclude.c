#include <fcntl.h>
#include <unistd.h>

//number of bytes we are reading at once
#define RBYTES 64

//exit success
#define EXIT_SUCCESS 0

/**
 * @author Kaijun Zhang
 * @brief Uses system calls to read a file 64 bytes at a time
 * and writes it to a file, omitting a specifified line
 * 
 * @param argc number of arguments passed in
 * @param argv the arguments passed in, input file, outputfile, line omitting
 * @return int 0 if succesful
 */
int main(int argc, char *argv[]) {
    int i = 0;
    //error if omit line is negative
    //error if inputfile error
    //error if less than 4 arguments in input
    char arr[] = {"usage: exclude <input-file> <output-file> <line-number>\n"};
    int pt1 = open(argv[1], O_RDONLY);
    int pt2 = open(argv[2], O_CREAT | O_WRONLY, 0600);
    if(argc != 4 || argv[3][0] == '-' || pt1 < 0 || pt2 < 0) {
        write(STDERR_FILENO, arr, sizeof(arr));
        _exit(1);
    }
    int omitLine = 0;
    while (argv[3][i]) {
        omitLine *= 10;
        char temp = argv[3][i];
        omitLine += (temp - '0');
        i++;
    }
    //reads the file in blocks of 64 bytes
    //and writes one byte at a time
    int curLine = 1;
    int rt = RBYTES;
    while(rt == RBYTES) {
        char buffer[RBYTES];
        rt = read(pt1, &buffer, RBYTES);
        i = 0;
        int j = 0;
        while (j < rt) {
            if(curLine != omitLine){
                char *ptt = &buffer[j];
                write(pt2, ptt, 1);
                i++;
            }
            if(buffer[j] == '\n') {
                curLine++;
            }
            j++;
        }
    }
    //closes the two file pointers
    close(pt1);
    close(pt2);
    _exit(EXIT_SUCCESS);
}