#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <sys/wait.h>
#include <sys/types.h>

//output for invalid commands
#define INCOMMAND "Invalid command"

//success exit
#define EXIT_SUCCESS 0

//success failure
#define EXIT_FAILURE 1

//max number of character in input
#define MAXINPUT 1024

/**
 * @brief This function takes a user command (line) as input. As described above it breaks the line into
 *individual words, adds null termination between the words so each word is a separate string, and
 *it fills in a pointer in the words array to point to the start of each word. It returns the number
 *of words found in the given line. The words array should be at least 513 elements in length, so it
 *has room for the largest possible number of words that could fit in a 1024-character input line.
 * 
 * @param line the user input that needs to be broken down
 * @param words pointer to a array of words
 * @return int number of words found in a line
 */
int parseCommand(char *line, char *words[]) 
{
    int numWords = 0;
    int numOnLine = 0;
    while(line[numOnLine] != ' ' && line[numOnLine] != '\n') {
        words[numWords] = &line[numOnLine];
        numWords++;
        while(line[numOnLine] != '\n' && line[numOnLine] != ' ') {
            numOnLine++;
        }
        while(line[numOnLine] == ' ') {
            line[numOnLine] = '\0';
            numOnLine++;
        }
    }
    line[numOnLine] = '\0';
    words[numWords] = NULL;
    return numWords;
}

/**
 * @brief This function performs the built-in exit command. The words array is the list of pointers to words
 * in the user’s command and count is the number of words in the array.
 * 
 * @param words list of pointers to words
 * @param count the number of words in the array
 */
void runExit(char *words[], int count) 
{
    if(count != 2) {
        printf("%s\n", INCOMMAND);
    } else {
        int num = 0;
        int i = 0;
        int isnegative = 0;
        char *woord = words[1];
        while (woord[i]) {
            if(i == 0 && woord[i] == '-') {
                isnegative = 1;
                i++;
            } else {
                if(woord[i] < '0' || woord[i] > '9') {
                    i = -1;
                    break;
                }
                num *= 10;
                char temp = woord[i];
                num += (temp - '0');
                i++;
            }
        }
        if(i < 0 || (i == 1 && isnegative)) {
            printf("%s\n", INCOMMAND);
        } else {
            if(isnegative) {
                num = num * -1;
            }
            printf("%d\n", num);
            exit(num);
        }
    }
}

/**
 * @brief This function performs the built-in cd command.
 * 
 * @param words list of pointers to words
 * @param count the number of words in the array
 */
void runCd(char *words[], int count)
{
    if(count != 2) {
        printf("%s\n", INCOMMAND);
    } else {
        int isSuc = chdir(words[1]);
        if(isSuc == -1) {
            printf("%s\n", INCOMMAND);
        }
    }
}

/**
 * @brief This function runs a (non-built-in) command by creating a child process and having it call execvp()
 * to run the given command.
 * 
 * @param words list of pointers to words
 * @param count the number of words in the array
 */
void runCommand(char *words[], int count)
{
    pid_t pid = fork();
    if(pid == 0) {
        int isError = execvp(words[0], words);
        if(isError == -1) {
            printf("%s%s\n", "Can't run command ", words[0]);
            exit(EXIT_FAILURE);
        } else {
            exit(EXIT_SUCCESS);
        }
    } else {
        wait(NULL);
    }
}

/**
 * @author Kaijun Zhang
 * @brief a shell program
 * 
 * @param argc number of input arguments
 * @param argv terminal user inputs
 * @return int 0 if successful
 */
int main(int argc, char *argv[]) 
{
    int isCont = 1;
    while(isCont == 1) {
        char *wordptrs[513];
        char line[MAXINPUT];
        printf("%s", "stash> ");
        fgets(line, MAXINPUT, stdin);
        int numWords = parseCommand(line, wordptrs);
        if(numWords == 0){
            continue;
        }
        if(strcmp(wordptrs[0], "cd") == 0){
            runCd(wordptrs, numWords);
        } else if(strcmp(wordptrs[0], "exit") == 0) {
            runExit(wordptrs, numWords);
        } else {
            runCommand(wordptrs, numWords);
        }
    }
    
    exit(EXIT_SUCCESS);
}
