/**
 * @author Author: zscummin (Zayda Cummings)
 * @date Date: September 3 2022
 *
 * The stash.c program is a part of homework 1 and is supposed to be a custom shell program.
  */
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <string.h>
#include <fcntl.h>

// Max line size
#define MAX_LINE_SIZE 1024

// Max word size
#define MAX_WORD_SIZE 513

/**
 * This function takes a user command (line) as input. As described above it breaks the line into
 * individual words, adds null termination between the words so each word is a separate string, and
 * it fills in a pointer in the words array to point to the start of each word
 */
int parseCommand( char *line, char *words[] ) {
  return 1;
}
/**
 * This function performs the built-in exit command. The words array is the list of pointers to
 * words in the user’s command and count is the number of words in the array.
 */
void runExit( char *words[], int count ) {
  exit(*words[0]);
}
/**
 * This function performs the built-in cd command. As with runExit(), the parameters give the words
 * in the command entered by the user.
 */
void runCd( char *words[], int count ) {
  chdir(*words);
}
/**
 * This function runs a (non-built-in) command by creating a child process and having it call
 * execvp() to run the given command.
 */
void runCommand( char *words[], int count ) {
  //Add content here
}

int main( int argc, char *argv[] ) {
  //Add content here
  char *line = " ";
  parseCommand(line, argv);
  return EXIT_SUCCESS;
}
