/**
 * @author Author: zscummin (Zayda Cummings)
 * @date Date: September 3 2022
 *
 * The job of the exclude.c program is to copy over everything from the input file to the output
 * file, excluding the line indicated by the number on the command line. Lines are numbered
 * countingfrom 1 (the first line of the input file)
  */
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <string.h>
#include <fcntl.h>

int MAX = 64;

/**
 * Prints out an error message and exit. Credit is to the example readFile.c in Moodle.
 * @param message failure message to send
 */
static void fail( char message[] ) {
  write(STDERR_FILENO, message, 60);
  _exit( 1 );
}

/**
 * Converts string representations of integers to decimals
 * Credit: https://stackoverflow.com/questions/35331740/string-to-int-without-atoi-isdigit
 * @param str pointer to a string representation of excluding line
 * @return integer representing the line to exclude from the output file
 */
int stringToDecimal(char *str) {
  // Initialize result
  int res = 0;
  //Error handling for invalid negative integers
  if (str[0] == '-') {
    fail("usage: exclude <input-file> <output-file> <line-number>\n");
  }

 // Iterate through all characters of input string and update result
  for (int i = 0; str[i] != '\0'; ++i) {
  if (str[i]> '9' || str[i]<'0') {
    return -1;
  }
  res = res*10 + str[i] - '0';
 }

 // return result.
 return res;
}

int main( int argc, char *argv[] ) {
  //Error handling for invalid arguments
  if (argc < 4) {
    fail("usage: exclude <input-file> <output-file> <line-number>\n");
  }
  //Line to delete indicated by command line
  int lineNum = stringToDecimal(argv[3]);
  //Opening input file for reading
  int fr = open(argv[1], O_RDONLY);
  if (fr < 0) {
    fail("Can't open input file for reading.\n");
  }
  //Opening output file for reading
  int fw = open(argv[2], O_WRONLY | O_CREAT, 0600);
  if ( fw < 0 ) {
    fail("Can't open output file for writing.\n");
  }
  //Making char buffer to read up to 64 bytes at a time from the file
  char buffer[MAX];
  int lineCount = 0;
  int len = read(fr, buffer, sizeof(buffer));
  //Reading until there is no more input
  while ( len > 0) {
    //Counting for every line there is
    for ( int i = 0; i < len; i++ ) {
      if (buffer[i] == '\n') {
        lineCount++;
      }
      //Excluding the line to delete
      if (lineCount != lineNum-1) {
        write(fw, &buffer[i], 1); //writing character by character to output
      }
    }
    //Read from the file again to continue until all of the file had been read
    len = read(fr, buffer, sizeof(buffer));
  }
  // Close the file and exit.
  close(fw);
  return EXIT_SUCCESS;
}
