/**
* @file exclude.c
* @author Finn Bacheldor
**/

#include <fcntl.h>
#include <unistd.h>

void wrongUsage();
int strToInt(char * str);

/**
* Main, removes a line from an input then puts it in output.
**/
int main(int argc, char * argv[]) {
   //Make sure we have the correct number of args
   if(argc != 5) {
      wrongUsage();
   }
   //Try to open the given files
   int fileIn = open(argv[1], O_RDONLY);
   int fileOut = open(argv[2], O_CREAT | O_WRONLY | O_TRUNC, 0600);
   //Check if the files were opened
   if(fileIn == -1 || fileOut == -1) {
      wrongUsage();
   }
   //Determine what line to removes from arguments
   int lineToRemove = strToInt(argv[3]);
   if(lineToRemove < 1) {
      wrongUsage();
   }
   //Read in 20 chars at a time
   char buffer[20];
   int charsRead = read(fileIn, buffer, sizeof(buffer));
   char bufferOut[20];
   int newlinesRead = 1;
   do {
      for(int i = 0; i < charsRead; i++) {
         //Read one char at a time from the buffer
         //If its a newline, increment newline counter
         //If the number of newlines equals the line to remove, skip over chars in that line
         //charsOut keeps track of where in the out buffer we should be writing chars, if we skip over some
         int charsOut = 0;
         if(newlinesRead != lineToRemove) {
            bufferOut[charsOut] = buffer[i];
            charsOut++;
         }
         if(buffer[i] == '\n') {
            newlinesRead++;
         }
         write(fileOut, bufferOut, charsOut);
      } 
   } while((charsRead = read(fileIn, buffer, sizeof(buffer))));
}


/**
* Converts a string to an integer
* @param str String to convert
* @return the integer from the string
**/
int strToInt(char * str) {
   int out = 0;
   //While there is still a character left, increment the pointer
   while(*str) {
      out *= 10;
      //Add that character to the 1s place of out
      if(*str < '0' || *str > '9') {
         wrongUsage();
      }
      out += *str - '0';
      str++;
   }
   return out;
}

/**
* Prints the wrong usage message for the exclude command
**/
void wrongUsage() {
   //Write usage messge to stdout, for when the user uses the command wrong.
   write(0, "usage: exclude <input-file> <output-file> <line-number>\n", 56);
   _exit(1);
}
