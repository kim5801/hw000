/**
* @file stash.c
* @author Finn Bacheldor
**/

#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/wait.h>

#define MAX_INPUT 1024
#define MAX_WORDS MAX_INPUT / 2 + 1
#define NULL_TERMINATOR '\0'

int parseCommand( char *line, char *words[] );
void runExit( char *words[], int count );
void runCd( char *words[], int count );
void runCommand( char *words[], int count );
char *readLine();

/**
* Main, reads in and runs commands
**/
int main( int argc, char * argv[] ) {
   char *line;
   char *words[MAX_WORDS];
   int charCount = 0;
   //Repeat until exit
   while( true ) {
      printf("stash> ");
      //Read a full line
      line = readLine();
      if(line == NULL) {
         continue;
      }
      charCount = strlen(line);
      //Make sure the line length is in bounds
      if(charCount > MAX_INPUT) {
         printf("Invalid command\n");
         free(line);
         continue;
      }
      if(!charCount) {
         free(line);
         continue;
      }
      //Break into words
      int wordCount = parseCommand(line, words);
      if(!wordCount) {
         free(line);
         continue;
      }
      //Determine command to use
      if(!strcmp(words[0], "cd")) {
         runCd( words, wordCount );
      }
      else if(!strcmp(words[0], "exit")) {
         runExit( words, wordCount );
      }
      else {
         runCommand( words, wordCount );
      }
      free(line);
   }
}

/**
* Splits a string into words by the spaces
* @param line String to divide
* @param words Output of words in the string
* @return number of words found
**/
int parseCommand( char *line, char *words[] ) {
   int ahead = 0;
   int word = 0;
   bool sawSpace = false;
   //Make sure line is a valid pointer
   if(line == NULL) {
      return 0;
   }
   if(*line != ' ') {
      words[0] = line;
      word++;
   }
   //Until a null terminator is hit
   while(*(line + ahead)) {
      //Skip over spaces
      if(*(line + ahead) == ' ') {
         ahead++;
         sawSpace = true;
      }
      else {
         //Set last space in a string of spaces to a null terminator
         if(sawSpace) {
            *line = NULL_TERMINATOR;
            line++;
            ahead--;
            sawSpace = false;
            words[word] = line;
            word++;
         }
         //Grab next non space character
         *line = *(line + ahead);
         line++;
      }
   }
   *line = NULL_TERMINATOR;
   return word;
}

/**
* Exits with the exit code of the second word
* @param words Words for the command
* @param count Number of words
**/
void runExit( char *words[], int count ) {
   //Check for correct number of arguments
   if(count != 2) {
      printf("Invalid command\n");
      return;
   }
   else {
      //Exit with given code
      int eCode = atoi(words[1]);
      exit(eCode);
   }
}

/**
* Changes the working directory to the second word
* @param words Words for the command
* @param count Number of words
**/
void runCd( char *words[], int count ) {
   //Check for correct number of arguments
   if(count != 2) {
      printf("Invalid command\n");
      return;
   }
   else {
      //Change working directory
      int found = chdir(words[1]);
      if(found) {
         printf("Invalid command\n");
         return;
      }
   }
}

/**
* Runs a provided command
* @param words Words for the command
* @param count Number of words
**/
void runCommand( char *words[], int count ) {
   //Create child process
   int forkResult = fork();
   if(forkResult == -1) {
      fprintf(stderr, "Could not create new thread\n");
      exit(1);
   }
   //If i'm the child process, run given command
   if(forkResult == 0) {
      words[count] = NULL;
      int error = execvp(words[0], words);
      if(error) {
         printf("Invalid command\n");
         exit(1);
      }
      exit(0);
   }
   //otherwise wait for child to finish
   else {
      wait(NULL);
   }
}

/**
* Reads a line from stdin
* @return String read from stdin until a newline is reached
**/
char *readLine() {
   int size = MAX_INPUT + 1;
   char *line = malloc( size );
   char read;
   int i = 0;
   //Read chars until the end
   while ( fscanf( stdin, "%c", &read) != EOF && read != '\n' ) {
      line[i++] = read;
      //Realloc if run out of room
      if( i + 1 > size ) {
         size *= 2;
         line = realloc( line, size );
      }
   }
   line[i] = NULL_TERMINATOR;
   if ( i == 0 ) {
      free( line );
      line = NULL;
   }
   return line;
}
