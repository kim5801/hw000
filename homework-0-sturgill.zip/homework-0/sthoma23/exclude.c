/**
* This program will accept a text file and produce 
* a text file output that excludes specified line
* of text from the input
*
* @file exclude.c
* @author Seth Thomas sthoma23
*/
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>

/** Number of bytes in buffer */
#define BUFLEN 64

/** Number of arguments in command line */
#define NUMARGS 4

/** Index of input file name in argv */
#define INPUT_IDX 1

/** Index of output file name in argv */
#define OUTPUT_IDX 2

/** Index of line number string in argv */
#define LINE_NUM_IDX 3

/** Radix/base for decimal numbers */
#define BASE_TEN 10

/**
* Handles the error message for invalid 
* command line input when starting the program
*/
void invalidArg() 
{
    char *err = "usage: exclude <input-file> <output-file> <line-number>\n";
    int len = 0;
    while ( err[ len ] ) {
        len++;
    }
    write( STDERR_FILENO, err, len );
    _exit( 1 );
}

/**
* Calculates the product of one integer raised 
* to the power of another integer
*
* @param base integer being multiplied x times
* @param exp exponent which base will be raised to
* @return product of the calculation
*/
int power( int base, int exp )
{
    int product = 1;
    for ( int i = 1; i <= exp; i++ ) {
        product = product * base;
    }
    return product;
}

/**
* Interpret strings from command line arguments
* for an integer value; convert string to int

* @param str string containing an integer value
* @return integer produced from string
*/
int parseAsInt( char *str )
{
    //Get the length of the string
    int len = 0;
    while ( str[ len ] ) {
        len++;
    }

    int digits[ len ];
    int sum = 0;

    for ( int i = 0; i < len; i++ ) {

        //Check for valid input
        if ( str[ i ] < '0' || str[ i ] > '9' ) {
            //Invalid
            invalidArg();
        }

        //Add digit to the array
        digits[ i ] = str[ i ] - '0';
    }

    //Combine all digits
    for ( int i = 0; i < len ; i++ ) {
        sum += digits[ len - 1 - i ] * power( BASE_TEN, i );
    }

    return sum;
}

/**
* Receives command line arguments and accesses
* input text file to write edited text to an 
* output
* 
* @param argc number of command line arguments
* @param argv array of each command line argument
* @return 0 to indicate program success
*/
int main( int argc, char *argv[] ) 
{
    //Verify correct number of args
    if ( argc < NUMARGS ) {
        invalidArg();
    }

    char *input = argv[ INPUT_IDX ];
    char *output = argv[ OUTPUT_IDX ];
    int lineNum = parseAsInt( argv[ LINE_NUM_IDX ] );

    //Open input file to read from
    // int in = open( input, O_RDONLY, 0600 );
    int in = open( input, O_RDONLY );
    if ( in < 0 ) {
        //Invalid
        invalidArg();
    }

    //Open output file to write to
    int out = open( output, O_WRONLY | O_CREAT, 0600 );
    if ( out < 0 ) {
        //Invalid
        close( in );
        invalidArg();
    }

    //Buffer to hold 64 bytes at a time
    char buf[ BUFLEN ]; 
    int len = 0;
    int lineCount = 1;

    //Read input file until all bytes have been read
    while ( ( len = read( in, buf, BUFLEN ) ) ) {

        //Array to hold the edited text
        char line[ len ];
        int idx = 0;

        for ( int i = 0; i < len; i++ ) {

            //Skip all text on specified line
            if ( lineCount != lineNum ) { 

                //Copy over the text from buf
                line[ idx++ ] = buf[ i ];
                if ( buf[ i ] == '\n' ) {

                    //Increment for each newline
                    lineCount++;
                }
            }
            else if ( buf[ i ] == '\n' ) {

                //Increment for each newline
                lineCount++;
            }
        }
        
        //Write to the output file
        write( out, line, idx );

    }

    //Close the opened files
    close( in );
    close( out );

    //End program
    return 0;
}