/**
  Program for managing processes and mimicking terminal behavior 
  by parsing commands from standard input and executing the appropriate
  action 

  @file stash.c
  @author Seth Thomas sthoma23
*/
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>

/** Max number of characters in a command */
#define MAX_ARG_LENGTH 1024

/** Number of words in a command */
#define MIN_WORDS 513

/** Number of arguments for built-in commands */
#define NUM_PARAMS 2

/**
* Handles error message output for built-in command
* error messages
*
*/
void invalid()
{
    char *errMsg = "Invalid command\n";
    fwrite( errMsg, strlen( errMsg ), 1, stdout );
} 

/**
* Splits line of input into individual arguments
* and assigns each string to an index in the words[]
* array 
*
* @param line user input/command line form stdin
* @param words empty array of char pointers
*/
int parseCommand( char *line, char *words[] )
{

    //Split line up by whitespace
    char *wordbuf = strtok( line, " \n" );

    int idx = 0;

    //Iterate through line with a buffer
    while ( wordbuf != NULL ) {

        //Copy from buffer to words
        words[ idx++ ] = wordbuf;
        wordbuf = strtok( NULL, " \n" ); 
    }

    //Return number of elements assigned to words
    return idx;
}

/**
* Handles "exit" command by calling exit() with
* the exit status provided in the second argument
* of the command
*
* @param words array of words from the command line
* @param count number of words in the words array
*/
void runExit( char *words[], int count ) 
{
    if ( count <= NUM_PARAMS ) {

        int status = 0;

        //Exit "0" without error status
        if ( count == 1 ) {
            exit( status );
        }

        //Check for valid exit status (an integer)
        int matches = sscanf( words[ 1 ], "%d", &status );

        //Exit with provided error status
        if ( matches == 1 ) {
            exit( status ); 
        }
    }

    //Invalid command line arguments
    invalid();
}

/**
* Handles "cd" command by calling chdir() with
* the second argument of the command
*
* @param words array of words from the command line
* @param count number of words in the words array
*/
void runCd( char *words[], int count )
{
    //Verify correct usage and attempt to change directory
    if ( count != NUM_PARAMS || ( chdir( words[ 1 ] ) < 0 ) ) {

        //Invalid command line arguments
        invalid();
    } 
}

/**
* Handles external commands by starting a child process 
* and having it call execvp() to delegate the command
*
* @param words array of words from the command line
* @param count number of words in the words array
*/
void runCommand( char *words[], int count )
{
    //Create child
    pid_t pid = fork();

    //Null terminate the words array
    words[ count ] = NULL;

    //Is child
    if ( pid == 0 ) {

        //Delegate external command to execvp()
        execvp( words[ 0 ], words );

        //Return from execvp() only upon error
        char errMsg[] = "Can't run command ";
        fwrite( errMsg, strlen( errMsg ), 1, stdout );
        fwrite( words[ 0 ], strlen( words[ 0 ] ), 1, stdout );
        fwrite( "\n", sizeof( char ), 1, stdout );
    }

    //Is parent
    else {
        //Wait for child
        wait( NULL );
    }
}

/**
* Handles user interface in a terminal format.
* Prompts user for commands, delegates to other functions,
* and repeats until user wishes to exit
*
* @return EXIT_SUCCESS
*/
int main() 
{
    //Allocate enough memory for input and words
    char *input = ( char * ) malloc( MAX_ARG_LENGTH * sizeof( char ) );
    char **words = ( char ** ) malloc( MIN_WORDS * sizeof( char * ) );

    //Prompt user for command
    printf( "stash> " );
    
    while ( fgets( input, MAX_ARG_LENGTH, stdin ) ) {

        //Parse the command line into separate arguments
        int argNum = parseCommand( input, words );

        //Empty command
        if ( words[ 0 ] == NULL || strcmp( words[ 0 ], "" ) == 0 ) {
            //Ignore and do nothing
        }

        //cd function
        else if ( strcmp( words[ 0 ], "cd" ) == 0 ) { 
            runCd( words, argNum );            
        }

        //Exit command
        else if ( strcmp( words[ 0 ], "exit" ) == 0 ) { 

            runExit( words, argNum );
        }

        //External command
        else {
            runCommand( words, argNum );
        }

        //Prompt user for another command
        printf( "stash> " );

        //Empty the command string and array of arguments
        free( input );
        free( words );
        input = ( char * ) malloc( MAX_ARG_LENGTH * sizeof( char ) );
        words = ( char ** ) malloc( MIN_WORDS * sizeof( char * ) );
    }

    //Free the allocated memory
    free( input );
    free( words );

    return EXIT_SUCCESS;
}
