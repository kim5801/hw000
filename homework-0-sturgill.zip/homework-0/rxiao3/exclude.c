/**
 * @file exclude.c
 * @author Rose Xiao
 * @date 2022-08-26
 *
 * @copyright Copyright (c) 2022
 */


#include <fcntl.h> //to utilize the open()
#include <sys/types.h>
#include <sys/stat.h>

#include <unistd.h> //to utilize the close() & lseek()
#define BYTE_CT 64
#define ARG_CT 4
#define DEC_BASE 10
#define ASCII_INT_MIN 48
#define ASCII_INT_MAX 57

 //Printing out the message if the files do not exist
static void errorFunc( int fileIn, int fileOut )
{
	// write( 2, msg, sizeof( msg ) );
	write( STDERR_FILENO, "usage: exclude <input-file> <output-file> <line-number>\n", 56 );
	close( fileIn );
	close( fileOut );
	_exit( -1 ); 	 //Unix system exit call 
}
int main( int argc, char* argv [ ] )
{

	//if the user did not passed the appropriate number of arguments
	if ( argc != ARG_CT ) {
		write( STDERR_FILENO, "usage: exclude <input-file> <output-file> <line-number>\n", 56 );
	}
	//opens the file to read lines from
	int input = open( argv [ 1 ], O_RDONLY );

	//opens the file to write to
	int output = open( argv [ 2 ], O_WRONLY | O_APPEND );
	if ( !input || !output ) {
		errorFunc( input, output );
	}

	//retrieve the integer value passed by the user
	int number = 0;
	//check if the last argument passed was an integer
	for ( int i = 0; i < argv [ 3 ][ i ]; i++ ) {
		if ( argv [ 3 ][ i ] < ASCII_INT_MIN || argv [ 3 ][ i ] > ASCII_INT_MAX ) {
			errorFunc( input, output );
		}
		else {
			//converts the vale from ASCII to decimal
			//First subtract by the lowest value and multiply by the base value
			number = number * DEC_BASE + ( argv [ 3 ][ i ] - ASCII_INT_MIN );
		}
	}

	//write an error if the arg passed was a negative value
	if ( ( number * -1 ) > 0 ) {
		errorFunc( input, output );
	}

	//read in char by 64 byte chunks
	char buffer [ BYTE_CT ];

	//counter to keep track of which line we are on by counting the number of new line terminators read in
	int newLine = 1;
	int bufferLen = 0;
	while ( ( bufferLen = read( input, buffer, BYTE_CT ) ) ) { //while there is still something to read
		//examine each char
		for ( int i = 0; i < bufferLen; i++ ) {
			//if char is '\n' then increment the new line counter
			if ( buffer [ i ] == '\n' ) {
				newLine++;
				//edge case for if the arg passed is 1 in order to account for the fact that line 1 does not start with the new line terminator
				if ( number == 1 && newLine -1 == number ) {
					continue;
				}
			}

			//to not write out the chars
			if ( ( newLine ) == number ) {
				continue;
			}
			//write out the chars
			write( output, buffer + i, 1 );

		}

	}
	//close the two file descriptors
	close( input );
	close( output );
	return 0;

}