
/**
 * @file stash.c
 * @author Rose Xiao
* @date 2022-08-26

 */

 //need to convert string to int by doing ASCII to dec
#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <string.h>
#include <ctype.h>

#include <fcntl.h> //to utilize the open()
#include <sys/types.h>
#include <sys/stat.h>
#include <unistd.h> //to utilize the close() & lseek()
#include <sys/wait.h>

#define MAX_CMD_CHAR 1024
#define MIN_WORDS 513
#define REQ_CT 2
#define CMP_CD 2
#define CMP_EXIT 4

//printing out fail msgs
static void fail( char* msg )
{
	printf( "Error: %s\n", msg );
	exit( EXIT_FAILURE );
}


/**
 * @brief Will break the line into words by adding null terminators between the words. It fills in a pointer to the words array to point to the start of each word. It returns the number of words it parsed.
The words array should be at least 513 elements in length, so it
has room for the largest possible number of words that could fit in a 1024-character input line.
 *
 * @param line
 * @param words
 * @return int
 */
static int parseCommand( char* line, char* words [ ] )
{
	int numWords = 0;
	//checks if we are on the first letter of a word
	bool startLetter = true;
	int j = 0;
	int len = strlen( line );
	for ( int i = 0; i < len; i++ ) {
		if ( startLetter && !isspace( line [ i ] ) ) { //if it's the start of the letter,, add a pointer
			startLetter = false;
			words [ j ] = &line [ i ]; //sets pointer to letter
			j++;
			numWords++;
		}
		if ( !startLetter && isspace( line [ i ] ) ) { //if it reaches the end of the word
			line [ i ] = '\0';
			startLetter = true;
		}

	}
	return numWords;

}

/**
 * @brief Will terminate the shell with the given integer value as its exit status. If given an invalid number of arguments or an invalid value,, the program will print out an error message to standard output
 *
 * @param words the line containing the commands
 * @param count the number of words in the input line
 */
static void runExit( char* words [ ], int count )
{
	int value = -1;
	int result = sscanf( words [ 1 ], "%d", &value );
	if ( result != 1 || count != REQ_CT ) {
		printf( "Invalid command\n" );
	}
	else {
		exit( value );
	}

}

/**
 * @brief Will run the change directroy system call and the return value of chdir() will tell you if the directory was valid.
 * If given an invalid number of arguments or an invalid value,, the program will print out an error message to standard output.
 *
  * @param words the line containing the commands
 * @param count the number of words in the input line
 */
static void runCd( char* words [ ], int count )
{
	int result = chdir( words [ 1 ] );
	if ( result < 0 || count != REQ_CT ) {
		printf( "Invalid command\n" );
	}
}

/**
 * @brief This function runs a (non-built-in) command by creating a child process and having it call execvp()
to run the given command.
 *
* @param words the line containing the commands
 * @param count the number of words in the input line
 */
static void runCommand( char* words [ ], int count )
{
	//run the external commands
	int pid = fork();
	if ( pid == -1 ) {
		fail( "Can't create child process" );
	}
	//if the child,, run the execvp cmd
	if ( pid == 0 ) {
		//to set NULL as the last thing to indicate how many parameters were passed. We minused one since the param might be starting at 1 instead of 0
		words [ count ] = NULL;

		// Calling the execvp() system call
		int result = execvp( words [ 0 ], words );
		//if the sys call was unsuccessful
		if ( result == -1 ) {
			printf( "Can't run command %s\n", words [ 0 ] );
			exit( 1 );
		}
		exit( EXIT_SUCCESS );

	}
	else {
		//parent waits for the child to terminate
		wait( NULL );
	}
}

/**
 * @brief  It is a shell program that will prompt the user to type in commands and will call the functions accordingly.
 *
 * @return int the exit status
 */
int main( int argc, char* argv [ ] )
{
	char str [ MAX_CMD_CHAR ];
	bool quit = false;
	while ( !quit ) {
		//allocating space for line read in
		char* line = ( char* )malloc( strlen( str ) * sizeof( char ) );
		char* words [ MIN_WORDS ];
		//print out prompt
		printf( "stash> " );
		//get the user input
		fgets( str, sizeof( str ), stdin );
		//returns the count of the words read
		int count = parseCommand( str, words );

		//if user's input was empty,, reprompt the user
		if ( count == 0 ) {
			free( line );
			continue;
		}
		//runs the built-in command for cd
		if ( strncmp( words [ 0 ], "cd", CMP_CD ) == 0 ) {
			runCd( words, count );
		}
		//runs the built-in command for exit
		else if ( strncmp( words [ 0 ], "exit", CMP_EXIT ) == 0 ) {
			runExit( words, count );
		}

		// //if the '&' is present which indicates the parent should not wait for child to terminate.
		// //for the extra credit
		// //Bug: after running the first cmd with '&',, the program does not seem to wait when running the command w/o the '&'
		// else if ( ( strncmp( words [ count - 1 ], "&", 1 ) == 0 ) ) {
		// 	int pid = fork();
		// 	if ( pid == -1 ) {
		// 		fail( "Can't create child process" );
		// 	}
		// 	//if the child,, run the execvp cmd
		// 	if ( pid == 0 ) {
		// 		//to set NULL as the last thing to indicate how many parameters were passed. We minused one since the param might be starting at 1 instead of 0
		// 		words [ count - 1 ] = NULL;

		// 		// Calling the execvp() system call
		// 		int result = execvp( words [ 0 ], words );
		// 		//if the sys call was unsuccessful
		// 		if ( result == -1 ) {
		// 			printf( "Can't run command %s", words [ 0 ] );
		// 			exit( 1 );
		// 		}
		// 		exit( EXIT_SUCCESS );
		// 	}
		// 	// printf( "here\n" );
		// }


		//running the built-in cmds with execvp()
		else {
			runCommand( words, count );
		}
		//frees the malloced line
		free( line );
	}

	return EXIT_SUCCESS;
}
