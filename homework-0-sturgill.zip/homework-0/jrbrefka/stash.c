/**
  @file stash.c
  @author Joey Brefka (jrbrefka)
  A command line interface name stash
*/

#include <stdio.h>
#include <ctype.h>
#include <string.h>
#include <unistd.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/wait.h>

/** The max line length for commands*/
#define MAX_LINE_SIZE 1025

/** The max necessary length of the words array*/
#define MAX_WORDS_LENGTH 513

/**
  Takes a command as input and breaks it into individual words, adding null termination
  between words.
  @param line for the line being parsed
  @param words holds the words in the line
  @return the number of words found
*/
int parseCommand( char *line, char *words[] )
{
  int idx = 0;
  int wordidx = 0;
  int isStart = 1;
  for (int i = 0; line[ i ]; i++ ) {
    if ( isStart && !isspace( line[ i ] ) ) {
      words[ idx++ ] = &line[ i ];
      isStart = 0;
    }
    if ( isspace( line[ i ] ) ) {
      line[ i ] = '\0';
      isStart = 1;
      wordidx = -1;
    }
    wordidx++;
  }
  return idx;
}

/**
  Performs the built-in exit command.
  @param words for the list of words
  @param count is the length of the list of words
*/
void runExit(char *words[], int count)
{
  if ( count < 2 || count > 2 ) {
    printf( "Invalid command\n" );
  } else {
    int exitInt = atoi( words[ 1 ] );
    if ( exitInt == 0 ) {
      printf( "Invalid command\n" );
    } else {
      exit( exitInt );
    }
  }
}

/**
  Performs the built-in cd command.
  @param words for the list of words
  @param count is the length of the list of words
*/
void runCd(char *words[], int count)
{
  if ( count < 2 || count > 2 ) {
    printf( "Invalid command\n" );
  } else {
    if ( chdir( words[ 1 ] ) == -1 ) {
      printf( "Invalid command\n" );
    }
  }
}

/**
  Performs a command by creating a child process and having it call execvp().
  @param words for the list of words
  @param count is the length of the list of words
*/
void runCommand(char *words[], int count)
{
  int pid = fork();
  words[ count ] = NULL;
  if ( pid == 0 ) {
    if ( execvp( words[ 0 ], words ) == -1 ) {
      printf( "Can't run command %s\n", words[ 0 ] );
      exit( 0 );
    }
  } 
  wait( 0 );
}

/**
  Main function of the program.
  @return the exit status
  @param argc for the number of command line arguments
  @param argv for the command line arguments
*/
int main(int argc, char *argv[]) 
{ 
  while ( 1 ) {
    char line[MAX_LINE_SIZE];
    char *words[MAX_WORDS_LENGTH];
    printf( "stash> " );
    fgets( line, sizeof( line ), stdin );
    int count = parseCommand( line, words );
    if ( strcmp( words[ 0 ], "exit" ) == 0 ) {
      runExit( words, count );
    } else if ( strcmp( words[ 0 ], "cd" ) == 0 ) {
      runCd( words, count );
    } else if ( strcmp( words[ 0 ], "" ) == 0 ) {
      //do nothing, user entered empty line
    } else {
      runCommand( words, count );
    }
  }
  
  return 0;
}