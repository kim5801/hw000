#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>
/**
  @file exclude.c
  @author Joey Brefka (jrbrefka)
  Takes a text file and outputs a text file that is the same as the input file, but
  is missing the specified line.
*/

/**
  Takes a string and parses it into an int
  @param the string being parsed 
  @return the int created
*/
int stringToInt(char *str)
{
  int num = 0;
  int multTen = 1;
  int len = 1;
  for ( int i = 1; str[ i ]; i++ ) {
    multTen *= 10;
    len++;
  }
  for ( int i = 0; str[ i ]; i++ ) {
    if ( !( str[ i ] == '\0' || ( str[ i ] > '0' && str[ i ] < '9' )  ) ) {
      return -1;
    }
    num += multTen * ( str[ i ] - '0' );
    
    multTen /= 10;
  }
  return num;
}

/**
  Main function of the program.
  @return the exit status
  @param argc for the number of command line arguments
  @param argv for the command line arguments
*/
int main(int argc, char *argv[]) 
{
  int argindx = 1;
  int input = open( argv[ argindx++ ], O_RDONLY, 0600 );
  int output = open( argv[ argindx++ ], O_CREAT | O_WRONLY, 0600 );
  int exLine = stringToInt( argv[argindx++] );
  
  char usageMsg[] = "usage: exclude <input-file> <output-file> <line-number>\n";
  if ( input < 0 || output < 0 || argc > argindx || argc < argindx || exLine < 0 ) {
    write( STDERR_FILENO, usageMsg, sizeof( usageMsg ) );
  }
  int line = 1;
  char buff[ 64 ] = {};
  int numRead = read( input, buff, 64 );
  while (  numRead > 0 ) {
    for ( int i = 0; i < numRead; i++ ) {
      if ( buff[ i ] == '\n' ) {
        line++;
      }
      if ( line == exLine ) {
        buff[ i ] = '\0';
      }
    }
    write(output, buff, numRead);
    numRead = read(input, buff, 64);
  }
  
  return 0;
}