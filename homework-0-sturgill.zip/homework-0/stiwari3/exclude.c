/** Written with help of Linux man pages accessed through EOS and lecture 1 slides
*/

#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>

/* Number of bytes to read from input file at a time */
int BYTES_TO_READ = 64;

/* ASCII code to offset char by to convert to int */
int CHAR_OFFSET = 48;

int main(int argc, char *argv[]) {
    if (argc != 4 || argv[3] <= 0 || open(argv[1], O_RDONLY) == -1 || open(argv[2], O_WRONLY | O_CREAT, 700) == -1) {
        write(STDERR_FILENO, "usage: exclude <input-file> <output-file> <line-number>", 10);
        _exit(1);
    }

    int fd = open(argv[1], O_RDONLY);
    int fd2 = open(argv[2], O_WRONLY | O_CREAT, 700);
    int buffer[BYTES_TO_READ];
    int lineCount = 0;
    int num[3] = {0, 0, 0};
    int convertedNum = 0;

    for (int i = 0; i < 2; i++) {
        num[i] = (argv[3])[i] - CHAR_OFFSET;
    }

    convertedNum += (100 * num[0]) + (10 * num[1]) + num[2];

    while (read(fd, buffer, BYTES_TO_READ) > 0) {
        lineCount++;

        if (lineCount != convertedNum) {
            write(fd2, buffer, BYTES_TO_READ);
        }
    }

    close(fd);
    close(fd2);
    _exit(0);
}