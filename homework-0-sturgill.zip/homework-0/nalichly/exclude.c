/**
 * TODO
 * @file exclude.c
 * @author Noah Lichlyter nalichly
 * @date 2022-09-01
 */

#include <sys/types.h> //dont know if i need this
#include <unistd.h>
#include <fcntl.h>

#define ERR_ARGS 1

#define ARG_IN 1
#define ARG_OUT 2
#define ARG_LINE 3
#define NUM_ARGS 4 //program name + 3 args

#define BUFFER_SIZE 64

#define ASCII_0 '0'
#define ASCII_9 '9'


/**
 * Method that gets the length of a given string. Counts indicies in the
 * given char array up until the first null value encountered, returning
 * the length of the string as a decimal integer
 * 
 * @param str the string whose length is to be counted
 * @return the length of the string as a decimal integer.
 */
int getLen(char *str)
{
    int count = 0;
    char current = *str;
    while (current != 0 && current != '\000') { //not null
        count++;
        current = *(str + count); 
    }
    return count;
}

/**
 * Prints usage statemement to terminal and exits with the invalid args status code
 */
void invalidArgs()
{
    //usage message and its length
    char msg[] = "usage: exclude <input-file> <output-file> <line-number>\n";
    int msglen = getLen(msg);

    //write to stderr
    write(STDERR_FILENO, msg, msglen);
    
    //terminate program with sys call
    _exit(ERR_ARGS); 
}

//Method I might need for converting the line number
int intFromChar(int ch)
{
    if (ch >= ASCII_0 && ch <= ASCII_9) //if not number
        return (ch - ASCII_0);
    //else
    invalidArgs(); //is invalid
        
}

/**
 * Method that reads a decimal number stored in a string and 
 * returns an int containing the value of the number. Uses
 * a helper method intFromChar() to handle converting the
 * individual digits. Program will exit via _exit() if the
 * given string contains anything other than a positive 
 * decimal integer. 
 * 
 * @param str the string to be parsed
 * @return int containing decimal value of the string
 */
int intFromStr(char *str)
{
    //variable for our number 
    int number = 0; 

    //determine how long the number is
    int len = getLen(str); //get the length of the str containing it

    int power = 1; //essentially exponent of 10 if this were in sci notation
    if (len > 1) { //set power according to length of string
        for (int i = len; i > 1; i--) {
            power *= 10; 
        }
    }

    //read in the number
    int idx = 0; //index in the array
    char current = *str; //first entry in array

    while (current != 0) {
        //add current digit to total
        number += intFromChar(current) * power; //
        power = power / 10;  //adjust power for next digit

        //get next digit ready
        idx++; 
        current = *(str + idx);
    }

    return number; //return the result
}

//main method
int main (int argc, char *argv[])
{

    /** Check args */
    if (argc != NUM_ARGS)
        invalidArgs(); //TODO return error for incorrect args

    //get the line to skip
    int lineToSkip = intFromStr(argv[ARG_LINE]); //line to skip

    //get input file and output file
    char *inFile = argv[ARG_IN]; //name of the input file
    char *outFile = argv[ARG_OUT]; //name of the ouput file

    //open files for reading and writing
    int in = open(inFile, O_RDONLY);
    int out = open(outFile, O_WRONLY | O_CREAT, 00600);

    if (in == -1 || out == -1) {
        invalidArgs(); //TODO check if it needs different error message
    }

    int go = 1;
    int lineNum = 1; //tracks current line
    while (go) { //fill buffer

        char inBuffer[BUFFER_SIZE] = ""; // make/reset inBuffer
        char outBuffer[BUFFER_SIZE] = ""; // make/reset outBuffer
        int status = read(in, inBuffer, BUFFER_SIZE); //get first line

        if (status > 0) { //if we were able to read in more lines
            int readIdx = 0; 
            int writeIdx = 0;

            for (int i = 0; i < BUFFER_SIZE; i++) {
                if (lineNum != lineToSkip) { // if this is not in the line we skip
                    outBuffer[writeIdx] = inBuffer[readIdx]; // copy to out buffer
                    writeIdx++; //increment write index
                }

                //increment line counter if there is a newline
                if(inBuffer[readIdx] == '\n')
                    lineNum++;

                if(inBuffer[readIdx] == 0) {
                    go = 0;
                    break;
                }

                readIdx++;
            }

            int wLen = getLen(outBuffer);

            if (go) 
                write(out, &outBuffer, wLen - 1);
            if (!go)
                write(out, &outBuffer, wLen);
        }
    }

    close(in);
    close(out);

    return 0; // exit success
}