
#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>


int main( int argc, char *argv[] ) {

  char *buffer = argv[3];
  if(argc < 4 || argc > 4 ) {
    write(STDERR_FILENO, "usage: exclude <input-file> <output-file> <line-number>\n", 56 );
    _exit(-1);
  }
  int lineDigits;
  int lineNum = 0;
  for(int i = 0; buffer[i] != '\0'; i++) {
    lineDigits++;
  }
  
  for(int i = lineDigits - 1; i >= 0; i--) {
    int exponent = 1;
    int added = (buffer[i] - '0') * exponent;
    lineNum = lineNum + added;
    exponent = exponent * 10;
  }
  
  // Read and open the input file, output file and line number.
  int input = open(argv[1], O_RDONLY); 
  int output = open(argv[2], O_CREAT | O_WRONLY | O_TRUNC, 0600);
  
  if ( input < 0 || output < 0 || lineNum < 0) {
    write(STDERR_FILENO, "usage: exclude <input-file> <output-file> <line-number>\n", 56 );
    _exit(-1);
  }
  int currentLine = 1;
  char buff[65];
  int len = 64;
  while( len == 64 ) {
    len = read(input, buff, 64);
    for(int i = 0; i < len; i++ ) {
      if( lineNum != currentLine ) {
        write( output, buff + i, 1 );
      }
      if(buff[i] == '\n') {
        currentLine++;
      }
    }
  } 
  close(input);
  close(output);
  _exit(0);
}