#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/wait.h>
#include <ctype.h>




/**
  This function takes a user command (line) as input. It breaks the line into
  individual words, adds null termination between the words so each word is a separate string, and
  it fills in a pointer in the words array to point to the start of each word.
  @param line the line with the command to be parsed
  @param words The words array is the list of pointers to words in the user’s command
*/
int parseCommand( char *line, char *words[] ) {
  int wordAmount = 0;
  int len = strlen(line);
  words[0] = &line[0];
  for( int i = 0; i < len; i++ ) {
    if(isspace(line[i]) ) {
      line[i] = '\0';
      wordAmount++;
      i++;
      while(isspace(line[i])) {
        i++;
      }
      words[wordAmount] = &line[i];

    }
    else if(line[i] == '\0') {
      wordAmount++;
    }
  }
  return wordAmount;
}
/*
  This function performs the built-in exit command.
  @param words The words array is the list of pointers to words in the user’s command
  @param count the number of words in the array.
*/
void runExit( char *words[], int count ) {
  //exit is going to be at index 0 and the status at index 1
  if( count > 2 || count < 2 ) {
    fprintf( stdout, "Invalid command\n" );
  } 
  else {
    int status = 0;
    for(int i = strlen(words[1]) - 1; i >= 0; i--) {
      int exponent = 1;
      int added = (words[1][i] - '0') * exponent;
      status = status + added;
      exponent = exponent * 10;
    }
    exit(status);
  }
  
}
/*
  This function performs the built-in cd command.
  @param words The words array is the list of pointers to words in the user’s command
  @param count the number of words in the array.
*/
void runCd( char *words[], int count ) {
  if( count > 2 || count < 2 ) {
    fprintf( stdout, "Invalid command\n" );
  } else {
  char *path = words[1];
  int rtn = chdir(path);
  if(rtn == -1 ) {
    fprintf( stdout, "Invalid command\n" );
  }
  }
}
/*
  This function runs a (non-built-in) command by creating a child process and having it
  call execvp() to run the given command
  @param words The words array is the list of pointers to words in the user’s command
  @param count the number of words in the array.
*/
void runCommand( char *words[], int count ) {
  char *command = words[0];
  int rtn = 0;
  pid_t id = fork();
  if(id == 0) {
    rtn = execvp(command, words);
    if( rtn == -1 ) {
      fprintf( stdout, "Can't run command %s\n", command );
    }
  }
  else {
    wait(NULL);
  }
  
}

int main( int argc, char *argv[] ) {
  fprintf( stdout, "stash> " );
  char *words[1025];
  char line[1025];
  fgets(line, 1024, stdin );
  line[1025] = '\0';
  int count = parseCommand(line, words);
  words[count] = '\0';
  char *command = words[0];
  while( strcmp(command, "exit") == 0 || strcmp(command, "cd") == 0  ) {
    if( strcmp(command, "exit") == 0  ) {
      runExit( words, count );
      fprintf( stdout, "stash> " );
    }
    if( strcmp(command, "cd") == 0 ) {
      runCd( words, count );
      fprintf( stdout, "stash> " );
    }
    fgets(line, 1024, stdin );
    line[1025] = '\0';
    count = parseCommand(line, words);
    words[count] = '\0';
    command = words[0]; 
  }
  
  while( strcmp(command, "exit") != 0 ||  strcmp(command, "cd") != 0  ) {
    if( strcmp(command, "") == 0) {
      fprintf( stdout, "stash> " );
      fgets(line, 1024, stdin );
      line[1025] = '\0';
      count = parseCommand(line, words);
      words[count] = '\0';
      command = words[0]; 
    }
    runCommand( words, count );
    fprintf( stdout, "stash> " );
    fgets(line, 1024, stdin );
    line[1025] = '\0';
    count = parseCommand(line, words);
    words[count] = '\0';
    command = words[0]; 
  }
  
  
  
}
