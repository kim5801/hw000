/**
 * A program to remove a line of a text file without using C standard
 * library calls
 *
 * @file exclude.c
 * @author Jonathan Lawrence (jdlawren)
 */

#include <fcntl.h>
#include <unistd.h>

/**
 * Function that is called when program receives invalid arguments
 */
static void fail()
{
  char error[] = "usage: exclude <input-file> <output-file> <line-number>\n";
  write(STDERR_FILENO, error, sizeof(error));
  _exit(1);
}

/** Program to exclude a line of a text file
 *
 * @param argc Number of command line arguments
 * @param argv Array of command line arguments
 * @return Exit Status, 0 is success, 1 is failure
 */
int main(int argc, char **argv)
{
  // Test to fail if too many arguments
  if (argc != 4) {
    fail();
  }

  // Open input, fail if not open
  int f_in = open(argv[1], O_RDONLY);
  if (f_in == -1) {
    fail();
  }

  // Open output, fail if not open
  int f_out = creat(argv[2], 0600);
  if (f_out == -1) {
    close(f_in);
    fail();
  }

  // Defined need variables
  char in_buffer[64];
  char out_buffer[64];
  int in_chars;
  char current;
  int out_chars = 0;
  int line_count = 1;
  int exclude = 0;

  // Convert line number string to and integer, fail if unable to be read
  for (int i = 0; argv[3][i]; i++) {
    if (argv[3][i] < '0' || argv[3][i] > '9') {
      close(f_in);
      close(f_out);
      fail();
    }
    exclude *= 10;
    exclude += argv[3][i] - '0';
  }

  // Read into input buffer
  in_chars = read(f_in, in_buffer, 64);

  // Loop while input buffer has data
  while (in_chars != 0) {

    // For each character in input buffer
    for (int i = 0; i < in_chars; i++) {
      current = in_buffer[i];

      // Keep track of the line number
      if (current == '\n') {
        line_count++;
      }

      // If line is to be printed, add character to output buffer
      if (line_count != exclude) {
        out_buffer[out_chars] = current;
        out_chars++;
      }

      // Write if output buffer is full
      if (out_chars == 64) {
        write(f_out, out_buffer, out_chars);
        out_chars = 0;
      }
    }

    // Read into input buffer
    in_chars = read(f_in, in_buffer, 64);
  }

  // Print any remaining character in output buffer
  write(f_out, out_buffer, out_chars);

  // Close files before exiting
  close(f_in);
  close(f_out);

  return 0;
}