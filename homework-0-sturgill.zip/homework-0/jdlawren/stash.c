/**
 * A simple shell program
 *
 * @file stash.c
 * @author Jonathan Lawrence (jdlawren)
 */

#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <string.h>
#include <sys/wait.h>
#include <sys/types.h>

/**
 * An error message used when the build in commands fail
 */
void error_msg()
{
  printf("Invalid command\n");
}

/**
 * Help function that takes a line of input from stdin, stopping at a new line,
 * or 1024 characters.
 * @param buffer array to save the character to, should be at least 1025 chars
 * in size
 */
void getLine(char *buffer)
{
  char current = getchar();
  for (int i = 0; i < 1024; i++) {
    if (current == '\n' || current == EOF) {
      buffer[i] = '\0';
      break;
    }
    buffer[i] = current;
    current = getchar();
  }
}

/**
 * Function to replaces all spaces in the input line with null terminators and
 * return an array of all works in the line
 * @param line The line of test from standard in, parsed by getLine()
 * @param words An array of char pointers to the start of each word in the line
 * @return the number of words found in the line
 */
int parseCommand(char *line, char *words[])
{
  bool newWord = true;
  int count = 0;
  for (int i = 0; line[i]; i++) {
    if (line[i] == ' ') {
      line[i] = '\0';
      newWord = true;
    } else if (newWord) {
      words[count] = &(line[i]);
      count++;
      newWord = false;
    }
  }
  return count;
}

/**
 * Built in cd command
 * @param words words inputted by the user
 * @param count number of words inputted by the user
 */
void runCD(char *words[], int count)
{
  if (count != 2) {
    error_msg();
    return;
  }
  int status = chdir(words[1]);
  if (status != 0) {
    error_msg();
    return;
  }
}

/**
 * Built in command to exit the shell
 * @param words words inputted by the user
 * @param count number of words inputted by the user
 */
void runExit(char *words[], int count)
{
  if (count != 2) {
    error_msg();
    return;
  }

  //Convert string to integer
  // I used very similar code in exclude.c for the same function
  int status = 0;
  for (int i = 0; words[1][i]; i++) {
    if (words[1][i] < '0' || words[1][i] > '9') {
      error_msg();
      return;
    }
    status *= 10;
    status += words[1][i] - '0';
  }

  exit(status);
}

/**
 * Function to run and command located in the user's PATH variable
 * @param words words inputted by the user
 * @param count number of words inputted by the user
 */
void runCommand(char *words[], int count)
{
  pid_t pid = fork();
  if (pid == 0) {
    // Add null terminator to array of words
    words[count] = NULL;
    execvp(words[0], words);
    //Error message and exit if command is not found
    printf("Can't run command %s\n", words[0]);
    exit(1);

  } else {
    //parent wait for child to finish
    wait(NULL);
  }
}

/**
 * Main loop of the shell, prompts user for input, gets input, and runs
 * corresponding function.
 * @return Exit value of the program is determined by the user and runExit
 * function
 */
int main()
{
  // Infinite Loop, exit command is used to close program
  while (true) {

    // Prompt for command
    printf("stash> ");

    // Get and parse user input
    char buffer[1025];
    char *words[513];
    getLine(buffer);
    int count = parseCommand(buffer, words);

    // Use runCommand if command is not built in
    if (strcmp(words[0], "exit") == 0) {
      runExit(words, count);
    } else if (strcmp(words[0], "cd") == 0) {
      runCD(words, count);
    } else {
      runCommand(words, count);
    }
  }
}