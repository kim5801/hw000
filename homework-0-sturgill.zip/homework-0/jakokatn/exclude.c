/*
  @file exclude.c
  @author Josh Kokatnur (jakokatn)
  Copies text between files, excluding a certain line.
*/

// Includes
#include <fcntl.h>
#include <unistd.h>

#define EXIT_FAILURE 1

/*
  The starting point of the program.
  @param argc the number of command line args
  @param *argv[] the command line args
  @return the exit status of the program
*/
int main( int argc, char *argv[] )
{
  // check for proper number of arguments
  if ( argc != 4 ) {
    // ref: https://stackoverflow.com/questions/3866217/how-can-i-make-the-system-call-write-print-to-the-screen
    const char msg[] = "usage: exclude <input-file> <output-file> <line-number>\n";
    write(STDOUT_FILENO, msg, sizeof(msg)-1);
    _exit(EXIT_FAILURE);
  }

  // open file for reading
  int fd = open( argv[1], O_RDONLY );

  // create output file
  int fd2 = open( argv[2], O_CREAT|O_WRONLY, 0600 );

  // parse line number to be excluded
  // I recall implementing this more efficiently in csc230, but am deciding to go with the more obvious implementation here:
  int validLineNumber = 0; // (boolean) to track if number is valid

  // first, determine the number of characters (and check for invalid ones)
  int numCharacters = 0;
  while ( argv[3][numCharacters] != '\0' ) {
    // if invalid character, mark it
    if ( argv[3][numCharacters] < '0' || argv[3][numCharacters] > '9' ) {
      validLineNumber = 1;
      break;
    }

    // increment counter
    numCharacters++;
  }

  // second, iterate over string in reverse and build the integer
  int lineNumber = 0;
  int multiplier = 1;
  for ( int i = numCharacters - 1; i >= 0; i-- )  {
    int digit = argv[3][i] - '0';
    lineNumber += multiplier * digit;
    multiplier *= 10;
  }
  
  // if any errors, exit
  if ( validLineNumber != 0 || fd == -1 || fd2 == -1 ) {
    const char msg[] = "usage: exclude <input-file> <output-file> <line-number>\n";
    write(STDOUT_FILENO, msg, sizeof(msg)-1);
    _exit(EXIT_FAILURE);
  }

  // begin copying to new file
  // track current line number
  int lineCounter = 1;

  // iterate over each byte in the input file, using chunks of 64 bytes
  char buffer[64];
  int numRead = 0;
  while ( (numRead = read(fd, buffer, 64)) != 0 && numRead != -1 ) {
    for ( int i = 0; i < numRead; i++ ) {
      // if not in the excluded line, write to the output file
      if ( lineCounter != lineNumber ) {
        write(fd2, &buffer[i], 1);
      }
    
      // if byte is newline, increase line counter
      if ( buffer[i] == '\n' ) {
        lineCounter++;
      }
    }
  }

  // close files
  close( fd );
  close( fd2 );
}
