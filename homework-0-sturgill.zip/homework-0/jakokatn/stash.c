/*
  @file stash.c
  @author Josh Kokatnur (jakokatn)
  A shell program.
*/

// Includes
#include <fcntl.h>
#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/wait.h>

/*
  Breaks user input into individual words.
  @param *line the user input
  @param *words[] pointer to the array of words to be returned
  @return the number of words read
*/
int parseCommand( char *line, char *words[] )
{
  int i = 0;
  int wordCount = 0;
  int isNewWord = 0;
  
  while( line[i] != '\0' && line[i] != '\n' ) {
    // skip all whitespace
    if ( line[i] == ' ' ) {
      line[i] = '\0';
      isNewWord = 0;
    } else if ( isNewWord == 0 ) {
      words[wordCount] = &line[i];
      wordCount++;
      isNewWord = 1;
    }

    i++;
  }

  // ensure final character is null terminator
  line[i] = '\0';

  return wordCount;
}

/*
  Runs the exit command.
  @param *words[] the array of parsed words
  @param count the number of parsed words
*/
void runExit( char *words[], int count )
{
  int exitCode = 0;
  if ( count == 2 ) {
    // parse second word to int
    exitCode = atoi(words[1]);
  }
  if ( count != 2 || exitCode == 0 ) {
    printf( "%s\n", "Invalid command" );
  } else {
    _exit(exitCode);
  }
}

/*
  Runs the cd command.
  @param *words[] the array of parsed words
  @param count the number of parsed words
*/
void runCd( char *words[], int count )
{
  int chdirResponse = 0;
  if ( count == 2 ) {
    chdirResponse = chdir( words[1] ); 
  }
  if ( chdirResponse == -1 || count != 2 ) {
    printf( "%s\n", "Invalid command" );
  }
}

/*
  Runs any arbitrary command.
  @param *words[] the array of parsed words
  @param count the number of parsed words
*/
void runCommand( char *words[], int count )
{
  // create child process
  pid_t pid = fork();
 
  // if child process, run the command
  if ( pid == 0 ) {
    // run executable
    words[count] = NULL;
    int res = execvp( words[0], words );

    if ( res == -1 ) {
      printf( "%s %s\n", "Can’t run command", words[0]);
    }

    // exit
    exit(0);
  } else if ( pid != -1 ) {
    // if parent process, wait
    wait(0);
  }
}

/*
  The starting point of the program.
  @param argc the number of command line args
  @param *argv[] the command line args
  @return the exit status of the program
*/
int main( int argc, char *argv[] )
{
  do {
    // get input
    write(STDOUT_FILENO, "\nstash> ", 8); 
    char buffer[1024];
    read(STDIN_FILENO, buffer, 1024);

    // parse input
    char *words[513];
    int numWords = parseCommand( buffer, words );

    // run command
    if ( numWords > 0 ) {
      if ( strcmp( words[0], "exit" ) == 0 ) {
        runExit( words, numWords );
      } else if ( strcmp( words[0], "cd" ) == 0 ) {
        runCd( words, numWords );
      } else {
        // run custom command
        runCommand( words, numWords );
      }
    }
    
  } while ( 1 == 1 ); // repeat this forever (program exits with exit command)
}
