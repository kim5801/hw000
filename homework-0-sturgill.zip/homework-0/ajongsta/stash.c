#include <unistd.h>
#include <fcntl.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include<sys/wait.h>

/**
* DONE
* This function should take in a user's command line input. It will break the
* line into individual words and return the number of words passed through
* @param line the line being read
* @param words  the array being added to
*/
int parseCommand( char *line, char *words[] ) {
    //Initialize the number of words to one
    int numWords = 1;
    //Tracks if we already had whitespace
    int whiteSpaceBefore = 0;
    int i = 0;
    while(line[i] == ' ') {
        i++;
    }
    words[ 0 ] = &line[ i ];
    
    //Iterate through the string searching for spaces, replacing spaces with
    //the null terminator and updating the pointer location for words[] and
    //the word count.
    while( line[ i ] != '\0' ) {
        if( line[ i ] == ' ' ) {
            line[ i ] = '\0';
            whiteSpaceBefore = 1;
        } else {
            if(whiteSpaceBefore == 1 ) {
                numWords++;
                //sscanf( line[ i ], "%s", words[ numWords - 1 ] );
                words[ numWords - 1 ] = &line[ i ];

            }
            whiteSpaceBefore = 0;
        }
        i++;
    }
    return numWords;
}

/**
* This function should perform the built in exit command.
* @param words list of pointers to words in the user's command
* @param count the number of words
*/
void runExit( char *words[], int count ) {
    //Not 2 arguments, throw error then reprompt
    if(count != 2) {
        printf( "Invalid command\n" );
    } else {
        //Convert to integer
        int statusCode = atoi( words[ 1 ] );
        //If it fails to convert throw an error
        if( statusCode == 0 ) { 
            printf( "Invalid command\n" );
        } 
        //Otherwise we exit with the status code presented
        else {
            exit( statusCode );
        }
    }
}

/**
* This function should perform the built in cd command.
* @param words list of pointers to words in the user's command
* @param count the number of words
*/
void runCd( char *words[], int count ) {
    //Not 2 arguments, throw error then reprompt
    if(count != 2) {
        printf( "Invalid command\n" );
    } else {
        //Should return -1 if chdir fails, if that happens we throw error
        //and reprompt
        int errorCheck = chdir( words[ 1 ] );
        if( errorCheck == -1 ) {
            printf( "Invalid command\n" );
        }
    }
}

/**
* This function should perform any other commands by creating a child process
* and calling execvp() to run a command
* @param words list of pointers to words in the user's command
* @param count the number of words
*/
void runCommand( char *words[], int count ) {
    pid_t id = fork();
    words[count] = NULL;
    if( id == 0 ) {
        int x = execvp( words[ 0 ], words );
        if( x < 0 ) {
            printf( "Can't run command %s\n", words[ 0 ] );
        }
        exit(1);
    } else {
        wait(NULL);
    }
}

/**
* @param argc the number of arguments presented
* @param argv the array of arguments
*/
int main( int argc, char *argv[] ) {

    while(1) {
        //Initialize our arrays
        char z[1025];
        char *words[513];

        //What starts each command (prompt for user) and gets the user input
        printf("stash> ");
        fgets(z, 1024, stdin);

        //Cap off user input with a null terminator
        z[ strlen(z) - 1 ] = '\0';

        //Parsed our command and end the words with a null terminator
        int count = parseCommand( z, words );
        words[count] = '\0';

        //Case for first custom command "cd"
        if( strcmp( words[ 0 ], "cd" ) == 0 ) {
            runCd( words, count );
        }
        //Case for second custom command "exit"
        else if ( strcmp( words[ 0 ], "exit" ) == 0 ) {
            runExit( words, count );
        }
        //Case for no command
        else if (strcmp(words[0], "") == 0) {
            continue;
        }
        //Case for other external command
        else {
            runCommand( words, count );
        }
    }
    
    return EXIT_SUCCESS;
}