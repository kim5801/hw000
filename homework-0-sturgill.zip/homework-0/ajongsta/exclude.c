#include <unistd.h>
#include <fcntl.h>

int bufferLength = 0;

char returnBuffer[1024];

/**
* @param c the string being converted to an int
* @return c as an integer value
*/
int stringToInt( char c[] ) {
    int retVal = 0;
    for( int i = 0; c[i] != '\0'; i++ ) {
        if(c[i] > '9' || c[i] < '0') {
            write( STDERR_FILENO, "exclude <input-file> <output-file> <line-number>\n", 49 );
            _exit(1);
        }
        retVal = ( retVal * 10 ) + c[i] - '0';
    }
    return retVal;
}

/**
* Reads in the buffer full of characters and omits the line to be excluded from a new buffer object
* @param buffer the buffer being passed through to be edited
* @param lineNum the line number which we must exclude from our project
*/
char * removeLine( char * buffer, int lineNum ) {
    //Tracks which line number we're on
    int lineTracker = 1;
    //Tracks whether or not we're done reading through the excluded line
    int doneReading = 1;
    //Boolean int to fix an error where the first line prints a new line even though it shouldnt when removed.
    int firstError = 1;
    //Variable tracker to ensure we can put characters at the start of the array.
    int x = 0;
    //Create a new buffer to hold the returnBuffer old values
    static char finalBuffer[1024];
    //Iterate through the buffer until we hit the line we're looking for. Special case for first line
    for( int i = 0; i < bufferLength; i++ ) {
        //Update LineTracker value every time we hit a new line.
        if( buffer[ i ] == '\n' ) {
            if( ( lineTracker == 1 ) && (lineNum == 1) ) {
                firstError = 0;
            }
            lineTracker++;
            //Update done reading else if we're done reading in the new line
            if( doneReading == 0 ) {
                doneReading = 1;
            }
        }
        //If we're starting the new line 
        if( ( lineTracker == lineNum ) && ( doneReading == 1 ) ) {
            if( ( lineTracker != 1 ) ) {
                ( finalBuffer[i] ) = buffer[ i ];
            }
            
            doneReading = 0;
        }
        
        //If we're not reading the excluded line add the character to the new buffer being returned
        if( ( doneReading != 0 ) && ( firstError == 1 ) ) {
            ( finalBuffer[x] ) = buffer[ i ];
            
            x++;
        }
        if((lineTracker == 2) && (firstError == 0)) {
            firstError = 1;
        }
    }
    return finalBuffer;
    
}

/**
* This program should be able to copy over all the lines from the first argument argv[0] to argv[1]
* excluding line # argv[2]
* @param argc the number of arguments included
* @param argv an array of the argument presented
* @return EXIT_SUCCESS if the program successfully exits
*/
int main( int argc, char *argv[] ) {
    /**char test[100] = "This is a test.\nTo see if the second line is removed.\nI don't know if it will work\n";
    returnBuffer[99] = '\0';
    removeLine(test, 1);
    printf("%s", returnBuffer);*/
    //Buffer that we're going to use to read in characters and then write to output
    char tempBuffer[ 64 ];

    //Open input
    int fi = open( argv[ 1 ], O_RDONLY);
    if( fi == -1 ) {
        write( STDERR_FILENO, "Can't open input file.\n", 23 );
        _exit( 8 );
    }

    int howManyFromInput = 0;
    //Read our input into the buffer while 
    while(1) {
        howManyFromInput = read( fi, &tempBuffer, 64);
        
        //If we're not reading anything more in, break out of the loop
        if( howManyFromInput == 0 ) {
            break;
        }
        //Increase the buffer length to include the new bytes
        bufferLength += howManyFromInput;
        char loopBuffer[ bufferLength ];

        if(bufferLength >= 64) {
            //Add old values to the loopBuffer (the new array)
            for(int i = 0; i < ( bufferLength - howManyFromInput ); i++ ) {
                loopBuffer[ i ] = returnBuffer[ i ];
            }
        }

        int k = 0;

        //Add new values to the loopBuffer
        for(int i = ( bufferLength - howManyFromInput ); i < bufferLength; i++) {
            loopBuffer[ i ] = tempBuffer[ k ];
            k++;
        }

        //Replace the old returnBuffer value
        for(int i = 0; i < bufferLength; i++) {
            returnBuffer[i] = loopBuffer[i];
        }
    } 
    //Get the third command line argument as an integer
    int lineNum = stringToInt( argv[ 3 ] );
    //Remove the line from this buffer (function call?)

    char * retVal = removeLine(returnBuffer, lineNum);

    //Open output
    int fo = open( argv[ 2 ], O_CREAT | O_WRONLY, 0600);
    if( fo == -1 ) {
        write( STDERR_FILENO, "Can't open output file.\n", 24 );
    }


    //Write the new buffer to the output file by iterating through the entirety of our buffer array
    //and writing one character at a time to the output (size of 1 byte per char)
    int valOfWrite = write( fo, retVal, bufferLength );
    if(valOfWrite == -1) {
        _exit( 8 );
    }

    //Close our files and exit successfully
    close(fo);
    close(fi);

    return 0;
}