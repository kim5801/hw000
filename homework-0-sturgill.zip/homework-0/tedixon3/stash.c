#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <stdlib.h>
#include<sys/wait.h>

int parseCommand();
void runCd();
void runExit();
void invalidCommand();



int main()
{
  char input[1025];
  char *wordList[513];
  // int numWords = parseCommand(input, wordList);
  int numWords;
  while(1) {
    printf("stash> ");
    fgets(input, 1024, stdin);
    numWords = parseCommand(input, wordList);
    if (strcmp(wordList[0], "cd") == 0) {
      runCd(wordList, numWords);
    } else if (strcmp(wordList[0], "exit") == 0) {
      runExit(wordList, numWords);
    }
  }
  
}
/**
 * Takes a user command line as input, breaks the line into individual words, adds null termination, 
 * and fills in the pointers in the words array to the start of each word. It returns the number of 
 * words found in the given line
 * 
 * @param line 
 * @param words 
 * @return int 
 */
int parseCommand(char *line, char *words)
{
  int numWords = 0;
  int i = 0;
  while (line[i] != '\0') {
    if (i == 0) {
      words[numWords++] = line[i];
    }
    if (i > 0 && ((line[i - 1] == ' ') | (line[i - 1] == '\0')) && line[i] != ' ') {
      words[numWords++] = line[i];
    }
    if (line[i] == '\0');
    i++;
  }
  return numWords;
}


/**
 * Performs the built-in exit command.
 * 
 * @param words a list of pointers to wrods in the users command
 * @param count the number of words in the array
 */
void runExit(char *words[], int count)
{
  if (count == 2) {
    exit(1);
  } else {
    invalidCommand();
  }
}

/**
 * Performs the built-in cd command.
 * 
 * @param words a list of pointers to wrods in the users command
 * @param count the number of words in the array
 */
void runCd(char *words[], int count)
{
  if(count != 2) invalidCommand(); 

  int result = chdir(words[1]);

  if (!result) {
    invalidCommand();
  } 
}


/**
 * Runs a command by creating a child process and having it call execvp to run 
 * the give command
 * 
 * @param words a list of pointers to wrods in the users command
 * @param count the number of words in the array
 */

void runCommand(char *words[], int count)
{
  int pid = fork();

  if (pid == 0) {
    execvp(words[0], words);
  } else {
    wait(NULL);
  }
}

void invalidCommand() { printf("Invalid command"); }