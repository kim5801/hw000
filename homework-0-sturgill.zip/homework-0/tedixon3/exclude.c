#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>


#include <stdio.h>

/**
 * Main method
 * 
 * @param argc number of command line arguments
 * @param argv command line arguments
 * @return int success value
 */
int main(int argc, char *argv[])
{
  // Checks for correct number of arguments from the command line
  if (argc != 4) {
    write(STDERR_FILENO, "usage: exclude <input-file> <output-file> <line-number>", 55);
    _exit(1);
  }


  int fileIn = open(argv[1], O_RDONLY);
  int fileOut = open(argv[2], O_RDWR | O_CREAT, 00700);

  char *linePtr;
  int lnToSkip = 0;


  int val = 0;
  for (linePtr = argv[3]; *linePtr != '\0'; linePtr++) {
    char c = *linePtr;
    if (c >= 48 && c <= 57) {
      val = c - 48;
      lnToSkip *= 10;
      lnToSkip += val;
    }
  }

  int lineCount = 1;
  
  int bytesRead = 0;


  //Checks if the read call got all 64 bytes and loops if it did to see if there are any more
  char buffer[64];
  char *toUse;

  int skippedCount = 0;
  do {
    int counter = 0;
    //reads 64 bytes from fileIn and puts them into the buffer
    buffer[0] = '\0';
    bytesRead = read(fileIn, buffer, 64);
    
    toUse = buffer;

    //loops until every value that was read has been processed
    while (counter < bytesRead) {

      //Checks if the current line is the one to be excluded and excludes it if necessary and writes 
      // it to the file otherwise
      if (lineCount != lnToSkip) {
        // printf("%c", buffer[counter]);
        write(fileOut, toUse, 1);
      } else {
        skippedCount++;
      }
      toUse++;

      //If a newline character is found then the line counter is increased so that we can find the line that will be excluded
      if (buffer[counter++] == '\n') lineCount++;
    }
  } while (bytesRead == 64);


  return 0;
}

