/**
    @file exclude.c
    @author Grant Arne gtarne
    Transfers contents of an input file to an output file, excluding the contents of a given line number
 */
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>

/** The size of one block to read */
#define BLOCK_SIZE 64
/** The length of the error message */
#define MSG_LENGTH 57

/**
 * Converts a string of characters into the decimal value and returns it
 * 
 * @param input a string representing a positive integer
 * @return int the value of the string, or -1 if string is not a positive integer
 */
int toDecimal( char *input ) {
    int value = 0;
    for( int i = 0; input[i] != '\0'; i++ ) {
        if ( input[i] < '0' || input[i] > '9' ) {
            return -1;
        } else {
            value *= 10;
            value += input[i] - '0';
        }
    }
    return value;
}

/**
 * Takes an input file, output file, and a line number.
 *  Copies the contents of the input file to the output file, excluding the contents of the given line number.
 *  usage: exclude <input-file> <output-file> <line-number>
 * 
 * @param argc the number of arguments
 * @param argv the arguments
 * @return int the exit status
 */
int main( int argc, char *argv[] ) {
    char *errMsg = "usage: exclude <input-file> <output-file> <line-number>\n";
    // Check for correct number of arguments
    if ( argc != 4 ) {
        write( STDERR_FILENO, errMsg, MSG_LENGTH );
        _exit( 1 );
    }
    // try to open input and output files
    int inputFd = open( argv[1], O_RDONLY );
    if ( inputFd == -1 ) {
        write( STDERR_FILENO, errMsg, MSG_LENGTH );
        close( inputFd );
        _exit( 1 );
    }
    int outFd = open( argv[2], O_WRONLY | O_CREAT | O_TRUNC, 0600 );
    int skip = toDecimal( argv[3] );
    // check for invalid files or line number
    if ( outFd == -1 || skip == -1 ) {
        write( STDERR_FILENO, errMsg, MSG_LENGTH );
        close( inputFd );
        close( outFd );
        _exit( 1 );
    }
    int curLine = 1;
    char inBlock[ BLOCK_SIZE ];
    char outBlock[ BLOCK_SIZE ];
    int bytesRead = -1;
    int outSize = 0;
    int atEnd = 0;
    // Loop to read and write bytes until EOF is reached
    while( atEnd == 0 ) {
        bytesRead = read( inputFd, inBlock, BLOCK_SIZE );
        outSize = 0;
        // Check each character for newline and copy byte to output if included
        for ( int i = 0; i < bytesRead; i++ ) {
            // If current line is included
            if ( curLine != skip ) {
                outBlock[ outSize ] = inBlock[ i ];
                outSize++;
            }
            // Increment line count if newline
            if ( inBlock[ i ] == '\n' ) {
                curLine++;
            }
        }
        // Check if EOF was reached or max bytes was read
        if ( bytesRead < BLOCK_SIZE ) {
            atEnd = 1;
        }
        // Copy output block to file
        write( outFd, outBlock, outSize );
    }
    // Close files
    close( inputFd );
    close( outFd );
    _exit( 0 );
}
