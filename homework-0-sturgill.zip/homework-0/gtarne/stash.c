/**
 * @file stash.c
 * @author Grant Arne gtarne
 * A small shell which prompts the user for a command then executes 
 * it locally if it is cd or exit, or externally otherwise
 */

#include <stdbool.h>
#include <ctype.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <sys/wait.h>
#include <sys/types.h>

/** The max number of words input */
#define MAX_WORDS 514
/** The max length of input line */
#define MAX_LINE_LENGTH 1024

/**
 * Takes an input line of characters and separates it into words with null terminators between
 *  Changes line whitespace to null terminators and changes the array of pointers to point to each word
 *  Returns the number of words parsed
 * 
 * @param line the line to parse
 * @param words the array to be filled with
 * @return int number of words parsed
 */
int parseCommand( char *line, char *words[] ) {
    int numWords = 0;
    bool newWord = true;
    // Iterate through line until null terminator reached
    for( int i = 0; line[ i ] != '\0'; i++ ) {
        // Replace whitespace with null terminator
        if ( isspace( line[ i ] ) ) {
            line[ i ] = '\0';
            newWord = true;
        // Create pointer to the character if it is a new word
        } else if ( newWord ) {
            words[ numWords ] = &( line[ i ] );
            numWords++;
            newWord = false;
        }
    }
    return numWords;
}
/**
 * Runs exit with the status given in index 1 of the given array
 * 
 * @param words the command to execute and parameters to use
 * @param count the number of words in the array
 */
void runExit( char *words[], int count ) {
    int status;
    // Parse status from string and check for correct number of words
    if ( count != 2 || sscanf( words[ 1 ], "%d", &status ) == 0 ) {
        printf("Invalid command\n");
    } else {
        exit( status );
    }
}

/**
 * Runs the cd system call with the given parameter
 * 
 * @param words the system call and parameter to use
 * @param count the number of words in the given array
 */
void runCd( char *words[], int count ) {
    if ( count != 2 || chdir( words[ 1 ] ) != 0 ) {
        printf("Invalid command\n");
    }
}

/**
 * Creates a child to execute the given command with the given parameters
 * 
 * @param words array with the command to execute and parameters to use
 * @param count the number of words in the array
 */
void runCommand( char *words[], int count ) {
    words[ count ] = NULL;
    int pid;
    int status;
    // Create child and check if current process is the parent
    if ( ( pid = fork() ) > 0 ) {
        wait( &status );
    } else if ( pid == 0 ) {
        // Execute command if this process is the child
        if ( execvp( words[ 0 ], words ) == -1 ) {
            printf( "Can't run command %s\n", words[0] );
        }
        exit( EXIT_SUCCESS );
    }
}
/**
 * A small shell which prompts the user for a command, executing valid commands until exited
 * 
 * @param argc the number of arguments
 * @param argv the array of arguments
 * @return int the exit status
 */
int main( int argc, char *argv[] ) {
    char line[ MAX_LINE_LENGTH + 1 ];
    char *words[ MAX_WORDS + 1 ];
    bool prompt = true;
    while ( prompt ) {
        printf( "stash> " );
        // Read input line
        fgets( line, MAX_LINE_LENGTH, stdin );
        int numWords = parseCommand( line, words );
        // Ignore blank
        if ( numWords == 0 ) {

        // Check if command is cd
        } else if ( strcmp( words[ 0 ], "cd" ) == 0 ) {
            runCd( words, numWords );
        // Check if command is exit
        } else if ( strcmp( words[ 0 ], "exit" ) == 0 ) {
            runExit( words, numWords );
        // Run external command
        } else {
            runCommand( words, numWords );
        }
    }
}
