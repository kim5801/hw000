#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>

// Read in contents of file, 64 bytes at a time and place into array
// Iterate through the array, write()ing characters to output and counting the number of \n characters passed
// When that number is passed, keep iterating but do not write. Guard the write call with a
// check to make sure numLinesRead != numThatUserSpecified

// Method to make printing the usage error easier
void throwUsageError() {
    write(STDERR_FILENO, "usage: exclude <input-file> <output-file> <line-number>\n", 56); // 56 is the number of bytes long the string is, plus the newline
    _exit(1);
}

static int stringToInt(char *str) {
    // Find the length
    int len = 0;
    while (str[len] != '\0') {
        len++;
    }

    // Check to make sure the number is a valid integer
    for (int i = 0; i < len; i++) {
        if (str[i] < '0' || str[i] > '9') {
            throwUsageError();
        }
    }

    // Starting from the rightmost digit, convert to integer
    int result = 0;
    int idx = 1;
    for (int i = len - 1; i >= 0; i--) {
        result += idx * (str[i] - '0'); // Get the decimal equivalent of the character, move it to the right place, and add it to the result
        idx *= 10; // Process the next digit
    }
    return result;
}

int main(int argc, char *argv[]) {
    // Check for the right number of arguments
    if (argc != 4) {
        throwUsageError();
    }
    
    // Open the input file and check if it was opened correctly
    int in = open(argv[1], O_RDONLY);
    if (in == -1) {
        throwUsageError();
    }

    // Open the output file and check if it was opened correctly
    int out = open(argv[2], O_WRONLY | O_CREAT | O_TRUNC, 0600);
    if (out == -1) {
        throwUsageError();
    }

    // Init variables for use later
    int capacity = 64;
    char contentsArray[capacity];
    int numBytesRead = 0;
    int currentLine = 1;
    int skipLine = stringToInt(argv[3]);

    // Keep reading input until there is no more to read
    while ((numBytesRead = read(in, contentsArray, 64)) != 0) {
        // Print the block of data, one byte at a time while counting newlines
        for (int i = 0; i < numBytesRead; i++) {
            if (currentLine != skipLine) { 
                write(out, contentsArray + i, 1);
            } // Else, don't do anything

            // As we read input, count how many lines there have been. We need this number to know what chars to exclude
            if (contentsArray[i] == '\n') {
                currentLine++;
            }
        }
    }

    // Close the files and exit successfully
    close(in);
    close(out);
    _exit(0);
}