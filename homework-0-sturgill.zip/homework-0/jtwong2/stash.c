#include <stdbool.h>
#include <stdio.h>
#include <ctype.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>

int parseCommand( char *line, char *words[] ) {
    int numWords = 0;
    bool hasWhitespaceBefore = true; // Since we start at the beginning of a word
    bool hasCharacterBefore = false;

    for (int i = 0; line[i]; i++) {
        if (isspace(line[i]) && hasCharacterBefore) { // If the char is a whitespace and the end of a word
            line[i] = '\0';
            hasCharacterBefore = false; // Set flags for the next iteration of the loop
            hasWhitespaceBefore = true;
        } else if (!isspace(line[i]) && hasWhitespaceBefore) {
            // If this character is the beginning of a word, we need to make a pointer to it
            // words[numWords] = malloc(sizeof(char));
            words[numWords] = &line[i];
            numWords++;

            hasCharacterBefore = true; // Set flags for the next iteration of the loop
            hasWhitespaceBefore = false;
        }
    }

    // Null-terminate the words array for ease of use (and because the execvp() system call expects it)
    words[numWords] = NULL;

    return numWords;
}

void runExit( char *words[], int count ) {
    // Invalid number of arguments
    if (count != 2) {
        printf("Invalid command\n");
        return;
    }

    // Attempt to parse the last argument into an integer:
    // Check if the word is an integer
    for (int i = 0; words[1][i]; i++) {
        if (!isdigit(words[1][i])) {
            printf("Invalid command\n");
            return;
        }
    }

    // Since the word is an integer, we can parse it
    int status = 0;
    for (int i = 0; words[1][i]; i++) {
        status = status * 10 + (words[1][i] - '0'); // Move the digits of status to the left by 1, and then convert the character into an integer to add it to status
    }
    // printf("%d\n", status);

    exit(status);
}

void runCd( char *words[], int count) {
    // Invalid number of arguments
    if (count != 2) {
        printf("Invalid command\n");
        return;
    }

    // Assume that the command is valid and call chdir() system call
    int cmdStatus = chdir(words[1]);
    if (cmdStatus != 0) {
        printf("Invalid command\n");
        return;
    }
}

void runCommand( char * words[], int count) {
    bool isBackground = false;
    static int backgroundedPID = -1;

    if (strcmp("&", words[count - 1]) == 0) {
        isBackground = true;
        words[count - 1] = NULL;
        count--;
    }

    int pid = fork();

    if (pid == 0) { // If this is the child executing the code
        int errStatus = execvp(words[0], &words[0]);
        if (errStatus == -1) { // If the command was unable to run
            printf("Can't run command %s\n", words[0]);
            exit(0);
        }
        exit(0);
    } else { // Else, must be the parent
        if (isBackground) {
            printf("[%d]\n", pid);
            backgroundedPID = pid;
        } else {
            if (WIFEXITED(0) && backgroundedPID != -1) {
                printf("[%d done]\n", backgroundedPID);
                backgroundedPID = -1;
                wait(0);
            }
            wait(0);
        }
    }
}

int main (int argc, char *argv[]) {
    // While true:
    // Print the prompt and read input
    while (true) { // Breaking out of this loop requires an internal exit() call
        printf("stash> ");

        // Read from stdin until you reach a newline - the array that you put this into is 1024 chars in length plus a newline
        char rawCommand[1026];
        int charsRead = scanf("%1025[^\n]", rawCommand);
        // Consume the newline at the end of the command. We know that there will always be one, because that is the process for entering a command
        getchar();
        // printf("The user typed: \"%s\"\n", rawCommand); // Test code

        // Check if the line was empty. If it was, prompt again by skipping to the top of the loop
        if (charsRead == 0) {
            continue;
        }

        // Pass the read line into parseCommand()
        char *words[514]; // Extra length to allow for null termination
        int numWords = parseCommand(rawCommand, words); // Fills in the words array
        // Based on the first word in the parsed string, run the appropriate command function
        if (strcmp("exit", words[0]) == 0) {
            runExit(words, numWords);
        } else if (strcmp("cd", words[0]) == 0) {
            runCd(words, numWords);
        } else {
            runCommand(words, numWords);
        }
    }

    // We don't actually ever hit this line, but for completeness, it will be included
    exit(EXIT_SUCCESS);
}
