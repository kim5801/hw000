/**
  * @author Natasha Benson
  * @file exclude.c
  * This program reads files and writes a copy but excludes a specified
  * line number
  */

#include <sys/types.h>
#include <fcntl.h>
#include <unistd.h>

/** Number of required arguments when running porgram */
#define ARG_NUM 4
/** Index of output file in argv */
#define OUTPUT_FILE 2
/** Index of excluded line in argv */
#define EXCLUDE_LINE 3
/** Number of bytes processed */
#define BYTE_LIMIT 64
/** Used to convert from char to decimal value */
#define CHAR_TO_DECIMAL 48
/** Bits in a char */
#define CHAR_BITS 8
/** Multiplies value by 10 for decimal number converdion */
#define MULT_BY_TEN 10

/**
  * Copies text from an input file to an output file and
  * excludes a specified line number
  * @param argc number of command line arguments
  * @param argv holds the arguments entered to run program
  * @return exit staus
  */
int main( int argc, char *argv[] ) {

  // Error checking for commnad line args
  char errorMessage[] = "usage: exclude <input-file> <output-file> <line-number>\n";
  if ( argc < ARG_NUM ) {
    write( STDERR_FILENO, &errorMessage, sizeof( errorMessage ) );
    _exit( 1 );
  }


  int numLength = 0; // Length of line number user entered
  int j = 0; // Current index of line number string
  // Ensures the user entered line number in valid format
  while ( argv[ EXCLUDE_LINE ][ j ] != '\0' ) {
    if ( argv[ EXCLUDE_LINE ][ j ] >= '0' && argv[ EXCLUDE_LINE ][ j ] <= '9') {
      numLength++;
    } else {
      write( STDERR_FILENO, &errorMessage, sizeof( errorMessage ) );
      _exit( 1 );
    }
    j++;
  }

  // Changes specified line number from string to decimal value
  int excludeLine = 0;
  int startingValue = 1;
  for ( int i = numLength - 1; i >= 0; i-- ) {
    excludeLine += ( argv[ EXCLUDE_LINE ][ i ] - CHAR_TO_DECIMAL ) * startingValue;
    startingValue *= MULT_BY_TEN;
  }

  /** The input and ouput files */
  int fRead = open( argv[ 1 ], O_RDONLY );
  int fWrite = open( argv[ OUTPUT_FILE ], O_CREAT | O_WRONLY, 0600 );

  char line[ BYTE_LIMIT ];
  // Keeps track of current line number in file
  int currentLineNum = 1;
  int len = read( fRead, line, sizeof( line ) );
  // Reads lines until it reaches EOF
  while ( len > 0 ) {
    for ( int i = 0; i < len; i++ ) {
      // Excludes the specified line
      if ( currentLineNum != excludeLine ) {
        write( fWrite, &line[ i ], 1 );
      }
      if ( line[ i ] == '\n' ) {
        currentLineNum++;
      }
    }
    len = read( fRead, line , sizeof( line ) );
  }

  close( fRead );
  close( fWrite );
  _exit( 0 );
}
