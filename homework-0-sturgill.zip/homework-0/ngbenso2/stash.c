/**
  * @author Natasha Benson
  * @file stash.c
  * This program prompts users for commmands and executes the specified
  * commands
  */

#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <unistd.h>
#include <stdbool.h>
#include <ctype.h>
#include <string.h>

/** Maximum amount of words in command */
#define MAX_WORDS 513
/** Max characters for input */
#define MAX_CHARS 1024
/** Length of temporary buffer */
#define TEMP_SIZE 30
/** Char to decimal value */
#define CHAR_TO_DEC 48
/** Needed words in command */
#define COMMAND_WORDS 2
/** Upper bound for number conversion */
#define DECIMAL_NINE 9
/** Value for computing string of numbers to decimal form */
#define TIMES_TEN 10

/**
  * Parses the words from the user command, adds null termination between each
  * word, and counts the words in the command
  * @param line user command line arguments
  * @param words holds each word of the user command
  * @return number of words in command
  */
int parseCommand( char *line, char *words[] )
{
  int i = 0;
  int wordArrayIndex = 0;
  int wordCount = 0;
  if ( line[ 0 ] != '\n' ) {
    while ( line[ i ] != '\0' ) {
      if ( line[ i ] != ' ' ) {
        int j = i;
        while ( line[ i ] != ' ' && line[ i ] != '\n' ) {
          i++;
        }
        line[ i++ ] = '\0';
        wordCount++;
        while ( line[ i ] == ' ' ) {
          line[ i++ ] = '\0';
        }
        words[ wordArrayIndex ] = &line[ j ];
        wordArrayIndex++;
      } else {
        i++;
      }
    }
  }
  return wordCount;
}

/**
  * Performs exit command with valid arguments
  * @param words
  * @param count
  */
void runExit( char *words[], int count )
{

  if ( count != COMMAND_WORDS || !isdigit( words[ 1 ][ 0 ] ) ) {
    fprintf( stdout, "Invalid command\n" );
  } else{
    bool validNum = true; // Represents if valid number found
    int charCount = 0;
    int i = 0;
    // Gets count of characters in number string
    while ( words[ 1 ][ i ] != '\0' ) {
      charCount++;
      i++;
    }

    int exitStatus = 0;
    int val = 1;
    // Converts string to number
    for ( int i = charCount - 1; i > -1; i-- ) {
      int num = words[ 1 ][ i ] - CHAR_TO_DEC;
      if ( num >= 0 && num <= DECIMAL_NINE ) {
        exitStatus += num * val;
        val *= TIMES_TEN;
      } else {
        validNum = false;
        fprintf( stdout, "Invalid command\n" );
        break;
      }
    }
    if ( validNum ) {
      _exit( exitStatus );
    }
  }
}

/**
  * Performs cd command with valid arguments
  * @param words
  * @param count
  */
void runCd( char *words[], int count )
{
  if ( count != COMMAND_WORDS || chdir( words[ 1 ] ) == -1 ) {
    fprintf( stdout, "Invalid command\n" );
  }
}

/**
  * Performs external commands with valid arguments, function sourced
  * from file forkExecWait.c, located in the Chpater 1 example files
  * @param words
  * @param count
  */
void runCommand( char *words[], int count )
{
  words[ count ] = NULL;
  pid_t id = fork();
  if ( id == 0 ) {
    if ( execvp( words[ 0 ], words ) == -1 ) {
      printf( "Can't run command %s\n", words[ 0 ] );
      exit( 0 );
    }
  } else {
    wait( NULL );
  }
}

/**
  * Interacts with user input to perform built-in and external commands
  * @return exit status
  */
int main()
{
  char command[ MAX_CHARS + 1 ];
  char *words[ MAX_WORDS + 1 ];
  bool run = true;
  do {
    int wordNum = 0;
    printf( "stash> " );
    if ( fgets( command, MAX_CHARS, stdin ) > 0 ) {
      wordNum = parseCommand( command, words );
    }
    if ( strcmp( "cd", words[ 0 ] ) == 0 ) {
      runCd( words, wordNum );
    } else if ( strcmp( "exit", words[ 0 ] ) == 0 ) {
      runExit( words, wordNum );
    } else if ( wordNum > 0 ) {
      runCommand( words, wordNum );
    }
  } while ( run );
  return 0;
}
