/**
    @file stash.c
    @author Christina Albores (ccalbore)
    This is a shell program that reads in lne commands by using parsing and logic
    to execute those commands.
*/
#include <unistd.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

// Max number of arguments for cd() and exit() call
#define MAX_ARGUMENTS 2
// The max length of a line read from input
#define LINE_LENGTH 1024
// The max number of words in an array
#define MAX_WORDS 513


/**
    This function takes in a string and parses its words and puts
    those words into an array of pointers to strings.
    @param line the string to parse
    @param words[] the array of pointers to strings to fill
    @returns the number of words parsed
*/
int parseCommand( char *line, char *words[] )
{
    // The length of the line
    int len = strlen(line);
    
    // If the line is empty immediately return 0
    if (len == 0) {
        return 0;
    }

    // The index where the words starts
    int startWord = 0;
    // Flag for if the current index is on a word
    int onWord = 0;
    // The number of words read
    int wordCount = 0;

    // For each character in the line
    for(int i = 0; i <= len; i++)
    {

        // If the index was on a word and encounters a space or null
      if (onWord == 1 && (line[i] == ' ' || line[i] == '\0')) {
          
          // Replace that whitespace with a null char
          line[i] = '\0';
          // Have the index in words point to the start of that word
          words[wordCount] = &(line[startWord]);
          // Switch to being off a word now
          onWord = 0;
          // Increase the word count
          wordCount++;

      } else if (onWord == 0 && line[i] != ' ') {
          
          //Else if index is not on a word and the char is not a space
          
          // Put the start of the word index here
          startWord = i;
          // Switch flag to say it is on a word now
          onWord = 1;
      }

      // Else just move the index forward

    }
    
    return wordCount;
}


/**
    This function returns the length of the given string.
    @param str the string to convert into an int
    @returns the number or -1 if not a valid word
*/
int stringToInt(char *str)
{
    
    // Keeps track of the place in the number
    int j = 0;
    // Constant for moving one's place
    int moveOnesPlace = 10;
    // The result 
    int sum = 0;
    // Holds a character of the number
    char c = str[j];
    
    while (c != '\0') {
    
        // Return -1 if the string contains a nonnumerical value 
         if ( !(c >= '0' && c <= '9')) {
            return -1;
         }

         // Convert character to its numerical value
         int n = c - '0';
         // Add the digit to the sum
         sum = (sum * moveOnesPlace) + n;
         j++;
         c = str[j];
    }
    return sum;
}

/**
    This function takes in an array of words for a command and the number of 
    words in the array. It them attemps to call the exit() call.
    @param words array of points to strings. Contains the words
    of the command
    @param count the number of words in the array
*/
void runExit( char *words[], int count )
{
    // If the number of arguments is not exactly 2, print an error and reprompt
    if (count != MAX_ARGUMENTS) {
        printf("Invalid command\n");
    } else {
        // Else call the stringToInt() method to convert the string into an int
        int status = stringToInt(words[1]);

        // If the function could not convert to an int, print an error and reprompt
        if (status == -1) {
            printf("Invalid command\n");
        } else {
            // Use exit() function with given number
            exit(status);
        }
        
    }
}


/**
    This function takes in an array of words for a command and the number of 
    words in the array. It them attemps to call the cd() call.
    @param words array of points to strings. Contains the words of the command
    @param count the number of words in the array
*/
void runCd( char *words[], int count )
{
    // If the number of arguments is not exactly 2, print an error and reprompt
    if (count != MAX_ARGUMENTS) {
        printf("Invalid command\n");
    } else {
        // chdir returns -1 if unable to find the file path
        int rtn = chdir(words[1]);
    
        // If the function could not cd to the path, print an error and reprompt
        if (rtn == -1) {
            printf("Invalid command\n");
        }
    }
}

/**
    This function takes in an array of words for a command and the number of 
    words in the array. It them attemps to call the designated command call.
    @param words array of points to strings. Contains the words of the command
    @param count the number of words in the array
*/
void runCommand( char *words[], int count )
{
    // Create a new child process
    int pid = fork();
    
    // If creating a child process fails, print an error message
    if ( pid == -1 ) {
        printf( "Can't create child process" );

    } else if ( pid == 0 ) {

        // Else if the child, 

        // Add a NULL character after the last word in the array
        words[count] = NULL;

        // The status of the execvp call
        int status = execvp(words[0], words);
        
        // If the function could not execute the command, print an error and reprompt
        if (status == -1) {
            printf("Can't run command %s\n", words[0]);
        }

        exit(0);
        
    } else {
        
        // If the parent process, wait for the child to exit
        wait(NULL);
    }
}

/**
    This function reads a line from standard input and returns the string.
    @param fp the stream to read from
    @param str the string to return
*/
void readLine(FILE *fp, char *str)
{
    /** The max length of the string */
    int cap = LINE_LENGTH;
    /** The length of the string */
    int len = 0;
    
    /** The character from the input */
    int ch = fgetc(fp);

    // While the character is not a newline
    while (ch != '\n' && len < cap) {
    
        
        // Add character to the string
        str[len++] = ch;
        ch = fgetc(fp);
    }
    
    // Add null character to the end
    str[len++] = '\0';
}


/** 
    Program starting point, reads commands from standard input until the user
    calls the exit function.
    @param argc number of command-line arguments.
    @param argv list of command-line arguments.
    @return program exit status
*/
int main(int argc, char *argv[])
{
    // The message prompt string
    char *stashMsg = "stash> ";
    // The number of words read in from input
    int numWords = 0;
    // Array of points to strings with the size of 513
    char *wordArray[MAX_WORDS];
   
    // The line to read in, limit of 1024 characters long
    char line[LINE_LENGTH];

    // Print the first prompt and read in the first line
    printf("%s", stashMsg);
    readLine(stdin, line);


    // While the line is not NULL (This is a continuous cycle. Can't exit until the 
    // user exits).
    while (line != NULL) {
        
        // Parase the line and return the number of words
        numWords = parseCommand(line, wordArray);

        // If the first word in the array (the command) matches cd,
        // exit, or another command, go to its designated function
        if (strcmp(wordArray[0], "cd") == 0) {
            
            runCd(wordArray, numWords);
            
        } else if (strcmp(wordArray[0], "exit") == 0) {
            
            runExit(wordArray, numWords);
            
        } else if (numWords != 0) {
            
            runCommand(wordArray, numWords);
            
        } else {
            // If an empty prompt ignore and reprompt
            printf("\n");
        }

        //Print the prompt message and intake another line
        printf("%s", stashMsg);
        readLine(stdin, line);
    }
  
   return 0;
}