/**
    @file exclude.c
    @author Christina Albores (ccalbore)
    This program sets removes a sentence line from the file given. The number provided
    by the user is the line that is removed. 
*/
#include <unistd.h>
#include <fcntl.h>
#include <sys/stat.h>


// Max number of arguments argc
#define MAX_ARGUMENTS 4
// The max length of a line 
#define LINE_LENGTH 64

/**
    This function returns the length of the given string.
    @param string the string to get the length of
    @returns length of the string
*/
static int stringLength(char *string)
{
    // Length of the string
    int len = 0;
    // While the character is not null,
    // move through the string and increase the length
    while (string[len] != '\0') {
        len++;
    }
    return len;
}

/**
    Program starting point, reads commands from standard input and uses them
    too remove the desired line from the file.
    @param argc number of command-line arguments.
    @param argv list of command-line arguments.
    @return program exit status
*/
int main(int argc, char *argv[])
{
    // Make sure the correct number of arguments was given.
    // Write to standard error and exit if so.
    char *msg = "usage: exclude <input-file> <output-file> <line-number>\n";
    int lenFile = stringLength(msg);
    if (argc != MAX_ARGUMENTS ) {
        write(STDERR_FILENO, msg, lenFile);
        _exit(1);
    }

    // Command-line arguments would be invalid if the user didn’t provide the right number of
    // arguments, if the last argument wasn’t a positive integer or if the program couldn’t
    // open one of the given files.
    char *msgError = "Error: Invalid arguments, can't open files, or problem reading/writing to a file\n";
    int len = stringLength(msgError);

    
    // Convert last argument from string to numerical form

    // Keeps track of the place in the number
    int j = 0;
    // Constant for moving one's place
    int moveOnesPlace = 10;
    // The result 
    int sum = 0;
    // Holds a character of the number
    char c = argv[MAX_ARGUMENTS - 1][j];

    // While there are still characters, convert the character to a digit
    while (c != '\0') {
    
    // Call an error and exit if the string contains a '-' or letter 
     if ( c == '-' || (c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z')) {
         write(STDERR_FILENO, msgError, len);
        _exit(1);
     }

     // Convert character to its numerical value
     int n = c - '0';
     // Add the digit to the sum
     sum = (sum * moveOnesPlace) + n;
     j++;
     c = argv[MAX_ARGUMENTS - 1][j];
 }


    // Make sure the files open. If they do not call an error and exit
    int fileOpen = open(argv[1], O_CREAT | O_RDONLY);
    if (fileOpen < 0) {
        write(STDERR_FILENO, msgError, len);
        _exit(1);
    }

    int fileWrite = open(argv[2], O_CREAT | O_WRONLY, 0600);
    if (fileWrite < 0) {
        write(STDERR_FILENO, msgError, len);
        _exit(1);
    }

    // Statically allocated buffer of 64 bytes
    char buffer[LINE_LENGTH];

    // Read in 64 or less bytes from the file. Keeps track of how many bytes have been read in.
    int rSize = read(fileOpen, buffer, LINE_LENGTH);
    // Keeps track of how many new line characters there have been
    int lineCount = 0;
    // When skipFlag is 0, the character should be written to the file. If 1 then it is skipped.
    int skipFlag = 0;
    // The number of bytes which were written.
    int wSize = 0;

    // While not at EOF, read in blocks of 64 bytes and skip the provided line number
    while (rSize != 0) {
        // Call and error and exit if there is a problem reading the file
        if (rSize == -1) {
            write(STDERR_FILENO, msgError, len);
            _exit(1);;
        }

        // For each character in the buffer, count the new lines and write characters.
        // Skip characters that are a part of the skipped line segment.
        for (int i = 0; i < rSize; i++) {
            
            // If the character is a new line, increase the lineCount variable.
            if (buffer[i] == '\n') {
                lineCount++;
            }
            
            // If skipFlag is 0, write the character
            if (skipFlag == 0) {
                wSize = write(fileWrite, &buffer[i], 1);
                // Call an error and exit if there is a problem writing to the file
                if (wSize == -1) {
                    write(STDERR_FILENO, msgError, len);
                  _exit(1);
                }
            }
            
            // If the lineCount variable is at the start of the skipped line segment, change
            // skipFlag to 1. If lineCount is at the end of the skipped line segment, change
            // skipFlag to 0.
            if (lineCount == (sum - 1) && buffer[i] == '\n') {
                skipFlag = 1;
            } else if (lineCount == sum && buffer[i] == '\n') {
                skipFlag = 0;
            }
        }
        
        // Read in 64 or less bytes from the file
        rSize = read(fileOpen, buffer, LINE_LENGTH);
        if (fileWrite < 0) {
            write(STDERR_FILENO, msgError, len);
            _exit(1);
        }
    }

    //Close files
    close(fileOpen);
    close(fileWrite);

    return 0;
}