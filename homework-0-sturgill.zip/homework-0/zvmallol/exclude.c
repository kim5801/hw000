/**
 * @file exclude.c
 * @author Zachary Mallol
 * 
 * This program takes three arguments from the command line - an input file,
 * an output file, and a positive integer. It then copies each line from the input
 * file into the output file with the exception of the line number given by the user
 * in the third argument.
 */
#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>

/**
 * How many bytes should be read from a file at a time
 */
#define BYTES_TO_READ 64

/**
 * Expected number of arguments
 */
#define ARG_NUM 4

/**
 * Program failed
 */
#define EXIT_FAILURE 1

/**
 * Program succeeded
 */
#define EXIT_SUCCESS 0
/**
 * Converts the given string to an integer. It is only possible
 * to convert positive integers.
 * 
 * @param str String to convert
 * @return int String as an integer, -1 if an error occurs.
 */
int stringToInteger(char str[]) {
    // Initialize num, i, and first character
    int num = 0;
    int i = 0;
    char ch = str[0];
    // While ch is not the null terminator, go through string and add
    // to num
    while(ch != '\0') {
        num *= 10;
        if(ch >= '0' && ch <= '9') {
            num += ch - '0';
        }
        else {
            // Character could not be read so return -1 (error)
            return -1;
        }
        i++;
        ch = str[i];
    }

    return num;
}

/**
 * Buffer of characters read from input file. Statically allocated
 * due to constraints placed by the assignment.
 */
char buffer[BYTES_TO_READ];

/**
 * Copies lines from an input file to an output file, excluding
 * the given line 
 * 
 * @param argc Number of args
 * @param argv Array of args strings
 * @return Exit status
 */
int main( int argc, char *argv[] ) {
    // Check for correct # of arguments
    if(argc != ARG_NUM) {
        write(STDERR_FILENO, "usage: exclude <input-file> <output-file> <line-number>\n", 64);
        _exit(EXIT_FAILURE);
    }

    // Open input file for reading and check if it can be opened
    int input = open(argv[1], O_RDONLY);
    if(input == -1) {
        write(STDERR_FILENO, "usage: exclude <input-file> <output-file> <line-number>\n", 64);
        _exit(EXIT_FAILURE);
    }

    // Open output file for writing and check if it can be opened
    int output = open(argv[2], O_WRONLY | O_CREAT | O_TRUNC, 0600);
    if(output == -1) {
        // Close open files
        close(input);
        write(STDERR_FILENO, "usage: exclude <input-file> <output-file> <line-number>\n", 64);
        _exit(EXIT_FAILURE);
    } 

    // Convert third argument to an integer
    // Check third arguments validity here too
    int lineNum = stringToInteger(argv[3]);
    if(lineNum < 1) {
        close(input);
        close(output);
        write(STDERR_FILENO, "usage: exclude <input-file> <output-file> <line-number>\n", 64);
        _exit(EXIT_FAILURE);
    }

    // Start copying from in file to out file
    int bytesRead = read(input, buffer, BYTES_TO_READ);
    int newLines = 0;
    while(bytesRead > 0) {
        for(int i = 0; i < bytesRead; i++) {
            if(buffer[i] == '\n' || buffer[i] == '\r') {
                newLines++;
            }
            // Ensures output on user specified line is not copied
            // There is a special case where excluding the first line leaves behind a blank line,
            // which the second part of the condition solves. Essentially the second half says
            // "Do not do this if the character is a new line, AND the new line count is equal to the exclusion line,
            // AND the first line is to be excluded"
            if(newLines != lineNum - 1 && 
                !((buffer[i] == '\n' || buffer[i] == '\r') && newLines == lineNum && lineNum == 1)) {
                write(output, &buffer[i], 1);
            }
        }
        bytesRead = read(input, buffer, BYTES_TO_READ);
    }
    
    // CLOSE THE FILES!!
    close(input);
    close(output);
    _exit(EXIT_SUCCESS);
}
