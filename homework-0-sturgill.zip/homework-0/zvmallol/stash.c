/**
 * @file stash.c
 * @author Zachary Mallol
 * 
 * Stash, or the Simple Toy Assignment SHell, is a basic command line
 * interpreter which uses system calls to start new programs and has some
 * built in features.
 */
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <stdbool.h>
#include <errno.h>
#include<sys/wait.h>
#include <unistd.h>
#include <ctype.h>

/**
 * Max size of words array
 */
#define WORDS_LEN 513

/**
 * Max line length (bytes). 1024 (max line length) plus 2 for null terminator
 * and an extra character
 */
#define LINE_LEN 1026
/**
 * Takes a user command (line as input), breaks the line into individual
 * words, adds null termination between the words, and it fills in a pointer
 * in the words array to the start of each word.
 * 
 * @param line User command to parse
 * @param words Array of pointers to each word
 * @return int Number of words found in each line
 */
int parseCommand( char line[], char *words[] ) {
    // Length of the line string
    int len = strlen(line);
    // Where we're at in the line string
    int pos = 0;
    // How many words have been added to the words array
    int numWords = 0;
    while(pos < len) {
        // Skips all space until we hit a word
        // Also replaces space with null terminators rather than selecting
        // individual spots for the null terminators
        while(isspace(line[pos])) {
            line[pos] = '\0';
            pos++;
        }
        // If we haven't hit the end of the string yet, put the pointer to
        // the current word in the words array
        if(line[pos] != '\0') {
            words[numWords] = &line[pos];
            numWords++;
        }
        // Start skipping ahead again until we find some white space
        while(!isspace(line[pos])) {
            pos++;
        }
    }
    return numWords;
}

/**
 * Performs the built in exit command
 * 
 * @param words List of pointer to words in user's command
 * @param count Number of words in array
 */
void runExit( char *words[], int count ) {
    // Check for too many/too few args
    if(count != 2) {
        printf("Invalid command\n");
        return;
    }
    int exitStatus;
    int match = sscanf(words[1], "%d", &exitStatus);
    // Ensures the user gave a valid integer for the exit status
    if(match != 1) {
        printf("Invalid command\n");
        return;
    }
    _exit(exitStatus);

}

/**
 * Runs the built in cd command
 *  
 * @param words List of pointers to words in user's command
 * @param count Number of words in array
 */
void runCd( char *words[], int count ) {
    // Check for too few/too many arguments
    if(count != 2) {
        printf("Invalid command\n");
        return;
    }
    int rtn = chdir(words[1]);
    // Check if there was an error, if so print invalid
    if(rtn == -1) {
        printf("Invalid command\n");
    }
}

/**
 * Runs any non built in commands by creating a child process and calling
 * execvp()
 * 
 * @param words List of pointers to words in user's command
 * @param count Number of words in array 
 */
void runCommand( char *words[], int count ) {
    // Get the process id and fork into a child process
    int pid = fork();
    // pid 0 for child process --
    // run the command and print an error message if needed
    if(pid == 0) {
        int err = execvp(words[0], words);
        if(err == -1) {
            printf("Can't run command %s\n", words[0]);
            _exit(EXIT_FAILURE);
        }
        _exit(EXIT_SUCCESS);
    }
    // parent process should wait patiently for child
    else {
        wait(NULL);
        return;
    }
    
}

/**
 * Gets the user command from stdin and stores it in the line
 * 
 * @param line Where to store the user input
 */
void getUserCommand(char line[]) {
    printf("stash> ");
    fgets(line, LINE_LEN, stdin);
}

int main( int argc, char *argv[] ) {
    // Initialize all variables
    char *words[WORDS_LEN];
    bool run = true;

    // Start while loop to get input from user
    while(run) {
        char line[LINE_LEN + 1];
        int numWords = 0;

        getUserCommand(line);

        // Run parseCommand() to break line into words
        numWords = parseCommand(line, words);

        // Check built in commands
        // cd
        if(numWords > 0 && strcmp(words[0], "cd") == 0) {
            runCd(words, numWords);
        }
        
        // exit
        else if(numWords > 0 && strcmp(words[0], "exit") == 0) {
            runExit(words, numWords);
        }

        // Run non built-in command
        else if(numWords > 0) {
            // Last part of array must be NULL for execvp
            words[numWords] = NULL;
            runCommand(words, numWords);
        }
        // If command is blank while loop will go around again
        // This loop is deliberately an infinite loop because the interrupt
        // condition is using the "exit" command
    }
}
