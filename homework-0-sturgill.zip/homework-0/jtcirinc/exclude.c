/**
 * @file exclude.c
 * @author your name (you@domain.com)
 * @brief 
 * @version 0.1
 * @date 2022-08-26
 * 
 * @copyright Copyright (c) 2022
 * 
 */
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>

/**
 * Converts a string to an integer
 * @param arr character array to be converted
 * @return int the number converted from the string
 */
int stringToInteger(char *arr) {
    char errMsg[] = "usage: exclude <input-file> <output-file> <line-number>\n";
    //size of the string at its current location
    int size = 0;
    //this loop iterates through each individual character in the string
    for(int i = 0; arr[i] != '\0'; i++) {
        if (arr[i] < '0' || arr[i] > '9') {
            write(STDERR_FILENO, errMsg, sizeof(errMsg));
            _exit(1);
        }
        //updates the size of the string from left to right, multiplying by 10 when another number is added.
        size = size * 10 + arr[i] - '0';
    }
    return size;
}

/**
 * 
 * @param argc number of command-line arguments
 * @param argv array of command-line arguments
 * @return int 0 upon success
 */
int main( int argc, char *argv[] ) {

    // Buffer we're going to write to the file, one character at a time.
    char buffer[64];
    // Create an output file for writing.
    //   FILE *fp = fopen( "output.txt", "w" );
    int fd = open(argv[1], O_RDONLY);
    
    //open a file for writing
    int fp = open(argv[2], O_WRONLY | O_CREAT | O_TRUNC, 0600);
    char errMsg[] = "usage: exclude <input-file> <output-file> <line-number>\n";

    if (fd < 0) {
        write(STDERR_FILENO, errMsg, sizeof(errMsg));
        _exit(1);
    }
    //line to exclude
    int lineExclude = stringToInteger(argv[3]);
    

    int size = 1;
    int lineCount = 1;
    while(size > 0) {
        size = read(fd, buffer, 64);
        for(int i = 0; i < size; i++) {
            if(lineCount != lineExclude) {
                 write(fp, &buffer[i], 1);
            }
            if (buffer[i] == '\n') {
                lineCount++;
            }
        }
    }
  
    close(fp);
    close(fd);
    _exit(0);
}

