/**
 * @file stash.c
 * @author your name jtcirinc
 * @brief Simple shell program
 * @version 0.1
 * @date 2022-09-01
 * 
 * @copyright Copyright (c) 2022
 * 
 */
#include <sys/types.h>
#include <sys/wait.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>
#include <string.h>
#include <stdbool.h>
#include <stdio.h>
#include <ctype.h>
#include <stdlib.h>

/**
 * Parses a command given by a user into an array of character pointers
 * 
 * @param line line of user input
 * @param words pointer array to be filled
 * @return int the number of parsed commands
 */
int parseCommand( char *line, char *words[] )
{
    int firstLetterIdx = 0;
    //TODO: make a case for an empty string 

    char *ptr = line;
    // printf("%s", line);
    int i = 0;
    int wordCount = 0;
    while (*ptr) {
        if (line[i] == ' ') {
            line[i] = '\0';
            //if character directly after the space is not a space
            if (line[i + 1] != ' ') {
                words[wordCount] = &line[firstLetterIdx];
                wordCount++;
                //set the index of the first letter to the character directly after the space
                firstLetterIdx = i + 1;
            }
        }
        else if (line[i + 1] == '\0') {
            words[wordCount] = &line[firstLetterIdx];
            wordCount++;
        }
        i++;
        ptr++;
    }
    words[wordCount] = NULL;
    
    // printf("%s", words[2]);
    // printf("%d", wordCount);
    return wordCount;
}

/**
 * Runs a given command from the user via the execvp system call
 * 
 * @param words pointer array of user input
 * @param count number of words in the input
 */
void runCommand( char *words[], int count )
{
    pid_t pid = fork();
    if (pid == -1) {
        fprintf(stderr, "%s", "Could not create child process.");
    }
    if (pid == 0) {
       int ret = execvp(words[0], words);
       if (ret == -1) {
            fprintf(stderr, "Invalid command %s\n", words[0]);
            // return;
            exit(EXIT_SUCCESS);
       }

    }
    else {
        wait(NULL);
    }
}

/**
 * When the user enters the exit command, this method runs the _exit system call and checks for valid args
 * 
 * @param words pointer array of user input
 * @param count number of commands
 */
void runExit(char *words[], int count)
{

    bool invalid = false;
    //if there are not 2 elements in input
    if (count != 2) {
        fprintf(stderr, "Invalid command\n");
        return;
    }
    else {
        //the status from the second command of user input
        int status = atoi(words[1]);
        if (status == 0) {
            for (int i = 0; i < strlen(words[1]); i++) {
                if (words[1][i] != '0') {
                    invalid = true;
                }
            }
            if (invalid) {
                fprintf(stderr, "Invalid command\n");
                return;
            }
            else {
                exit(status);
            }
        }
        else {
            //exit with the given status
            _exit(status);
        }
        
    }
}

/**
 * @brief runs the cd command using chdir system call
 * 
 * @param words pointer array of user input
 * @param count number of commands
 */
void runCd( char *words[], int count )
{
    int ret = chdir(words[1]);

    if (count != 2 || ret == -1) {
        fprintf(stderr, "Invalid command");
    }
}

/**
 * Loops through user input and calls functions
 * 
 * @param argc number of command line arguments
 * @param argv array of command line arguments
 * @return int 0 upon success
 */
int main(int argc,char *argv[]) {
    bool hi = true;
    while (hi) {
        printf("stash> ");
        //buffer of user input
        char buffer[1024];
        //index for each array within the pointer array of input
        // int len = read(STDIN_FILENO, buffer, sizeof(buffer));
        char temp[1025];
        //character array with a maximum of 513 words
        char *arr[513];

        memset(buffer, 0, sizeof buffer);
        memset(arr, 0, sizeof arr);
        memset(temp, 0, sizeof temp);
            char c;
            int charCount = 0;
            while ((c = getchar()) != '\n') {
                buffer[charCount] = c;
                charCount++;
            }

        if (charCount > 0) {

            //loop through user input
            for(int i = 0; i < charCount; i++) {
                // if (i == charCount) {
                //     temp[i] = buffer[i - 1];

                //     temp[i + 1] = '\0';
                // }
                // else {
                    temp[i] = buffer[i];
                // }
            }

            temp[charCount + 1] = '\0';
            int count = parseCommand(temp, arr);
            if (strcmp(arr[0], "exit") == 0) {
                runExit(arr, count);
            }
            else if (strcmp(arr[0], "cd\0") == 0) {
                runCd(arr, count);
            }
            else {
                runCommand(arr, count);

            }

        }
        


        
    }
    
    return 0;
}