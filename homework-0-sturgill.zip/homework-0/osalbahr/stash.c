/**
 * This program, stash (simple toy assignment shell) emulates
 * basic shell functionality. It can change directory with one
 * argument, exit with a specified status, and delegate to libc
 * to try to execute anything else.
 *
 * @file stash.c
 * @author Osama Albahrani (osalbahr)
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>
#include <ctype.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>

/** Maximum input line length */
#define MAX_LINE_LENGTH 1024

/** Maximum possible words in a 1024-character line + 1 for NULL */
#define MAX_WORDS ( MAX_LINE_LENGTH / 2 + 1 )

/**
 * Counts whitespace from the current location
 * to the next whitespace i.e. the gap in between
 * 
 * @param line the start of counting whitespace
 * @return the amount of whitespace, or -1 if at the end
 */
int countGap( char *line )
{
  int gap = 0;
  while ( isspace( *line ) ) {
    line++;
    gap++;
  }

  return *line == '\0' ? -1 : gap;
}

/**
 * Measures the length of the given word. In contrast to
 * to strlen which stops at the null-terminator,
 * this function stops at whitespace or null-terminator.
 * 
 * @param word the word to be measured
 * @return the length of the word
 */
int wordlen( char *word )
{
  int len = 0;
  while ( *word && !isspace( *word ) ) {
    word++;
    len++;
  }
  return len;
}

/**
 * Parses the line, null-terminating the words,
 * and fills in the words array of pointers.
 * 
 * @param line the line to be parsed
 * @param words the array of poinetrs
 * @return the word count
 */
int parseCommand( char *line, char *words[] )
{
  int wc = 0;
  int gap;
  
  while( ( gap = countGap( line ) ) != -1 ) {
    line += gap;
    words[ wc++ ] = line;
    line += wordlen( line );
    if ( ( *line ) == '\0' ) {
      break;
    }
    *( line++ ) = '\0';
  }
  words[ wc ] = NULL;
  return wc;
}

/** Prints the invalid command message */
void invalidCommand()
{
  printf( "Invalid command\n" );
}

/**
 * Runs the exit command
 * 
 * @param words the input line
 * @param count the word count of the input line 
 */
void runExit( char *words[], int count )
{
  if ( count != 2 ) {
    invalidCommand();
    return;
  }

  int status;
  char ch;
  if ( sscanf( words[ 1 ], "%d%c", &status, &ch ) != 1 ) {
    invalidCommand();
    return;
  }

  exit( status );
}

/**
 * Runs the cd command
 * 
 * @param words the input line
 * @param count the word count of the input line 
 */
void runCd( char *words[], int count )
{
  if ( count != 2 || chdir( words[ 1 ] ) == -1 ) {
    invalidCommand();
  }
}

/**
 * Checks whether the current input satisfies
 * the extra credit, by checking for the &,
 * the removes it
 * 
 * @param words the input line
 * @param count the word count of the input line 
 * @return true if extra credits, false otherwise
 */
bool checkEc( char *words[], int count )
{
  bool ec = false;
  if ( strcmp( words[ count - 1 ], "&" ) == 0 ) {
    words[ count - 1 ] = NULL;
    ec = true;
  }
  return ec;
}

/**
 * Attempts to run an arbitrary command from the user
 * 
 * @param words the input line
 * @param count the word count of the input line 
 */
void runCommand( char *words[], int count )
{
  pid_t release;
  while ( ( release = waitpid( -1, NULL, WNOHANG ) ) > 0 ) {
    printf( "[%d Done]\n", release );
  }
 
  bool ec = checkEc( words, count );
  pid_t pid = fork();

  if ( pid == 0 ) {
    execvp( words[ 0 ], words );
    invalidCommand();
    exit( EXIT_SUCCESS );
  } else if ( ec ) {
    printf( "[%d]\n", pid );
    return;
  }
  
  wait( NULL ); // wait if not EC
}

/**
 * Starting point of the program
 * 
 * @return EXIT_SUCCESS at the end of program execution
 */
int main()
{
  char line[ MAX_LINE_LENGTH + 1 ];
  printf( "stash> " );
  while ( fgets( line, MAX_LINE_LENGTH, stdin ) != NULL ) {
    char *words[ MAX_WORDS ];
    int count = parseCommand( line, words );
    if ( count == 0 ) {
      printf( "stash> " );
      continue;
    }

    if ( strcmp( words[ 0 ], "exit" ) == 0 ) {
      runExit( words, count );
    } else if ( strcmp( words[ 0 ], "cd" ) == 0 ) {
      runCd( words, count );
    } else {
      runCommand( words, count );
    }

    printf( "stash> " );
  }

  return EXIT_SUCCESS;
}
