/**
 * This program writes out the content of a text file, excluding a
 * specified line, using purely c code and system calls.
 *
 * @file exclude.c
 * @author Osama Albahrani (osalbahr)
 */

#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>

// Since I cannot use headers I'll create the macros myself
#define true 1
#define false 2
#define EXIT_SUCCESS 0

/** Prints the usage message and exit unsuccessfully */
void usage()
{
  char str[] = "usage: exclude <input-file> <output-file> <line-number>\n";
  int len = sizeof( str ) / sizeof( str[ 0 ] );
  write( STDERR_FILENO, str, len );
  _exit( 1 );
}

/**
 * Returns the length of the given string
 * 
 * @param str the string to be measured
 * @return the length of the given string 
 */
int myStrlen( char *str )
{
  int len = 0;
  while ( *( str++ ) ) {
    len++;
  }
  return len;
}

/**
 * Converts a '0' - '9' character to its integer representatiom
 * 
 * @param ch the character to be converted
 * @return the integer representatiom
 */
int ctoi( char ch )
{
  return ch - '0';
}

/**
 * Checks whether the given string represents a non-negative integer
 *
 * @param str the string to be examined
 * @return true if valid, false otherwise
 */
_Bool isValidNumber( char *str )
{
  for (; *str; str++ ) { // This is secretly while( *(str++) )
    char ch = *str;
    if ( ch < '0' || ch > '9' ) {
      return false;
    }
  }
  return true;
}

/**
 * Converts an array of characters (string) to a non-negative integer
 * 
 * @param str the string to be converted
 * @return the integer if valid, -1 if not
 */
int atoi( char *str )
{
  if ( !isValidNumber( str ) ) {
    return -1;
  }

  int val = 0, len = myStrlen( str );
  for ( int i = 0; i < len; i++ ) {
    val *= 10;
    val += ctoi( str[ i ] );
  }

  return val;
}

/**
 * Returns the length of the given line, counting the newline
 *
 * @param line the line to be measured
 * @param size how far ahead to look
 * @return the length of the line,
            or -1 if there is no newline character
 */
int lineLen( char *line, int size )
{
  for ( int i = 0; i < size; i++ ) {
    if ( *( line++ ) == '\n' ) {
      return i + 1; // since i is the index
    }
  }
  return -1;
}

/**
 * Writes the given block, except if it contains the excluded line
 * 
 * @param outfd output file descriptor
 * @param buf buffer to be written
 * @param size size of the current block
 * @param excludedLine the line to exclude
 * @param lineCounter the current line, counting from 1
 */
void writeBlock( int outfd, char buf[ 64 ], int size, // write() args
                int excludedLine, int *lineCounter ) // exclude args
{
  // Nevermind
  if ( size == 0 ) {
    return;
  }

  // Already excluded, no worries
  if ( *lineCounter > excludedLine ) {
    write( outfd, buf, size );
    return;
  }

  // Not there yet
  if ( *lineCounter < excludedLine ) {
    int len = lineLen( buf, size );
    if ( len == -1 ) {
      write( outfd, buf, size );
    } else {
      (*lineCounter)++;
      write( outfd, buf, len ); // Write up to the \n then delegate the rest
      writeBlock( outfd, buf + len, size - len, excludedLine, lineCounter );
    }
    return;
  }

  // We are there!
  int len = lineLen( buf, size );
  if ( len != -1 ) {
    (*lineCounter)++; // Skip up to the \n then write the rest
    write( outfd, buf + len, size - len );
  } // else just skip this block
}

/**
 * Starting point of the program
 * 
 * @param argc arg count
 * @param argv arg vector
 * @return EXIT_SUCCESS at the end of program execution
 */
int main( int argc, char *argv[] )
{
  if ( argc != 4 ) {
    usage();
  }
  
  int infd = open( argv[ 1 ], O_RDONLY );
  if ( infd == -1 ) {
    usage();
  }

  int outfd = creat( argv[ 2 ], 0600 );
  if ( outfd == -1 ) {
    usage();
  }

  int excludedLine = atoi( argv[ argc - 1 ] );
  if ( excludedLine <= 0 ) {
    usage();
  }

  char buf[ 64 ];
  int length, lineCounter = 1;
  while( ( length = read( infd, buf, 64 ) ) > 0 ) {
    writeBlock( outfd, buf, length, excludedLine, &lineCounter );
  }

  return EXIT_SUCCESS;
}
