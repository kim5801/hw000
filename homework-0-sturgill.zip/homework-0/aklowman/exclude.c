/** 
 *    @file exclude.c
 *    @author Annie Lowman aklowman
 *    Program that will take a given file and a given line numnber
 *    and remove that given line number from the given file in the output
 */
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>


/** 
 *    Main function to excecute the program
 *
 *    @param argc number of command line arguments
 *    @param argv list of command line arguments
 */
int main( int argc, char *argv[] ) 
{
    if ( argc != 4 ) {
       write( STDERR_FILENO, "usage: exclude <input-file> <output-file> <line-number>\n", 56);
        _exit(1);
    }
    int input = open( argv[ 1 ], O_RDONLY );
    if ( input == -1 ) {
      write( STDERR_FILENO, "usage: exclude <input-file> <output-file> <line-number>\n", 56);
        _exit(1);
    }
    int output = open( argv[ 2 ],  O_WRONLY|O_CREAT|O_TRUNC, 0666);
    if ( input == -1 ) {
        write( STDERR_FILENO, "usage: exclude <input-file> <output-file> <line-number>\n", 65);
        _exit(1);
    }
    
    
    char *lineNum = argv[3];
    int i = 0;
    int valid = 1;
    while ( lineNum[i] != '\0' )  {
        char ch = lineNum[i];
        if ( ch < '0' || ch > '9' ) { 
            valid = 0;
            
        }
        i++;
    } 
    if ( valid == 0 ) {
       write( STDERR_FILENO, "usage: exclude <input-file> <output-file> <line-number>\n", 56);
        _exit(2);
    }
    i--;
    int excludeLine = 0;
    for ( int len = i; len >= 0; len-- ) {
        int add = lineNum[ len ] - '0';
        for ( int j = len; j < i; j++ ) {
            add = add * 10;
        }
        excludeLine += add;
    }
    
    char buffer[64];
    int numRead = read(input, buffer, 64);
    int line = 1;
    while (numRead != 0) {
        for ( int i = 0; i < numRead; i++ ) {
            char ch = buffer[i];
            if ( line != excludeLine ) {
                write( output, &buffer[i], 1 );
            }
            if (ch == '\n') {
                line++;
            }
        }
        numRead = read(input, buffer, 64);
    }
    close(input);
    close(output);
    return 0;
    
}