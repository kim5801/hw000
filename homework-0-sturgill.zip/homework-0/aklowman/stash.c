/** 
 *    @file stash.c
 *    @author Annie Lowman aklowman
 *    Program to act as a terminal when user and give different commands
 *    that the system will execute
 */
#include <stdio.h>
#include <stdbool.h>
#include <unistd.h>
#include <string.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/wait.h>
/** */
#define LINE_MAX 1025
/** */
#define WORD_MAX 514

/** 
 * Function to take the users command and seperate it into individual words and count those words
 * @param line users input line
 * @param words array to store the reference to the begining of each individual word
 * @return number of words the user input
 */
int parseCommand( char *line, char *words[] )
{
    int len = strlen(line);
    if (len == 0) {
        return 0;
    }
    int spaces = 0;
    for ( int i = 0; i < len; i++) {
        if (line[i] == ' ') {
            spaces++;
            line[i] = '\0';
        }
        if (line[i] == '\n') {
            line[i] = '\0';
        }
    }
    if (len == spaces) {
        return 0;
    }

    int numWords = 0;
    for (int i = 0; i < len; i++ ) {
        while (line[0] == '\0' && i < len) {
            i++;
            line++;
        }
        if ( i < len ) {
            int wordLen = strlen(line);
            words[numWords] = &(line[0]);
            i += wordLen - 1;
            for ( int j = 0; j < wordLen; j++ ) {
                line++;
            }
            numWords++;
        }
        
    }
    return numWords;
}

/** 
 * Function to run system exit commands
 * @param words list of the command and arguments given by the user
 * @param count number of words user gave in their command
 */
void runExit( char *words[], int count )
{
    bool valid = true;
    if ( count != 2 ) {
        valid = false;
    }
    int num;
    int match = sscanf( words[1], "%d", &num);
    if (match == 0) {
        valid = false;
    }
    if ( !valid ) {
        printf("Invalid command\n");
    }
    else {
        _exit(num);
    }
}

/** 
 * Function to run system change directories command
 * @param words list of the command and arguments given by the user
 * @param count number of words user gave in their command
 */
void runCd( char *words[], int count )
{ 
    bool valid = true;
    if (count != 2) {
        valid = false;
    }   
    int result = chdir( words[1] );
    if ( result == -1 ) {
        valid = false;
    }
    if ( !valid ) {
         printf("Invalid command\n"); 
    }
}

/** 
 * Function to run any other system call given by forking and 
 * then waiting for the child to finish executing
 * @param words list of the command and arguments given by the user
 * @param count number of words user gave in their command
 */
void runCommand( char *words[], int count )
{
    int pid = fork();
    if ( pid == 0 ) {
        words[count] = NULL;
        int result = execvp(words[0], words);
        if (result == -1) {
            printf("Can't run commmand %s\n", words[0]);
        }
        exit(0);
    }
    else {
        wait(NULL);
    }
    
}


/** 
 * Main function to read in input from the user and decide what command to execute
 */
int main() 
{
    while ( true ) {
        printf("stash> ");
        char *line = (char *) malloc( sizeof(char) * LINE_MAX);
        fgets( line, LINE_MAX, stdin );
        char **words = (char **) malloc( sizeof(char *) * WORD_MAX);
        int numWords = parseCommand( line, words );
        if (numWords == 0 || strlen(line) == 0) {
            // loop again
        }
        else if (strcmp("exit", words[0]) == 0) {
        runExit(words, numWords);
        }
        else if (strcmp("cd", words[0]) == 0) {
            runCd( words, numWords);
        }
        else {
            runCommand( words, numWords );
        }
        free ( line );
        free( words );
    }
    
    
}
