/**
 * @file exclude.c
 * @author Jonathan Kolesar (jkolesa)
 * This component contains the main function. It copies all lines of characters 
 * from the input file to the output file other than one specified line.
 */


#include <unistd.h>
#include <stdio.h>
#include <fcntl.h>
#include <string.h>


/** Valid number of command line arguments. */
#define REQ_ARG_LEN 4

/* Input file's index in the list of pointers to command line arguments */
#define INPUT_FILE_ARG 1

/* Output file's index in the list of pointers to command line arguments */
#define OUTPUT_FILE_ARG 2

/* Line number to omit's index in the list of pointers to command line arguments */
#define LINE_NUM_ARG 3

/** Conversition multiplier for the string to integer converter function */
#define CONVERT_MULTIPLIER 10

/** Size of the buffer */
#define SIXTY_FOUR_BITS 64


/**
 * A helper function to validate and convert the given string (representing the line 
 * number that corresponds with the line of characters to not print from the input file 
 * to the output file) to an integer.
 * 
 * @param lineNumString line number to be converted to an integer
 * @return int line number that was converted to an integer, or returns -1
 * when the given string is invalid.
 */
int stringToInt( char lineNumString[] ) {
    // Initializes an integer variable that will hold the given string.
    int lineNum = 0;
    // Length of the given string.
    int stringLen = strlen(lineNumString);
    // Converts the given string to an integer.
    for ( int i = 0; i < stringLen; i++) {
        // Returns -1 for invalid if the given string contains characters other than digits.
        if ( lineNumString[ i ] < '0' || lineNumString[ i ] > '9' ) {
            return -1;
        }
        // Adds the next most significant digit to the integer.
        lineNum += lineNumString[ i ] - '0';
        // Multiplies the integer by 10 if there are more digits of less 
        // significance to apend to the integer.
        if ( lineNumString[ i + 1 ] != '\0' ) {
            lineNum *= CONVERT_MULTIPLIER;
        }
    }
    // Returns the converted string.
    return lineNum;
}

/**
 * Start of program. It copies all lines of characters from the input file to the output
 * file other than one specified line.
 * 
 * @param argc number of command line arguments.
 * @param argv list of pointers to the command line arguments.
 * @return int exit success if the user provides valid command line arguments. 
 *              Otherwise, exit failure.
 */
int main( int argc, char *argv[] ) {

    // Checks that there are a valid number of arguments.
    if ( argc != REQ_ARG_LEN ) {
        char stderrMessage[] = "usage: exclude <input-file> <output-file> <line-number>\n";
        write( STDERR_FILENO, &stderrMessage, sizeof( stderrMessage ) );
        close( STDERR_FILENO );
        _exit( STDERR_FILENO );
    }

    // Validates the given input line number.
    int lineNum = stringToInt( argv[ LINE_NUM_ARG ] );
    if ( lineNum < 1 ) {
        char stderrMessage[] = "usage: exclude <input-file> <output-file> <line-number>\n";
        write( STDERR_FILENO, &stderrMessage, sizeof( stderrMessage ) );
        close( STDERR_FILENO );
        _exit( STDERR_FILENO );
    }

    // Open the input file
    int inputFP = open( argv[ INPUT_FILE_ARG ], O_RDONLY, 0600);

    // Create the output file
    int outputFP = open( argv[ OUTPUT_FILE_ARG ], O_WRONLY | O_CREAT, 0600 );

    // Read-in 64 bits of the input file per loop.
    char buffer[ SIXTY_FOUR_BITS ];
    int numBitsRead = 0;
    int numLinesRead = 0;
    // Reads-in all characters
    do {
        // Read-in 64 bits of the input file per loop.
        numBitsRead = read( inputFP, buffer, SIXTY_FOUR_BITS );
        for ( int i = 0; i < numBitsRead; i++ ) {
            // Special case for when removing line number 1.
            if ( buffer[ i ] == '\n' && lineNum == 1 && numLinesRead == 0 ) {
                numLinesRead++;
                i++;
            }
            // Increments the number of lines read counter if a new line character is read.
            if ( buffer[ i ] == '\n' ) {
                numLinesRead++;
            }
            // Writes characters to the output file 
            if ( numLinesRead != lineNum - 1 ) {
                write( outputFP, &buffer[ i ], sizeof( char ) );
            }
        }
    } while ( numBitsRead > 0 );

    // Close input and output files.
    close( inputFP );
    close( outputFP );

    return 0;
}
