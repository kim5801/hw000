/**
 * @file stash.c
 * @author Jonathan Kolesar (jkolesa)
 * This component contains the main function.
 * It prompts the user for commands using a prompt and then executes them.
 */


#include <stdlib.h>
#include <unistd.h>
#include <stdio.h>
#include <fcntl.h>
#include <string.h>
#include <stdbool.h>
#include <sys/wait.h>


/** Conversition multiplier for the string to integer converter function */
#define CONVERT_MULTIPLIER 10

/** Number of required arguments for the exit and cd command functions */ 
#define REQ_NUM_ARGS 2

/** Capacity of the line array of characters */ 
#define LINE_CAP 1024

/** Capacity of the words array of character pointers */ 
#define WORDS_CAP 513


/**
 * A helper function to convert the given string (representing the exit status number) to an integer.
 * 
 * @param statusStr exit status number string to be converted to an integer
 * @return int exit status number that was converted to an integer, or returns -1
 * when the given string is invalid.
 */
int stringToInt( char statusStr[] ) {
    // Initializes an integer variable that will hold the given string.
    int statusNum = 0;
    // Length of the given string.
    int stringLen = strlen(statusStr);
    // Converts the given string to an integer.
    for ( int i = 0; i < stringLen; i++) {
        // Returns -1 for invalid if the given string contains characters other than digits.
        if ( statusStr[ i ] < '0' || statusStr[ i ] > '9' ) {
            return -1;
        }
        // Adds the next most significant digit to the integer.
        statusNum += statusStr[ i ] - '0';
        // Multiplies the integer by 10 if there are more digits of less 
        // significance to apend to the integer.
        if ( statusStr[ i + 1 ] != '\0' ) {
            statusNum *= CONVERT_MULTIPLIER;
        }
    }
    // Returns the converted string.
    return statusNum;
}


/**
 * This function takes a user command (line) as input. It breaks the 
 * line into individual words, adds null termination between the words so each word is a 
 * separate string, and it fills in a pointer in the words array to point to the start of 
 * each word. It returns the number of words found in the given line. The words array 
 * should be at least 513 elements in length, so it has room for the largest possible 
 * number of words that could fit in a 1024-character input line.
 * 
 * @param words list of pointers to words
 * @param count number of words in the words array
 * @return int number of words read-in
 */
int parseCommand( char *line, char *words[] ) {
    // Current position in the given line.
    int linePos = 0;
    // Keeps track of the number of words read-in.
    int numWords = 0;
    // Gets the first character in the given line.
    char currChar = line[ 0 ];
    // Skips initial sequences of spaces.
    while ( currChar == ' ' ) {
        linePos++;
        currChar = line[ linePos ];
    }

    // Returns zero words if the given line is empty.
    if ( currChar == '\n' || currChar == '\0' ) {
        return numWords;
    }

    // Iterates through the entire given line and replaces the first space of each 
    // sequence of with null termination and also make a reference to the position of the
    // first letter of each word.
    while ( linePos < LINE_CAP && currChar != '\0' ) {
        // Makes a reference to the start of the current word.
        words[ numWords ] = &line[ linePos ];
        // Increments the number of words that have been read.
        numWords++;
        // Reads the rest of the current word.
        while ( currChar != ' ' && currChar != '\0' ) {
            if ( currChar == '\n' && line[ linePos + 1 ] == '\0' ) {
                line[ linePos ] = '\0';
            }
            linePos++;
            currChar = line[ linePos ];
        }
        // Replaces the first space with a null terminator and
        // then reads past the following spaces.
        bool firstSpace = true;
        while ( currChar == ' ' ) {
            if ( firstSpace ) {
                line[ linePos ] = '\0';
                firstSpace = false;
            }
            linePos++;
            currChar = line[ linePos ];
        }
    }
    return numWords;
}


/**
 * This function performs the built-in exit command. The words array is the list of pointers 
 * to words in the user’s command and count is the number of words in the array.
 * 
 * @param words list of pointers to words
 * @param count number of words in the words array
 */
void runExit( char *words[], int count ) {
    // Keeps track of whether the given argument is valid.
    bool validNumArg = true;
    bool validArg = true;

    // Checks for the correct number of arguments for the exit command.
    if ( count != REQ_NUM_ARGS ) {
        printf( "Invalid command\n" );
        validNumArg = false;
    } else {
        // Converts the exit status string to an integer.
        int status = stringToInt( words[ 1 ] );
        // Validates the exit status integer.
        if ( status < 0 ) {
            printf( "Invalid command\n" );
            validArg = false;
        }

        // Calls the built-in exit() if the given argument is valid.
        if ( validNumArg && validArg ) {
            exit( status );
        }
    }
}


/**
 * This function performs the built-in cd command. The words array is the list of pointers 
 * to words in the user’s command and count is the number of words in the array.
 * 
 * @param words list of pointers to words
 * @param count number of words in the words array
 */
void runCd( char *words[], int count ) {
    // Keeps track of whether the given argument is valid.
    bool validNumArg = true;
    // Checks for the correct number of arguments for the exit command.
    if ( count != REQ_NUM_ARGS ) {
        printf( "Invalid command\n" );
        validNumArg = false;
    } else {
        // Calls the built-in cd() if there are the correct number of given arguments.
        if ( validNumArg ) {
            int feedback = chdir( words[ 1 ] );
            // Checks that whether the given argument was valid.
            if ( feedback < 0 ) {
                printf( "Invalid command\n" );
            }
        }
    }
}


/**
 * This function runs a (non-built-in) command by creating a child process and having 
 * it call execvp() to run the given command. The words array is the list of pointers 
 * to words in the user’s command and count is the number of words in the array.
 * 
 * @param words list of pointers to words
 * @param count number of words in the words array
 */
void runCommand( char *words[], int count ) {

    // Make a child process to execute the given command.
    if ( fork() == 0 ) {
        // Atempts to run the given command and its arguments.
        int feedback = execvp( words[ 0 ], words );
        // Checks that whether the given argument was valid.
        if ( feedback < 0 ) {
            printf( "Can't run command %s\n", words[ 0 ] );
        }
        exit( 0 );
    } else {
        // Old Parent process. The C program will wait here for the child
        // process to finish.
        wait(NULL);
    }
}

/**
 * Start of program.
 * 
 * @param argc number of command line arguments.
 * @param argv list of pointers to the command line arguments.
 * @return int exit success if the user provides valid command line arguments. 
 *              Otherwise, exit failure.
 */
int main( int argc, char *argv[] ) {
    // Declares a char array with a capacity of 1024 bits.
    char line[ LINE_CAP ];
    // Initializes the words pointer array to empty.
    char *words[ WORDS_CAP ] = {'\0'};
    // Initializes number of read-in words to zero.
    int numWords = 0;

    REPROMPT:do {
        // Prompts the user to input a command.
        printf( "stash> " );
        // Resets the words pointer array.
        memset( words , '\0', sizeof( words ) );
        // Reads in the user command to the line char array.
        fgets( line, LINE_CAP, stdin );
        // Parses the user input.
        numWords = parseCommand( line, words );
    } while ( numWords == 0 );

    /*
    // Prints out the number of words and then each word in order.
    printf("%d\n", numWords );
    for ( int i = 0; i < numWords; i++ ) {
        printf("%s\n", words[ i ] );
    }
    */

    if ( strcmp(words[ 0 ], "exit" ) == 0 ) {
        // Attempts to run exit() with the given parameters.
        runExit( words, numWords );
        // Automatically reprompts the user.
        goto REPROMPT;
    } else if ( strcmp(words[ 0 ], "cd" ) == 0 ) {
        // Attemps to run cd() with the given parameters.
        runCd( words, numWords );
        // Automatically reprompts the user.
        goto REPROMPT;
    } else {
        // Attemps to run an external command with the given parameters.
        runCommand( words, numWords );
        // Automatically reprompts the user.
        goto REPROMPT;
    }
}