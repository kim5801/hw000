/**
 * @file stash.c
 * @author Madeleine Ewart (meewart)
 * Simple Toy Assignment Shell (stash)
 * Runs cd and exit commands with its own methods, then delegates to the system for all other commands
 */

#include <string.h>
#include <limits.h>
#include <stdio.h>
#include <ctype.h>
#include <stdlib.h>
#include <stdbool.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>

/** ASCII representation of 0 */
#define ASCII_0 48

/** Maximum supported length of a line of input */
#define MAX_LINE_LENGTH 1024

/** Maximum supported number of words in line of input */
#define MAX_WORDS_ARRAY_LENGTH 513

/**
 * Converts a number stored as a string to an int
 * @param str string representation
 * @return int integer representation or INT_MIN if the string was not a valid integer
 */
int strToInt(char str[])
{
    // True if no inputs have been read or if the previos digit was valid
    int lastDigitValid = 1;
    char ch = str[0];
    int total = 0;
    int digit;
    int strInx = 0;

    while(ch != '\0' && lastDigitValid) {
        if (str[strInx] < ASCII_0 || str[strInx] > ASCII_0 + 9) {
            lastDigitValid = 0;
            return INT_MIN;
        }

        total *= 10;
        digit = ch - ASCII_0;
        total += digit;

        strInx++;
        ch = str[strInx];
    }
    return total;
}

/**
 * Frees words array
 * 
 * @param words array of words to be freed
 * @param count number of words in array
 */
void freeWords(char *words[], int count)
{
    for (int i = 0; i < count; i++) {
        free(words[i]);
    }
}

/**
 * Breaks a command into individual words. Adds null termination to each word.
 * Fills in the given array with pointers to the beginning of each word.
 * @param line line to be parsed
 * @param words array to be filled with parsed words. Should be at least 513 elements long.
 * @return number of words found
 */
int parseCommand(char *line, char *words[])
{
    int count = 0; // Current index of words array
    char *temp = (char*) malloc(513 * sizeof(char));
    int tempIndex = 0;

    for (int i = 0; i < strlen(line); i++) { // For each character in line
        // If the character is part of a word, add character to temp
        if (!isspace(line[i])) {
            temp[tempIndex] = line[i];
            tempIndex++;
        }
        // If character is whitespace, add a null terminator and copy to words array
        else if (isspace(line[i]) && tempIndex != 0) {
            temp[tempIndex] = '\0';
            words[count] = (char*) malloc(strlen(temp) * sizeof(char));
            strcpy(words[count], temp);
            count++;
            tempIndex = 0;
        }
    }
    free(temp);
    return count;
}

/**
 * Runs the exit command with the given exit status
 * Prints "Invalid Command" if the exit status is not valid or the words array does not have 2 members
 * 
 * @param words array of words in command
 * @param count number of words in array
 */
void runExit(char *words[], int count)
{
    if (count != 2) {
        printf("Invlid command\n");
    }
    else {
        int exitStatus = strToInt(words[1]);

        if (exitStatus == INT_MIN) {
            printf("Invlid command\n");
        }
        else {
            freeWords(words, count);
            exit(exitStatus);
        }
    }
    
}

/**
 * Runs cd command with the given directory
 * Prints "Invalid Command" if the directory is invalid or if the words array does not have 2 members
 * 
 * @param words array of words in command
 * @param count number of words in array
 */
void runCd(char *words[], int count)
{
    if (count != 2) {
        printf("Invlid command\n");
    }
    else {
        int validDirectory = chdir(words[1]);
        if (validDirectory != 0) {
            printf("Invlid command\n");
        }
    }
}

/**
 * Runs the given non-built in command by creating a child process
 * 
 * @param words array of words containing command
 * @param count number of words in array
 */
void runCommand(char *words[], int count)
{
    words[count] = NULL;

    int newpid = fork();
    if (newpid == 0) {
        int error = 0;
        error = execvp(words[0], words);

        if (error == -1) {
            printf("Can't run command %s\n", words[0]);
        }
        exit(EXIT_SUCCESS);
    }
    else {
        wait(NULL);
    }
}

/**
 * Reads commands from the user and operates like a simple shell.
 * Supports cd and exit commands and delegates to system for any other commands.
 * 
 * @param argc number of command line arguments
 * @param argv shell commands
 * @return exit status
 */
int main(int argc, char *argv[])
{
    char line[MAX_LINE_LENGTH];
    char *words[MAX_WORDS_ARRAY_LENGTH];
    int count = 0;
    // Bug: exit isn't being run directly after an invalid run command

    while(true) {// While program is running. Program will exit when method is called.
        printf("stash> ");
        fgets(line, MAX_LINE_LENGTH, stdin);
        count = parseCommand(line, words);
        
        if (count == 0) {
            continue;
        }
        else if (strcmp(words[0], "cd") == 0) {
            runCd(words, count);
        }
        else if (strcmp(words[0], "exit") == 0) {
            runExit(words, count);
        }
        else {
            runCommand(words, count);
        }
        freeWords(words, count);
    }
    return 0;
}
