/**
 * Creates a new text file, which is a copy of another text file with a given line missing
 * @file exclude.c
 * @author Madeleine Ewart (meewart)
 */

#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>

/** ASCII representation of 0 */
#define ASCII_0 48

/** Size of buffer holding pieces of the input file contents */
#define BUFFER_SIZE 64

/**
 * Converts a number stored as a string to an int
 * @param str string representation
 * @return int integer representation or -1 if the string was not a valid integer
 */
int strToInt(char str[])
{
    // True if no inputs have been read or if the previos digit was valid
    int lastDigitValid = 1;
    char ch = str[0];
    int total = 0;
    int digit;
    int strInx = 0;

    while(ch != '\0' && lastDigitValid) {
        if (str[strInx] < ASCII_0 || str[strInx] > ASCII_0 + 9) {
            lastDigitValid = 0;
            return -1;
        }

        total *= 10;
        digit = ch - ASCII_0;
        total += digit;

        strInx++;
        ch = str[strInx];
    }
    return total;
}

/**
 * Creates a new file with a name given on the command line.
 * Copies a given file to the new file with the given line missing.
 * 
 * @param argc number of command line arguments
 * @param argv command line arguments in the format "exclude <input-file> <output-file> <line-number>"
 * @return exit status
 */
int main(int argc, char *argv[])
{
    // Check number of command line arguments
    if (argc != 4) {
        write(STDERR_FILENO, "usage: exclude <input-file> <output-file> <line-number>\n", 56);
        _exit(1);
    }

    char *inputFileName = argv[1];
    char *outputFileName = argv[2];
    char *lineNumber = argv[3];

    // Open and check input file
    int inputFile = open(inputFileName, O_RDWR);
    if (inputFile == -1) {
        write(STDERR_FILENO, "usage: exclude <input-file> <output-file> <line-number>\n", 56);
        _exit(1);
    }

    // Open and check output file
    int outputFile = open(outputFileName, O_RDWR | O_CREAT | O_TRUNC, 0600);
    if (outputFile == -1) {
        write(STDERR_FILENO, "usage: exclude <input-file> <output-file> <line-number>\n", 56); 
        _exit(1);
    }

    // Parse and check line number
    int lineInt = strToInt(lineNumber);
    if (lineInt == -1) {
        write(STDERR_FILENO, "usage: exclude <input-file> <output-file> <line-number> (lineInt)\n", 56);
        _exit(1);
    }

    int bytesRead = 0; // Number of bytes read from file
    char buffer[BUFFER_SIZE]; // Buffer to hold bytes
    int currentLine = 1; // Current line in file

    // Read bytes into buffer
    bytesRead = read(inputFile, buffer, BUFFER_SIZE);

    while (bytesRead != 0) {
        // For each byte in buffer
        for (int i = 0; i < bytesRead; i++) {
            // Track current line
            if (buffer[i] == '\n') {
                currentLine++;
            }

            // If the character is not on a skipped line, write to file
            if (currentLine != lineInt) {
                write(outputFile, &buffer[i], 1);
            }
        }

        // Read bytes into buffer
        bytesRead = read(inputFile, buffer, BUFFER_SIZE);
    }
    
    close(inputFile);
    close(outputFile);
}
