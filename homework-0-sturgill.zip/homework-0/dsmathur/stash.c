/**
* @file stash.c 
* @author dsmathur
* This file includes all the functions
* as proposed in the design for stash.c.
* It's main objective is to create a shell
* program that is basically a command line interpreter.
*/

#include <stdlib.h>
#include <stdbool.h>
#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <sys/wait.h>
#include <sys/types.h>

#define INVALID_COMMAND "Invalid command\n"

#define STASH "stash> "

#define LINE_MAX_LENGTH 1025

#define WORDS_ARRAY_LENGTH 513


/**
* This functions parses a command  by taking the user input 
* as a line and breaks it into individual words , while 
* also adding  a null termination between the words so
* that each word is a separate string.
* @param line the input line entered by the user
* @param words an array of character pointers that will point
*        to the start of each term
* @return wordCount representing the number of words in the input line
*/
int parseCommand(char * line , char *words[]){
    int wordCount = 0;
    bool firstLetterBlank = 1;
    int offset = 0;
    int max = strlen(line);
    
    //Go until a character exists in the given line
    while(*(line + offset)){
    
        //A special case is organized for the first letter
        //If there are any additional spaces before the first letter,
        //those should be ignored.
        if( firstLetterBlank ){
            if( *(line + offset) == ' '){
                while(*(line + offset)  && *( line + offset) == ' '){
                    offset++;
                }
            }
            firstLetterBlank = 0;
            words[wordCount] = line + offset;
            wordCount++;
        }
        
        //If a space comes in as the next character, then that indicates
        // that one word has finished
        
        if(*(line + offset) && *(line + offset) == ' '  ){
            *(line + offset) = '\0';
            offset++;
            //If there are any spaces between two words, 
            // all of them should be ignored.
            while(*(line + offset) && *(line + offset) == ' '){
                offset++;
            }  
            words[wordCount] = line + offset;
            
            //Incrementing the word count to account for a new word
            wordCount++;
        }
        
        //If a next character exists, then it is the same word 
        // so we just need to increase the offset value
        else if(*(line + offset + 1)){
         offset++;
        }
        
        //If the offset has reached the maximum length, then you need to break out
        // from the loop
        else if( offset ==max - 1){
            break;
        }
    }   
    return wordCount;
    
}

/**
* This function implements a built in 
* exit command for the stash program.
* It delegates the  work to the exit system 
* call and takes care of invalid checks.
* @param words  the character array of pointers
* @param count  the number of words in the input line
*/
void runExit(char* words[] , int count){
    //If one argument is not present
    // then the command should be stated
    // as invalid
    if(count == 2){
        int parsedInteger = atoi(words[1]);
        if(parsedInteger == 0){
            printf(INVALID_COMMAND);
        }
        else{
            _exit(parsedInteger);
        }  
    }
    else{
        printf(INVALID_COMMAND);   
    }
}

/**
* This function performs the built in cd command
* The task of changing the directory is delegated 
* to chdir.
* @param words the character array of pointers
* @param count the number of words in the input line
*/
void runCd(char* words[] , int count){
    //If one argument is not present
    // then the command should be stated
    // as invalid
    if(count !=2){
        printf(INVALID_COMMAND);
    }
    else{
        int value = chdir(words[1]);
        if(value < 0){
            printf(INVALID_COMMAND);
        }
    }
}

/**
* This function perfroms all of the non built in 
* or external commands by calling the execvp system 
* call . It also takes care of invalid checks.
* @param words the character array of pointers
* @param count the number of words in the input line
*/
void runCommand(char * words[] , int count ){
    //Creating a child process
    pid_t id =  fork();
    //If it is not the child , the parent
    // needs to wait for the child to finish 
    // executing 
    if(id != 0){
        wait(NULL);
    }
    else{
        words[count] = NULL;
        
        //Executes the command , the first parameter, along 
        // with the list of the arguments as the second parameter
        execvp(words[0],words);
        
        //If the command is not executed , the following 
        // line is printed to the terminal output
        printf("Can't run command %s\n",words[0]);
        exit(0);
    }
}

/**
* The main function performs the reading 
* from the standard input and accordingly
* checks which function needs to be called.
* @return an integer representing whether the program was successfully
*         executed or not.
*/
int main (){

    //Creating a char array to hold the line contents
    char line[LINE_MAX_LENGTH ];

    printf(STASH);
    
    while(fgets(line, LINE_MAX_LENGTH , stdin) != NULL){
    
       
        //Storing the length of the line
        if(strlen(line) > 0){
            line[strlen(line) -1 ] = '\0';
        }

        // Create an array of character pointer called as words
        char* words[WORDS_ARRAY_LENGTH];

        //Storing the count of the words, and parsing the line
        int wordLength = parseCommand( line , words);

        //First built in  command, cd
        if(strcmp (words[0], "cd") == 0){
            runCd(words , wordLength);
            printf(STASH);
        }
        
        //Second built in command , exit
        else if(strcmp(words[0],"exit") == 0){  
            runExit(words,wordLength);
            printf(STASH);
        }   
    
        //If it is a blank input, the user should be prompted again
        else if (wordLength == 0){
            printf(STASH);
            continue;
        }
        
        //If it is an external command use the runCommand() function
        else{
            runCommand(words , wordLength);
            printf(STASH);
            continue;
        }
    }
    
    return EXIT_SUCCESS;
      
}
