/**
* @file exclude.c
* @author dsmathur
* This file includes the implementation of the 
* exclude.c requirements.This program only 
* uses system calls to achieve the proposed
* objective.
*/

#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>

/** The character or ascii form of the number 0 */
#define ZERO_ASCII '0'

/** The character or ascii form of the numer 9 */
#define NINE_ASCII '9'

/** A string holding the invalid response contents */
#define INVALID_RESPONSE "usage: exclude <input-file> <output-file> <line-number>\n"

/** Holds the length of the above invalid response */
#define INVALID_REPONSE_LENGTH 56

/** Stores the name of the output file to write to */
#define OUTPUT_FILE "output.txt"

/**
* This function returns the length of a string 
* @param p , a pointer to a string
* @return length , the length of the string
*/
static int  stringLength(char *p){
    int length = 0;
    while(*p){
        length++;
        p++;
    }
    return length;
}

/**
* This function converts a string in to an integer format 
* if it within the particular ASCII range as described 
* It also handles invalid input scenarios.
* @param str, the string that consists of the user input of the line number to exclude
* @return sum, the line number in the integer format
*
*/
static int  asciiConvertor(char *str){
    int count =1;
    int length = stringLength(str);
    int sum =0;
    for(int i = length -1 ; i >=0 ; i-- ){
        
        //Checks if the ascii characters is between the digit range
        if(str[i] >= ZERO_ASCII && str[i] <= NINE_ASCII){
            sum += (str[i] - '0') * count;
            count *= 10;
        }
        //If it is not in range , the given error is issued.
        else{
            write(STDERR_FILENO,INVALID_RESPONSE, INVALID_REPONSE_LENGTH);
            _exit(1);
        }
    }
    return sum;
}

/**
* The main program that takes in command line arguments.
* @param argc , the number of command line arguments.
* @param argv, a char pointer array holding the argument contents
* @return an integer of whether the program was successful.
*/
int main (int argc , char *argv[]){

    if( argc !=4){
        write(STDERR_FILENO, INVALID_RESPONSE, INVALID_REPONSE_LENGTH);
        _exit(1);
    }
    
    //Making an array to read in the characters, that is with 64 bytes
    char readArray[64];
    
    //Creating a file descriptor for reading the file  
    int fp = open( argv[1], O_RDONLY);
    
    //Creating a file descriptor for writing to a file, the output file if present
    // is truncated before being used.
    int fd = open( OUTPUT_FILE,O_TRUNC| O_WRONLY|O_CREAT,0600);
    
    //If the file descriptor is invalid , exit out of the program
    if(fp < 0){
        write(STDERR_FILENO, INVALID_RESPONSE, INVALID_REPONSE_LENGTH);
        _exit(1);
    }
    
    int count = asciiConvertor(argv[3]);
    
    //Read the file as a block of bytes up tp 64
    int len = read(fp,readArray,sizeof(readArray));
    
    int numLines = 0;
    int numBytes = 0;
    int offset = 0;
    
    //Until there is some content present in the file , keep running the following loop
    while(len > 0){
        for(int i = 0; i < len;i++){
            numBytes++;
            //if the line to be excluded is on the next line, 
            // discard everything that is read until the next 
            // new line is reached 
            if(numLines == count - 1){
                while(readArray[i] != '\n' && i != len -1 ){
                    i++;
                    offset++;
                }
                
                //If the length of the file is already reached , break from this 
                // loop and dont write any of the bytes , hence mark numBytes as zero
                if(i == len -1){
                    numBytes = 0 ;
                    break;
                }
                
                //for the null character
                i++;
                offset++;
                numLines++;
             }
             
             //If a new line character had been reached , that indicates that 
             // a line has ended so the line count needs to be incremented 
             // and the block of code remaining should be written to the 
             // file with the write system call while taking offset 
             // and the number of bytes to be written in to account.
            if(readArray[i] == '\n' || i == len -1){
                if(readArray[i] == '\n'){
                    numLines++;
                }
                
                write( fd,readArray + offset, numBytes);
                offset = offset + numBytes;
                numBytes = 0;
            }    
        }
        // Reading in another block of bytes from the input file
        len = read(fp,readArray,sizeof(readArray) );
        offset = 0;
    }
    
    //Closing the files
    close(fp);
    close(fd);
    return 0;
    
}
