//Homework 0 program for a shell (command-line interpreter) for cd, exit, ls, and sleep.
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>

//Parse line into command and command-line arguments
int parseCommand( char *line, char *words[] ) {
    int count = 0;
    int i = 0;
    char *word = calloc(50, sizeof(char));
    while(*line) {
        if(*line == ' ' || *line == '\n') {
            *line = '\0';
            word[i] = *line++;
            words[count++] = word;
            word = "";
            i = 0;
        } else {
            word[i++] = *line++;
        }
    }

    return count;
}

//Run exit command
void runExit( char *words[], int count ) {
    if(count > 2) {
        printf("Invalid command");
    } else {
        int status = 0;
        for(int i = 0; i < strlen(words[1]); i++) {
            if((words[1][i] >= '!' && words[1][i] <= '/') || (words[1][i] >= ':' && words[1][i] <= '~')) {
                printf("Invalid command");
                break;
            }

            if(i != 0) {
                status *= 10;
            }

            status = status + (words[1][i] - '0');
        }
        _exit(status);
    }
}

//Run cd command
void runCd( char *words[], int count ) {
    if(count > 2 || count < 2) {
        printf("Invalid command");
    } else {    
        chdir(words[1]);
    }
}

//Run other commands via execvp
void runCommand( char *words[], int count ) {
    if(strcmp(words[0], "ls")) {
        fork();
        execvp("ls", words);
        exit(0);
    }

}

//Program starting point
int main() {
    char *line = calloc(100, sizeof(char));
    char **words;
    words = (char **)malloc(513 * sizeof(char *));
    for ( int i = 0; i < 513; i++ )
        words[ i ] = (char *)malloc( 50 * sizeof( char ) );
    printf("stash> ");
    while(fgets(line, 100, stdin)) {
        int count = parseCommand(line, words);

        if(count > 0) {
            if(strcmp(words[0], "cd") == 0){
                runCd(words, count);
            } else if(strcmp(words[0], "exit") == 0) {
                runExit(words, count);
            } else {
                runCommand(words, count);
            }

        }

        free(line);
        for ( int i = 0; i < 513; i++ )
            free( words[ i ] );
        free( words );

        printf("\nstash> ");
    }

    return EXIT_SUCCESS;
}