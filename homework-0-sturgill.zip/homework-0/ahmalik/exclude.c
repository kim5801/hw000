//Homework 0 program using Unix commands to exclude specific read lines from being written to file.
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>

//Return length of string
int stringLength(char const *s) {
    int i = 0;
    int count = 0;

    while(s[i++]) {
        count++;
    }

    return count;
}

// Print out an error message and exit.
static void fail( char const *message ) {
    for(int i = 0; i < stringLength(message); i++) {
        write(STDERR_FILENO, &message[i], 1);
    }
    _exit( 1 );
}

int main( int argc, char *argv[] ) {
    //Check for correct number of arguments
    if(argc != 4) {
        fail("Invalid number of arguments\n");
    }

    //Open input file for reading.
    int input = open(argv[1], O_RDONLY);
    if ( input < 0 ) {
        fail( "Can't open input file\n" );
    }

    //Open output file for reading.
    int output = open(argv[2], O_WRONLY | O_CREAT, 0600);
    if ( output == -1 ) {
        fail( "Can't open output file\n" );
    }

    //Convert last command line argument to an integer.
    int line = 0;
    for(int i = 0; i < stringLength(argv[3]); i++) {
        if((argv[3][i] >= '!' && argv[3][i] <= '/') || (argv[3][i] >= ':' && argv[3][i] <= '~')) {
            fail("Invalid character in line number\n");
        }

        if(i != 0) {
            line *= 10;
        }

        line = line + (argv[3][i] - '0');
    }
    
    //Read lines and exclude line number at third argument.
    char buffer[64];
    int len = read(input, buffer, sizeof(buffer));
    int count = 1;

    while(len > 0) {
        for(int i = 0; i < len; i++) {
            if(buffer[i] == '\n') {
                count++;
            }

            if(count != line) {
                write(output, &buffer[i], 1);
            }
        }
        len = read(input, buffer, sizeof(buffer));
    }

    close(input);
    close(output);
    return 0;
}