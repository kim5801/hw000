#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>


int strToInt ( char* str )
{
    int sum = 0;

    for(int i = 0; str[i] != '\0'; ++i) {
        
        sum *= 10;
        sum += str[i] - '0';
    }

    return sum;
}


int main( int argc, char *argv[] ) {


    int line_num = strToInt(argv[3]);


    if( argc > 4 || line_num <= 0 ) {

        write(STDERR_FILENO, "usage: exclude <input-file> <output-file> <line-number>", 56);
        _exit( 1 );
    }

    int fdin = open(argv[1], O_RDONLY);
    int fdout = open(argv[2], O_CREAT | O_WRONLY, 00700);

    if ( fdin == -1 ) {

        write(STDERR_FILENO, "usage: exclude <input-file> <output-file> <line-number>", 56);
        _exit( 1 );
    }

    char buffer[64];
    int lineidx[100];
    int omitidx1 = 0;
    int omitidx2 = 0;

    ssize_t readsize = 1;
    int linecount = 1;
    int omitline = 0;       //0 = have not omit, 1 = need to omit half in next read, 2 = omit all in this read, 3 = 2nd half of omit
    
    while( readsize > 0 )
    {
        readsize = read(fdin, buffer, 64);        

        for( int i = 0; i < readsize; i++ ) {
        
            if( buffer[i] == '\n' ) {

                lineidx[linecount] = i;
                if(omitline == 1)
                {
                    omitline == 2;
                }
                if(line_num == linecount) {
                    omitline = 1;
                }

                linecount++;

            }            
        }

        if(omitline == 0) {
            write(fdout, buffer, readsize);
        }
        else if (omitline == 1)
        {
            write(fdout, buffer, lineidx[line_num]);
            omitline = 3;
        }
        else if (omitline == 2)
        {
            char *linebuffer = &buffer[lineidx[line_num + 1]];
            write(fdout, buffer, lineidx[line_num]);
            write(fdout, linebuffer, readsize - lineidx[line_num + 1]);
        }
        else if (omitline == 3)
        {
            char *linebuffer = &buffer[lineidx[line_num + 1]];
            write(fdout, linebuffer, readsize - lineidx[line_num + 1]);
        }

    }

    close(fdin);
    close(fdout);

 
    

}