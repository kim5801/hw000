#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>
#include <ctype.h>
#include<sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>
#include <wait.h>

#define NUM_ARGS 2

#define ERROR_STATUS -1

#define MAX_CHARS 1024

#define MAX_WORDS 523

int parseCommand( char *line, char *words[] ) {
    int len = strlen(line);
    int wordIdx = 0;
    int i = 0;
    while (i < len) {
        while (isspace(line[i]) != 0) {
            if(line[i] == '\n') {
                line[i] = '\0';
                words[wordIdx] = NULL;
                return wordIdx;
            }
            line[i] = '\0';
            i++;
        }
        words[wordIdx] = &line[i];
        while (isspace(line[i]) == 0) {
            i++;
        }
        wordIdx++;
    }
    words[wordIdx] = NULL;
    return wordIdx + 1;
}

void runExit( char *words[], int count ) {
    if (count != NUM_ARGS) {
        fprintf(stderr, "Invalid command\n");
        return;
    }
    if (strcmp(words[1], "0") == 0) {
        exit(0);
    }
    int status = atoi(words[1]);
    if (status == 0) {
        fprintf(stderr, "Invalid command\n");
        return;
    }
    exit(status);
}

void runCd( char *words[], int count ) {
    if (count != NUM_ARGS) {
        fprintf(stderr, "Invalid command\n");
        return;
    }
    int status = chdir(words[1]);
    if (status == ERROR_STATUS) {
        fprintf(stderr, "Invalid command\n");
    }
}

void runCommand( char *words[], int count ) {
    int pid = fork();
    
    if (pid == 0) {
        int status = -1;
        status = execvp(words[0], &words[0]);
        if (status == ERROR_STATUS) {
            fprintf(stderr, "Can't run command %s\n", words[0]);
        }
        exit(EXIT_SUCCESS);
    }
    
    wait(NULL);
}

int main( int argc, char *argv[] ) {
    bool go = true;
    while (go) {
        printf("stash> ");
        char line[MAX_CHARS + 1];
        char *result = NULL;
        result = fgets(line, MAX_CHARS + 1, stdin);
        char *words[MAX_WORDS + 1];
        words[MAX_WORDS] = NULL;
        int count = parseCommand(result, words);
        if (count == 0) {
            //do nothing
        }
        else if (strcmp(words[0], "exit") == 0) {
            runExit(words, count);
        }
        else if (strcmp(words[0], "cd") == 0) {
            runCd(words, count);
        }
        else {
            runCommand(words, count);
        }
    }
}
