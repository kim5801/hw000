#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>

/** Number of command line arguments needed. */
#define NUM_ARGS 4

/** Error value returned from open and close. */
#define ERR_VAL -1

/** Command line argument index with the input file. */
#define INPUT_ARG 1

/** Command line argument index with the output file. */
#define OUTPUT_ARG 2

/** Command line argument index with the line number to be excluded. */
#define LINE_ARG 3

/** Maximum number of bytes to read from the input file at a time. */
#define MAX_BYTES 64

/** Exit success value. */
#define EXIT_SUCCESS 0

/** Exit failure value. */
#define EXIT_FAILURE 1

/** Output file permissions, allows the user to have all permissions and anyone else to read. */
#define OUTPUT_PERMS 0644

/** Number used to multiply by to turn a string to an integer by adding up the ones, then tens, then hundreds, etc. using the rules of base 10. */
#define BASE 10

int main( int argc, char *argv[] ) {
    
    //Checking that the number of command line arguments is correct, exiting if not.
    if (argc != NUM_ARGS) {
        write(STDERR_FILENO, "usage: exclude <input-file> <output-file> <line-number>\n", MAX_BYTES);
        _exit(EXIT_FAILURE);
    }
    
    //Opening the input file, exiting if it cannot be opened.
    int infile = open(argv[INPUT_ARG], O_RDONLY);
    if (infile == ERR_VAL) {
        write(STDERR_FILENO, "usage: exclude <input-file> <output-file> <line-number>\n", MAX_BYTES);
        _exit(EXIT_FAILURE);
    }
    
    //Opening the output file, or creating it if it doesnt exist. Exiting the program if it can't be opened.
    int outfile = open(argv[OUTPUT_ARG], O_RDWR | O_TRUNC | O_CREAT, OUTPUT_PERMS);
    if (outfile == ERR_VAL) {
        write(STDERR_FILENO, "usage: exclude <input-file> <output-file> <line-number>\n", MAX_BYTES);
        _exit(EXIT_FAILURE);
    }
    
    //Counting the length of the line number argument from the command line
    int len = 0;
    char *line = argv[LINE_ARG];
    while (line[len] != '\0') {
        len++; 
    }
    
    int lineNum = 0;
    int power = 1;
    //Iterating from right to left, adding to ones, tens, etc. * the value to lineNum in order
    //to convert from a String to an int. Exits with an error status if any of the characters
    //are not a digit (0-9). Ignores leading zeros.
    for (int i = len - 1; i >= 0; i--) {
        char c = line[i];
        if (c == '0') {
            //nothing to add
        }
        else if (c == '1') {
            lineNum += power * 1;
        }
        else if (c == '2') {
            lineNum += power * 2;
        }
        else if (c == '3') {
            lineNum += power * 3;
        }
        else if (c == '4') {
            lineNum += power * 4;
        }
        else if (c == '5') {
            lineNum += power * 5;
        }
        else if (c == '6') {
            lineNum += power * 6;
        }
        else if (c == '7') {
            lineNum += power * 7;
        }
        else if (c == '8') {
            lineNum += power * 8;
        }
        else if (c == '9') {
            lineNum += power * 9;
        }
        else {
            //invalid character, exits
            write(STDERR_FILENO, "usage: exclude <input-file> <output-file> <line-number>\n", MAX_BYTES);
            _exit(EXIT_FAILURE);
        }
        //Mulitply by 10
        power *= BASE;
    }
    
    //Reads in 64 bytes from the input file and then outputs each character at a time to the output
    //file, making sure to keep up with the line count, and excluding any character from the line
    //that was designated in the command line arguments.
    int currentLine = 1;
    char buffer[MAX_BYTES];
    int go = 1;
    while (go == 1) {
        int bytes = read(infile, buffer, MAX_BYTES);
        for (int i = 0; i < bytes; i++) {
            if (currentLine != lineNum) {
                write(outfile, &buffer[i], 1);
            }
            if (buffer[i] == '\n') {
                currentLine++;
            }
        }
        if (bytes < MAX_BYTES) {
            go = 0;
        }
    }
    
    //No errors occurred, exits successfully.
    _exit(EXIT_SUCCESS);
}