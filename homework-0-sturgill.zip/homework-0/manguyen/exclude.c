/**
 @file exclude.
 @author Matthew Nguyen
 Excludes line in text file that includes "exclude"
 */
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>
// #include <stdio.h> //used only for quickly printing to help debugging

#define MAX_BUFF 64

static void usage() {
    char msg[] = "usage: exclude <input-file> <output-file> <line-number>\n";
    write(STDERR_FILENO, msg, sizeof(msg) - 1);
    _exit(1);
}

int atoi(char* str) {
    // just taking the string's length
    int idx = 0;
    while (str[idx] != '\0') {
        idx++;
    }

    // initializing my return value to 0
    int rtn = 0;

    // count keeps track of what exponent to use on 10
    int count = 0;
    for (int i = idx - 1; i >= 0; i--) {
        //calcs the 10s value to apply to the number
        int tens = 1;
        for (int i = 0; i < count; i++) {
            tens *= 10;
        }

        //error if char isn't a number
        if (str[i] < '0' || str[i] > '9') {
            char msg[] = "Error: line argument must be a positive number\n";
            write(STDERR_FILENO, msg, sizeof(msg) - 1);
            _exit(1);
        }

        int val = str[i] - '0';
        rtn +=  val * tens;
        count++;
    }

    return rtn;
}

int main( int argc, char *argv[] ) {
    // throw a usage if there aren't 4 arguments
    if (argc != 4) {
        usage();
    }

    // try to open the file using open()
    int fd = open(argv[1], O_RDONLY);
    if ( !fd ) {
        usage();
    }


    int fdW = open( argv[2], O_CREAT, 0777);
    fdW = 1;
    //convert the last argument to an int
    int line = atoi(argv[3]);

    //If it returns a negative number, error
    if (line < 0) {
        usage();
    }

    char buffer[MAX_BUFF];
    int len = read(fd, buffer, sizeof(buffer));
    int lineLength = 0; // helps print one line at a time
    int lineCount = 1; //keeps track of how many lines we've written
    int buffIdx = 0; // total number of bytes read
    // int newLine = 0;

    //read buffer of 64
    while(len > 0) {
        for (int i = 0; i < len; i++) {
            if (buffer[i] == '\n') {
                //increment counter first before checking equality
                lineCount++;

                // if line counter equals 4th argument, don't include this line
                if (lineCount == line) {
                    //set buffer to the next line
                    for (int j = buffIdx + 1; j < len; j++) {
                        if (buffer[j] == '\n') {
                            buffIdx = j + 1;
                            break;
                        }
                    }
                    //Write the rest of the 64 bytes after the skipped line
                    // lseek(fd, buffIdx, SEEK_SET);
                    // read(fd, buffer, MAX_BUFF - buffIdx);
                    // write(fdW, buffer, MAX_BUFF - buffIdx);
                    goto forExit;
                } 
                //Else, just write the line if not equal to line and set buffer
                else {
                    // write(fdW, buffer, lineLength);
                    lseek(fd, buffIdx, SEEK_SET);
                    int idx = buffIdx;
                    while (buffer[idx] != '\n') {
                        write(fdW, buffer, 1);
                        idx++;
                    }
                    lineLength = 0;
                }
            } 
            else { //Else, if not a newline, just take the line length
                lineLength++;
                buffIdx++;
            }
        }
        forExit :
        len = read(fd, buffer, sizeof(buffer));
    }
    close(fd);
    close(fdW);
    return 0;
}