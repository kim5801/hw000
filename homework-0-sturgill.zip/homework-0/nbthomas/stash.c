/** 
  @file stash.c
  @author Noah Thomas (nbthomas)
  The program simulates a shell prompt which requests commands from the user with the appropriate arguments to
  carry out tasks. STASH possess built-in commands such as cd to change working directory and exit to end the program
  with the provided exit status. External commands can also be performed as well.
*/
#include <stdlib.h>
#include <stdio.h>
#include <stdbool.h>
#include <string.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/wait.h>

/** Successful Completion of program, likely never triggered due to the exit command */
#define EXIT_SUCCESS 0
/** size of input array to hold up to 1024 with null termination*/
#define MAX_CHAR_LENGTH 1025
/** Most words that could be read from input */
#define MAX_WORDS 513

/** 
  Breaks the user's input into words that can then be processed individual to reference for later commands
  @param line of input
  @param words array used to contain each word instance
  @return number of words founds
*/
int parseCommand( char *line, char *words[] ) {

    int l = 0; //counter variable

    words[l++] = strtok(line, " "); //strtok uses space as a delimeter to then read the first word

    while((words[l++] = strtok(NULL, " ")) != NULL) {} //continues reading words until none can be found

    return l - 1; //amount of words found, removes the extra increment for when there are no words left
}

/** 
  Exits the shell with the exit status provided, provides an error message if there are more arguments than the
  command "exit" and the exit status as an integer
  @param words used in command
  @param count of words in command
*/
void runExit( char *words[], int count ) {
    if(count != 2) {
        fprintf(stderr, "Invalid command\n");
    }

    int exit_stat = atoi(words[1]); //reads the exit status

    if(exit_stat == 0 && strcmp(words[1], "0") != 0) { //should account for 00 or 000 too and also inform if a non-proper integer was given
        fprintf(stderr, "Invalid command\n");
    } else {
        exit(exit_stat); //exits as desired
    }
}

/** 
  Changes the working directory for the user currently and informs of error if more than the pathname is given
  or if the directory doesn't exist
  @param words of input
  @param count of words
*/
void runCd( char *words[], int count ) {

    if(count != 2) { //checks if more than pathname is given or no pathname is provided
        fprintf(stderr, "Invalid command\n");
    }

    int success = chdir(words[1]); //changes directory to path provided, relative or absolute

    if(count == 2 && success < 0) { //sees if pathname given does not exist
        fprintf(stderr, "Invalid command\n");
    }
}

/** 
  Runs external commands provided by the user and provides an error if the command included can not be found
  or can't be ran with arguments given
  @param words of input
  @param count of words
*/
void runCommand( char *words[], int count ) {

    words[count] = NULL; //provides null terminator for execvp

    pid_t child = fork(); //generates child process

    if(child == 0) { //provides instructions for child process to execute
        int success = execvp(words[0], words); //performs external commands

        if(success < 0) {
            fprintf(stderr, "Can't run command %s\n", words[0]); //notes of issue with command
        }
        exit(1); //terminates child process
    } else {
        wait(&child); //waits on child process to terminate
    }

}

/** 
  Prompts the user continually for commands until they exit the program via the exit command or termination. Processes
  and delegates the input to their appropriate command for task completion
  @param argc number of arguments
  @param argv arguments
  @return exit status
*/
int main(int argc, char *argv[]) {
    bool over = false;

    while(!over) { //will continue to prompt until user ends program
        fprintf(stdout, "stash> "); //prompt message

        char *inp = (char *)malloc(MAX_CHAR_LENGTH * sizeof(char)); //where input will be held
        char *words[MAX_WORDS]; //where each word from the input will be held

        int c = 0;
        while((inp[c] = getchar()) != '\n') {//reads the line of input
            c++;
        }

        if(strcmp(inp, "\n") == 0 || strcmp(inp, "") == 0) {//nothing is given or user simply \n or null
            continue;
        }

        int length = parseCommand(inp, words); //breaks down input

        for(int i = 0; i < length; i++) {// goes through each word to ensure it is null terminated 
            int e = 0;
            while(words[i][e]) {
                if(words[i][e] == '\n') {
                    words[i][e] = '\0';
                }
            e++;
           }
        }

        if(strcmp(words[0], "cd") == 0) { //checks for cd command
            runCd(words, length);
        } else if (strcmp(words[0], "exit") == 0) { //checks for exit command
            runExit(words, length);
        } else { //checks for external command
            runCommand(words, length);
        }

    }

    return EXIT_SUCCESS; //exits successfully
}