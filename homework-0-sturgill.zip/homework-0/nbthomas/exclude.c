/** 
  @file exclude.c
  @author Noah Thomas (nbthomas)
  Program intended to write a new file which copies the input file provided but excludes the line indicated.
  In cases where the line number provided is larger than the input file lines, then the file contents should
  be maintained.
*/
#include <unistd.h>
#include <fcntl.h>

/** Successful Completion of program */
#define EXIT_SUCCESS 0
/** Error occurred and execution ceased */
#define EXIT_FAIL 1
/** Amount of bytes needed to write the error/usage message */
#define INVALID_ARGS_BYTES 56
/** Reference to the third argument passed */
#define THIRD 3
/** difference to make char value into the int value it represents */
#define CHAR_SHIFT 48
/** The amount of bytes that can be read up to at a time */
#define BYTE_READ 64

int main(int argc, char *argv[]) {

    if(argc != 4) { //checking that all arguments are given
        write(STDERR_FILENO, "usage: exclude <input-file> <output-file> <line-number>\n", INVALID_ARGS_BYTES);
        _exit(EXIT_FAIL);
    }

    int in = open(argv[1], O_RDONLY, 0600); //open input file for reading

    int out = open(argv[2], O_WRONLY | O_CREAT, 0600); //open output file to write new copy

    if(argv[THIRD][0] == '-' || in < 0 || out < 0) { //makes sure line number is not negative and a postive integer and files could be made
        write(STDERR_FILENO, "usage: exclude <input-file> <output-file> <line-number>\n", INVALID_ARGS_BYTES);
        _exit(EXIT_FAIL);
    }

    int digits = 0; //counting how many digits the line number is
    int d = 0; //index to parse the line number as a string and start check for leading 0s
    while(argv[THIRD][d] && argv[THIRD][d] == '0') { //traverse line number to ignore leading 0s
        d++;
    }

    while(argv[THIRD][d]) { //traverse rest of line number string
        if(argv[THIRD][d] < '0' || argv[THIRD][d] > '9') { //make sure it is an integer
            write(STDERR_FILENO, "usage: exclude <input-file> <output-file> <line-number>\n", INVALID_ARGS_BYTES);
            _exit(EXIT_FAIL);
        }

        digits++; //increase how many digits the line number is
        d++; //check next digit
    }

    int line = 0; //the line number provided
    int i = 0; //marker to traverse the line number parameter

    while(argv[THIRD][i] && argv[THIRD][i] == '0') { //skip leading 0s
        i++;
    }

    while(digits != 0) { //multiply each value in a digits place by the correct 10s place
        
        int decPlace = 1;
        for(int p = digits; p > 1; p--) {
            decPlace = decPlace * 10;
        }

        digits--;
        line = line + ((argv[THIRD][i] - CHAR_SHIFT) * decPlace); //convert char to int value and calculate line number
        i++;
    }

    if(line < 1) {
        write(STDERR_FILENO, "usage: exclude <input-file> <output-file> <line-number>\n", INVALID_ARGS_BYTES);
        _exit(EXIT_FAIL);
    }

    char readIn[BYTE_READ]; //buffer to read file

    int lineCounter = 1; //starting line number to process input read in

    int bytes = read(in, readIn, BYTE_READ); //read first 64 bytes

    while(bytes != 0) { //until EOF
        int l = 0; //start of characters inside readIn

        while(l != bytes) { //until last byte read

            if(lineCounter != line) { //checks if current line processed should be written
                write(out, &readIn[l], 1);
            }

            if(readIn[l] == '\n') { //increments line position everytime a line break is found
                    //fprintf(stdout, "current line number: %d\n", lineCounter);
                    lineCounter++;
                    //fprintf(stdout, "now line number: %d\n", lineCounter);
            }

            l++;
        }

        bytes = read(in, readIn, BYTE_READ);
    }

    

    close(in);
    close(out);

    return EXIT_SUCCESS; //file successfully read
}