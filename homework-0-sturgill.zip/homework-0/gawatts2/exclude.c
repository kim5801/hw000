#include <unistd.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/stat.h>

//gcc -Wall -g -std=c99 -o exclude exclude.c to run at terminal 
//helper method upon failure - gives user a message and exits 1
void failure() {
  char messageFail[] = "usage: exclude <input-file> <output-file> <line-number>\n";
  write(STDOUT_FILENO, messageFail, sizeof( messageFail ) - 1 ); //-1 to ignore /0
 //system call to exit - 1 indicates failure
  _exit(1);
}


//helper method to get the size of a string 
int sizeOfString( char arr[] ) {
  int answer = 0;
  for ( int i = 0; arr[i] != '\0'; i++) {
    answer++;
  }
  return answer;
}



//return -1 if not valid or not a number representation
int stringToInteger( char s[] ) {
  int size = sizeOfString( s );
  //first loop to see if contents correct
  for ( int i = 0; i < size; i++ ) {
    int charactor = s[i]; //convert string char to decimal
    //not valid if not 0-9
    if ( charactor < '0' || charactor > '9') {
      return -1;
    }
  }
  //loop again - get answer - know they are all numbers
  int answer = 0;
  int worthHighestPlace = 1;
  for (int w = 0; w < size - 1; w++ ) {
    worthHighestPlace *= 10;
  }
  
  for ( int i = 0; i < size; i++ ) {
    int number = s[i] - '0'; 
    answer += worthHighestPlace * number;
    worthHighestPlace = worthHighestPlace / 10;
    
  }
  return answer;
}



//STDERR_FILENO write to standard error stream
//STDOUT_FILENO write for the console, used for testing before submission
//main function of the program
int main ( int argc, char *argv[] ) {

  // exit with 1 if not valid
  // arguments is program(always given), arg1(in), arg2(out), arg3(line) needed
  if ( argc != 4 ) {
    failure();
  }
  //wasn’t a positive integer
  int toInt = stringToInteger( argv[3] );
  if ( toInt == -1 ) {
    failure();
  }
  //program couldn’t open one of the given files
  int readFile = open( argv[1], O_RDONLY );
  if ( readFile < 0 ) {
    failure();
  }
  int writeFile = open( argv[2], O_WRONLY | O_CREAT , 0600);//can create file
  if ( writeFile < 0 ) {
    failure();
  }
  
  
  
  int startExclude = toInt - 1;
  char buffer[64];
  char line[64];
  int lineIdx = 0;
  int foundA = 0;
  //int foundB = 0;
  int lineCount = 0;
  //now read in the contents of the read file - 64 bits at a time - buffer[] wont be full on last call
  int readLength = read( readFile, buffer,  sizeof(buffer) );
  
  while ( readLength > 0 ) {
  
    for ( int i = 0; i < readLength; i++ ) {
      //special case remove is first line- wont work with implementation used
      if (toInt == 1 ) {
          if ( buffer[i] == '\n' && foundA == 0) {
            foundA = 1;
            continue; //so that the ending /n not copied over
          }
          if ( foundA == 1 ) {
            line[lineIdx] = buffer[i];
            lineIdx++;
          }
          
      } else {
              //take note of when /n is found
        if ( buffer[i] == '\n' ) {
          lineCount++;
          //found the starting point of the line to exclude
          if ( lineCount ==  startExclude ) {
            //place here because wont call to write this instance of /n
            line[lineIdx] = buffer[i];
            lineIdx++;
          
            foundA = 1;
          }
          //found the ending point of the line to exclude
          if ( lineCount == startExclude + 1 ) {
            foundA = 0;
            continue; //so that the ending /n not copied over
          }
        }
      
        if ( foundA == 0 ) {
          line[lineIdx] = buffer[i];
          lineIdx++;
        }
     } //else 

    }//for loop
    
    write( writeFile, line, lineIdx - 1); //write to the output file
    lineIdx = 0;
    readLength = read( readFile, buffer,  sizeof(buffer) );
  }

  //valid - if more than actual lines
  close(readFile);
  close(writeFile);
  return 0; //sucessful
}