#include <stdio.h> 
#include <string.h> //needed for strlen, strcmp
#include <unistd.h>
#include <stdlib.h> //to exit
#include <sys/types.h> //pid
#include <sys/wait.h> //wait parent



//helper
//return -1 if not valid or not a number representation
//better than atoi because atoi can return 0 upon failure
int stringToInteger( char s[] ) {
  int size = strlen( s );
  //first loop to see if contents correct
  for ( int i = 0; i < size; i++ ) {
    int charactor = s[i]; //convert string char to decimal
    //not valid if not 0-9
    if ( charactor < '0' || charactor > '9') {
      return -1;
    }
  }
  //loop again - get answer - know they are all numbers
  int answer = 0;
  int worthHighestPlace = 1;
  for (int w = 0; w < size - 1; w++ ) {
    worthHighestPlace *= 10;
  }
  
  for ( int i = 0; i < size; i++ ) {
    int number = s[i] - '0'; 
    answer += worthHighestPlace * number;
    worthHighestPlace = worthHighestPlace / 10;
    
  }
  return answer;
}

//prototype 
//to help call this helper method
void display();


// helper method is responsible for counting how many words are in line
// and add null terminators
int parseCommand( char *line, char *words[] ) {
  //printf("%ld\n", strlen(line) );
  int counter = 0;
  int booleanStartedLine = 0;
  int length = strlen(line);
  for (int i = 0; i < length; i++ ) {
    //go through the line to find the ind of start of word - add to words
    if ( line[i] != ' ' && booleanStartedLine == 0) {
      words[counter] = &line[i];
      counter++;
      booleanStartedLine = 1; //start found for word
    } 
    //find first idx of after end of word (blank space)
    if (line[i] == ' ' && booleanStartedLine == 1 ) {
      line[i] = '\0'; //needs to add null terminator
      booleanStartedLine = 0;
    }
  }
  return counter;
}




//helper method for exit with status given
//any invalid commands gets reprompt to user
//proper status must already be given (checked beforehand)
void runExit( char *words[], int count ) {
  if (count > 2) {
    printf("Invalid command\n");
    display();
  }
  exit(stringToInteger( words[1] ));
}



//helper method to change directory
//any invalid commands gets reprompt to user
void runCd( char *words[], int count ) {
  //words[0] is just cd
  //words[1] is path, more is invalid
  if (count > 2) {
    getchar(); //ignore the newline
    printf("Invalid command\n");
    display();
  }
  
  //could not change dir
  int change = chdir( words[1] );
  if ( change == -1 ) {
    getchar(); //ignore the newline
    printf("Invalid command\n");
    display();
  }
}



void runCommand( char *words[], int count ) {

}


//called when the user needs to give input, processed here
void display() {
  char displayStr[] = "stash> ";
  printf("%s", displayStr); //display to user to then start typing
  
  char lineBuffer[1024];
  scanf("%1024[^\n]s", lineBuffer); 
  
  
  char *w[512]; // array of pointer that point to a char
  int numWords = parseCommand(lineBuffer, w);

  //ignore blank given by the user
  while ( numWords == 0 ) {
    getchar(); //ignore the newline 
    printf("%s", displayStr); //display to user to then start typing
    scanf("%1024[^\n]s", lineBuffer); 
    numWords = parseCommand(lineBuffer, w);
  }
  
  //check if call cd
  int comparason = strcmp(w[0], "cd");
  if ( comparason == 0 ) {
    runCd( w, numWords);
  }
  //check if call exit
  comparason = strcmp(w[0], "exit");
  if ( comparason == 0 ) {
      int status = stringToInteger( w[1] );
      if ( status == -1 ) {
        getchar(); //ignore the newline
        printf("Invalid command\n");
        display();
      }
      runExit( w, numWords);
  }
  
  //done with checking for built in functions
  pid_t id = fork();

  // parent or the child? 
  if ( id == 0 ) {
    w[numWords + 1] = NULL; 
    
    int rtn = execvp( w[0], w);
    if ( rtn == -1 ) {
      getchar(); //ignore the newline
      printf("Can’t run command " );
      printf("%s", w[0]);
      printf("\n");
      display();
    }
    // If successful, we never get past the execl.
   
  } else {
    // wait for the child to finish.
    wait( NULL );

  }
  
}

//the starting point of the program and reads in arguments from command line
int main ( int argc, char *argv[] ) {

  display();
  
  return 0;
}