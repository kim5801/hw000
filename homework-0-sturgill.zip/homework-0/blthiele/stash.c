
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include<unistd.h> 

// declare functions
int parseCommand();
void runExit();
void runCd();
void runCommand();

int main( int argc, char *argv[] ) {

	// prompt user
	printf("%s ", "stash>");
	
	// define arrays
	char buffer[1024];
	char *commands[1024];

	
	while(fgets(buffer,1023,stdin)!= 0){
	
		// memory for array
		memset(commands, 0, sizeof commands);
		//memset(buffer, 0, sizeof buffer);
		// num of words in array
		int numWords = parseCommand(buffer,&commands);
		
	
		// check if exit is the first command given
			if (strcmp(commands[0],"exit")==0){
				
				runExit(commands,numWords);
			// check if cd is the command given	
			} else if (strcmp(commands[0],"cd")==0){
			
				runCd(commands, numWords);
			// if nothing is typed, ignore and reprompt
			} else if (strcmp(commands[0],"")==0){
				// ignore
			// run all other commands	
			} else {
				runCommand(commands, numWords);
			}
		// reprompt user 
		printf("%s ", "stash>");
	
	}
 
	return 0;


}

// parses the stdin given
int parseCommand( char *line, char *words[] ) {

	// number of words in line
	int numWords = 0;
	
	// number of chars in a line, used to iterate
	int x = 0;
	
	// keep track of indexes of words in the array
	int dex = 0;
	
	// while char is not null 
	while(line[x]){
		// if char is any of these, make it a null term
		if(line[x]==' ' || line[x] == '\n' || line[x] == '\0'){
			// set pointer top index of the beginning of that word
			words[numWords] = &line[dex];
			// set null term
			line[x]='\0';
			// add a word to array of pointers
			numWords++;
			// iterate through chars
			x++;
			// update index for beginning of next word
			dex = x;
		} else {
		// iterate through until finding a space, newline, or null term
			x++;
		}
    }
   // return num of words in array of pointers
	return numWords;
	


}

// for exiting the program
void runExit( char *words[], int count ){

	// exit must have 2 args
	if (count != 2){
		printf("%s\n","Invalid command");
	} else {
		// len of second arg
		int x = strlen(words[1])-1;
		int num = 0;
		int place = 1;
		int broken = 1;
		// got this code from my own program exclude.c
		
		// converts arg to numbers and adds them
		while(words[1][x]){
			// char must be integer
    		if ((words[1][x] > '9') || (words[1][x] < '0')){
    			printf("%s\n","Invalid command");
    			broken = 0;
    			break;
    		} else {
    			// adds based on placement in string / tens place
    			num += (words[1][x]-48) * place;
    			// updates place based on place in string
    			place *= 10;
    
    			// iterates through string
    		}
    		x--;
  		}
		// exits with the number we converted from a string
		if(broken){
			exit(num);
		}
	}
	

}

// runs the cd command
void runCd( char *words[], int count ){
	printf("%s\n","here2");
	// must have 2 args
	if (count != 2){
		printf("%s\n","Invalid command");
	// runs the command; if it returns an error, prints message
	} else if (chdir(words[1])!= 0) {
		printf("%s\n","Invalid command");
	}
	

}

// runs command
void runCommand( char *words[], int count ){
	printf("%s","here");
	// got from O2-OS-Structures lecture slides and children.c, provided to us
	int pid = fork();
	
	// if fork is successful, run command with execvp
	if(pid){
		execvp(words[0], words);
	}
	
}


