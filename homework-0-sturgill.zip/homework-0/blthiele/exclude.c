#include <fcntl.h>
#include <sys/types.h>
#include <sys/uio.h>
#include <unistd.h>


#include <stdio.h>
#include <stdlib.h>

int main( int argc, char *argv[] ) {

  int fin = open(argv[1], O_RDONLY);
  int fout = open(argv[2], O_WRONLY | O_CREAT | O_TRUNC, 0600);
  char buffer[64];
  
  int size = 0;
  
  // gets the size of argv[3] argument 
  while(argv[3][size]){
    size++;
  }
  
  int x = size-1;
  int place = 1;
  int num = 0;
  
  while(argv[3][x]){
    if ((argv[3][x] > '9') || (argv[3][x] < '0')){
    printf("%s","usage: exclude <input-file> <output-file> <line-number>");
    exit(1);
    }
    num += (argv[3][x]-48) * place;
    place *= 10;
    
    x--;
  }
  
  printf("%d",num);
  
  //number of new lines
  int newlinecount = 0;
  int reads = read(fin, buffer, 64);
  //int reads = read(fin, buffer, 64);
  // while the file can be read from, read each individual char
  while(reads > 0){
    for(int i = 0; i < reads-1; i++){
      // if this is a newline character, increase # of new lines
      if (buffer[i] == '\n'){
        newlinecount++;
        while(newlinecount == num){
        // moves past until hits next newline
          printf("%d %d %d\n", i, newlinecount, num);
          if (i >= reads){
            i=0;
            reads = read(fin, buffer, 64);
      	    if (buffer[i] == '\n'){
      	      printf("%s\n","here");
        	  newlinecount++;
          }
		}
      }
      }
    }
   
    write( fout, buffer, reads);
    reads = read(fin, buffer, 64);
  }

  close(fin);
  close(fout);
  
  
  return 0;
}