/**
 * @file stash.c
 * @author Eduardo Martinez
 * @brief This program emulates a shell program that allows various the user
 *        to input various commands to achieve various actions typically available
 *        through any shell program.
 * 
 */
#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <unistd.h>
#include <string.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <sys/wait.h>
#include <fcntl.h>

/** Value by which the list is multiplied whenever capacity is hit */
#define DOUBLE_LIST 2

/**
 * @brief Reads a line from a file input. Uses
 *        a dynamically expanding string to read any line.
 *        This is a slightly modified line reader I used 
 *        for my CSC 230 projects throughout the class.
 * 
 * @return the fully read line as a string
 */
char *readLine( FILE *fp )
{
    int capacity = 1;
    int ch;
    if ( ( ch = fgetc( fp ) ) == EOF ) {
        return NULL;
    }
    char *line = (char *)malloc( capacity * sizeof( char ) ) ;
    int len = 0;
    while ( ch != '\n' ) {
        if ( ( len + 1 ) >= capacity ) {
            capacity *= DOUBLE_LIST;
            line = (char *)realloc( line, capacity * sizeof( char ) );
        }
        line[ len++ ] = ch;
        ch = getc( fp );
    }
    if ( len > 1024 ) {
        return NULL;
    }
    line[ len ] = '\0';
    return line;    
}

/**
 * @brief parseCommand splits the initial command String into various Strings for a 2D array
 * 
 * @param line Initial single String
 * @param words 2D array containing the words
 * @return the amount of words discovered 
 */
int parseCommand( char *line, char *words[] ) {
    int length = strlen( line );
    int wordCount = 0;
    int len = 0;
    int capacity = 1;
    bool whiteSpace = false;
    words[ wordCount ] = (char *)malloc( capacity * sizeof( char ) ) ;
    for( int i = 0; i < length; i++ ) {
        words[ wordCount ][ len++ ] = line[ i ];
        if ( ( len + 1 ) >= capacity ) {
            capacity *= DOUBLE_LIST;
            words[ wordCount ] = (char *)realloc( words[ wordCount ], capacity * sizeof( char ) );
        }
        if ( line[ i ] == ' ' && whiteSpace == false ) {
            words[ wordCount ][ len - 1 ] = '\0';
            whiteSpace = true;
            len = 0;
            capacity = 1;
            wordCount++;
            words[ wordCount ] = (char *)malloc( capacity * sizeof( char ) ) ;
        }
        if ( line[ i ] != ' ' ) {
            whiteSpace = false;
        }
    }
    words[ wordCount + 1 ] = NULL;
    return wordCount;
}

/**
 * @brief runExit runs the exit() command with a provided custom integer value
 * 
 * @param words Command with possible integer value
 * @param count Amount of arguments for the command
 */
void runExit( char *words[], int count ) {
    bool invalid = false;
    if ( count >= 2 || count < 1 ) {
        printf( "Invalid command\n" );
        invalid = true;
    }
    int i = 0;
    int value = 0;
    while ( invalid == false && words[ 1 ][ i ] != '\000' ) {
        if ( ( words[ 1 ][ i ] < '0' || words[ 1 ][ i ] > '9' ) ) {
            printf( "Invalid command\n" );
            invalid = true;
        }
        if ( i == 0 ) {
            value = words[ 1 ][ i ] - '0';
        } else {
            value *= 10;
            value += words[ 1 ][ i ] - '0';
        }
        i++;
    }
    if ( invalid == false ) {
        for ( int i = 0; i < count; i++) {
            free( words[ i ] );
        }
        exit( value );
    }
}

/**
 * @brief runCd function uses the chdir() function to enact a cd action to
 *        move the user to certain folder
 * 
 * @param words Command with possible file path
 * @param count Amount of arguments for the command
 */
void runCd( char *words[], int count ) {
    // boolean value helps avoid repeating error message if both failure checks are triggered
    bool invalid = false;
    if ( count >= 2 ) {
        printf( "Invalid command\n" );
        invalid = true;
    }
    int value;
    if ( invalid == false ) {
        value = chdir( words[ 1 ] );
    }
    if ( value == -1 && invalid == false ) {
        printf( "Invalid command\n" );
    }

}

/**
 * @brief runCommand uses execvp() to run various shell commands
 *        depending on what words are passed via the arguments
 * 
 * @param words Command and possible add ons to that command
 * @param count Amount of arguments for the command
 */
void runCommand( char *words[], int count ) {
    int status = execvp( words[ 0 ], words );
    if ( status == -1 ) {
        printf( "Can’t run command %s\n", words[ 0 ] );
    }
    exit( status );
}

/**
 * @brief Starting point of the program
 * 
 * @return any positive integer upon exiting the program
 */
int main() {
    while( true ) {
        printf( "stash> " );
        char *line = readLine( stdin );
        if ( line != NULL ) {
            char *words[ 513 ];
            int wordCount = parseCommand( line, words );
            free( line );
            if ( strcmp( words[ 0 ], "cd" ) == 0 ) {
                runCd( words, wordCount );
            } else if ( strcmp( words[ 0 ], "exit" ) == 0 ) {
                runExit( words, wordCount );
            } else if ( strcmp( words[ 0 ], "" ) == 0 ) {

            } else {
                pid_t pid = fork();
                if ( pid == 0 ) {
                    runCommand( words, wordCount );
                } else {
                    wait( NULL );
                }
            }
        } else {
                printf( "Invalid command\n" );
        }
    }
    return EXIT_SUCCESS;
}