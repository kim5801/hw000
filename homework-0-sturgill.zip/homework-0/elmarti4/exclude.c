/**
 * @file exclude.c
 * @author Eduardo Martinez (elmarti4)
 * A program that through system calls can remove a line from a text file.
 * 
 */
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>

// Amount by which a value with multiple digits is multiplied in order to do slides
#define VALUE_TEN 10

// Required amount of arguments in order for the program to run
#define REQ_ARGS 4

// Bytes required to write the error message
#define ERR_BYTES 57

// Default amount of bytes read from an input file
#define READ_BYTES 64

/**
 * @brief removedLine function converts the argument of the line marked for removal
 *        from String to an integer. The function allows for numbers of multiple digits 
 *        to be accepted.
 * 
 * @param txtNumber String thatis being converted into an integer
 * @return the String, now integer value
 */
int removedLine( char *txtNumber ) {
    int actualNumber;
    int i = 0;
    // Go through a loop until the end of the string is encountered
    while ( txtNumber[ i ] != '\000' ) {
        // If a character is not a number, the program will display this error
        if ( txtNumber[ i ] < '0' || txtNumber[ i ] > '9' ) {
            write( STDERR_FILENO, "usage: exclude <input-file> <output-file> <line-number>\n", ERR_BYTES );
            _exit( 1 );
        }
        // First value is added as an integer
        // All consquent values are added after the original value is slid to the left
        if ( i == 0 ) {
            actualNumber = txtNumber[ i ] - '0';
        } else {
            actualNumber *= VALUE_TEN;
            actualNumber += txtNumber[ i ] - '0';
        }
        i++;
    }
    return actualNumber;
}

/**
 * @brief Starting point of the program
 * 
 * @param argc Amount of arguments
 * @param argv List of arguments as Strings
 * @return 0 on success, 1 on failure 
 */
int main( int argc, char *argv[] ) {
    if ( argc != REQ_ARGS ) {
        write( STDERR_FILENO, "usage: exclude <input-file> <output-file> <line-number>\n", ERR_BYTES );
        _exit( 1 );
    }
    int fp1 = open( argv[ 1 ], O_RDONLY );
    if ( !fp1 ) {
        write( STDERR_FILENO, "usage: exclude <input-file> <output-file> <line-number>\n", ERR_BYTES );
        _exit( 1 );
    }

    // This section of code reads through the input file to find the exact size of the input file
    int capacity = 0;
    char buffer[ READ_BYTES ];
    int addCapacity = READ_BYTES;
    int prevCapacity = 0;
    while ( addCapacity == READ_BYTES ) {
        addCapacity = read( fp1, &buffer, READ_BYTES );
        capacity += addCapacity;
    }

    // read is reset, and a new String with the exact size of the file is created
    lseek( fp1, 0, SEEK_SET );
    char fileCPY[ capacity ];
    capacity = 0;
    addCapacity = READ_BYTES;
    
    // read the file again to import the input file text into the String
    while ( addCapacity == READ_BYTES ) {
        addCapacity = read( fp1, &buffer, READ_BYTES );
        capacity += addCapacity;
        for ( int i = prevCapacity; i < capacity; i++ ) {
            fileCPY[ i ] = buffer[ i - prevCapacity ];
        }
        prevCapacity += addCapacity;
    }

    // This section of code uses a loop to find where in the buffer the line marked for removal is
    int lineCount = 0;
    int currentStartLine = 0;
    int startLine = 0;
    int endLine = 0;
    int line = removedLine( argv[ argc - 1 ] );
    for ( int i = 0; i < capacity + 1; i++ ) {
        if ( fileCPY[ i ] == '\n' ) {
            lineCount++;
            // The line marked for removal has been found
            if ( lineCount == line ) {
                startLine = currentStartLine;
                endLine = i;
            }
            currentStartLine = i;
        }
    }

    // This section of code removes the line marked for removal by 
    // moving all of the lines past it one level down
    for ( int i = startLine + 1; i < capacity; i++ ) {
        fileCPY[ i ] = fileCPY[ i + ( endLine - startLine ) ];
    }
    // Change the capcity to match the modified String
    capacity -= ( endLine - startLine );

    // Create the output file and insert the original text minus the removed line
    int fp2 = open( argv[2], O_RDWR | O_CREAT, 0600 );
    if ( !fp2 ) {
        write( STDERR_FILENO, "usage: exclude <input-file> <output-file> <line-number>\n", ERR_BYTES );
        _exit( 1 );
    }
    write( fp2, &fileCPY, capacity );

    // Close the files before ending the program
    close( fp1 );
    close( fp2 );

    return 0;
}
