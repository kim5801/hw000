/**
 * @file stash.c
 * @author Ethan Treece (eltreece)
 * 
 * The stash.c program stands for "simple toy assignment shell". It will have just a few of the features of
 * a typical shell program, but this will be enough to show how a program can use system calls to start new
 * programs and wait for them to finish. The user will be promted to enter commands, and the user can type
 * up to 1024 characters in length. Built in commands include 'cd' and 'exit'.
 * 
 */
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/wait.h>

#include <stdio.h>
#include <stdbool.h>
#include <string.h>
#include <stdlib.h>

/**
 * Checks if the character is a space
 * 
 * @param c character
 * @return true is a space
 * @return false not a space
 */
bool isSpace(char c) {
    return c == ' ' || c == '\t' || c == '\r' || c == '\v' || c == '\f';
}

/**
 * This function takes a user command (line) as input. As described above it breaks the line into
 * individual words, adds null termination between the words so each word is a separate string, and
 * it fills in a pointer in the words array to point to the start of each word. It returns the number
 * of words found in the given line. The words array should be at least 513 elements in length, so it
 * has room for the largest possible number of words that could fit in a 1024-character input line.
 * 
 * @param line line
 * @param words words
 * @return int number of words read
 */
int parseCommand( char *line, char *words[] ) {
    int counter = 0;
    int i = 0;
    bool isWord = false;
    while (line != NULL && line[i] != '\0') {
        if (isSpace(line[i])) {
            line[i] = '\0';
            isWord = false;
        } else if (!isWord) {
            words[counter] = &line[i];
            counter++;
            isWord = true;
        }
        i++;
    }
    return counter;
}

/**
 * This function performs the built-in exit command. The words array is the list of pointers to words
 * in the user’s command and count is the number of words in the array.
 * 
 * @param words words
 * @param count count
 */
void runExit( char *words[], int count ) {
    if (count != 2) {
        printf("Invalid command\n");
    } else {
        int status = atoi(words[1]);
        if (status == 0 && strcmp(words[1], "0") != 0) {
            printf("Invalid command\n");
        } else {
            exit(status);
        }
    }
    
}

/**
 * This function performs the built-in cd command. As with runExit(), the parameters give the
 * words in the command entered by the user.
 * 
 * @param words words
 * @param count count
 */
void runCd( char *words[], int count ) {
    if (count != 2) {
        printf("Invalid command\n");
    } else {
        int cd = chdir(words[1]);
        if (cd == -1) {
            printf("Invalid command\n");
        }
    }
}

/**
 * This function runs a (non-built-in) command by creating a child process and having it call execvp()
 * to run the given command.
 * 
 * @param words words
 * @param count count
 */
void runCommand( char *words[], int count ) {
    pid_t pid = fork();
    if (pid == 0) { 
        words[count] = NULL;
        int r = execvp(words[0], &words[0]);
        if (r == -1) {
            printf("Can't run command %s\n", words[0]);
        }
        exit(EXIT_SUCCESS);
    }
    wait(NULL);
}

/**
 * The main runs the program, repeatedly asking the user for input until exit.
 * 
 * @param argc number command line arguments
 * @param argv command line argument character array
 * @return int exit status
 */
int main( int argc, char *argv[] ) {

    printf("stash> ");
    char ch;

    while ( (ch = getchar()) != EOF) {

        char line[1025] = {0};
        char *words[513] = {0};

        // If the first read character is a new line, prompt user for
        // input again and go back to the start of the loop
        if (ch == '\n') {
            printf("stash> ");
            continue;
        }

        // Fills the line char array with user input until a new line
        int i = 0;
        while (ch != '\n') {
            line[i++] = ch;
            ch = getchar();
        }

        // c keeps the count of words read 
        int c = parseCommand(line, words);

        if (strcmp(words[0], "exit") == 0) {
            runExit(words, c);
        } else if (strcmp(words[0], "cd") == 0) {
            runCd(words, c);
        } else {
            runCommand(words, c);
        }

        printf("stash> ");
    }


    return EXIT_SUCCESS;
}
