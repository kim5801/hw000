/**
 * @file exclude.c
 * @author Ethan Treece (eltreece)
 * 
 * The exlude program allows the user to choose a line from an input text file to remove, and recieve an
 * output text file with that line removed.
 * 
 */
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>

/**
 * This program takes three command line arguments, the first being the input text file, second being the
 * output text file name, and the third being a positive integer representing the line number to remove. This
 * program is written using only Unix system calls.
 * 
 * @param argc number command line arguments
 * @param argv command line argument character array
 * @return int exit status
 */
int main( int argc, char *argv[] ) {

    //Error message
    char *err = "usage: exclude <input-file> <output-file> <line-number>\n";

    // If there are not exactly 4 command-line arguments, the program is invalid
    if (argc != 4) {
        write(STDERR_FILENO, err, sizeof(err));
        _exit(1);
    }

    // Get pointer to the 1s place digit, keeping track of how many places the pointer has moved
    char *num = argv[3];
    int count = 0;
    while (*num != '\0') {
        // If the last argument is not a positive integer, the program is invalid
        if (*num < 48 || *num > 57) {
            write(STDERR_FILENO, err, sizeof(err));
            _exit(1);
        }
        num++;
        count++;
    }

    // Add total up starting in 1s place, moving pointer to the left every loop
    // Multiply exp by 10 every loop cause the next digit to the left is worth 10x more
    num--;
    int exp = 1;
    int line = 0;
    while (count > 0) {
        line += (*num - 48) * exp;
        count--;
        num--;
        exp *= 10;
    }

    // Open input file for reading.
    int input = open( argv[1], O_RDONLY );
    if ( !input ) {
        write(STDERR_FILENO, err, sizeof(err));
        _exit(1);
    }

    // Create an output file for writing.
    int output = open( argv[2], O_CREAT | O_WRONLY | O_TRUNC, 0600 );
    if ( !output ) {
        write(STDERR_FILENO, err, sizeof(err));
        _exit(1);
    }

    // Read up to 64 bytes from the file.
    char buffer[ 64 ];
    int len = read( input, buffer, sizeof( buffer ) );

    int lineCounter = 1;
    // Keep printing out the contents of the buffer as long as we successfully
    // read something.
    while ( len > 0 ) {
        // We got a block of characters (bytes) from the file.  This
        // isn't a string, since read() doesn't automatically put a null
        // byte at the end.  So, we print each character one at a time.  The
        // return value tells us how many we got.
        for ( int i = 0; i < len; i++ ) {
            if ( lineCounter == line ) {
                while ( buffer[i] != '\n' && i < len) {
                    i++;
                }
                if (i != len)
                    lineCounter++;
            } else {
                if ( buffer[i] == '\n' ) {
                    lineCounter++;
                }
                write( output, &buffer[ i ], 1 );
            }
        }

        // Try to read up to 64 more bytes from the file.
        len = read( input, buffer, sizeof( buffer ) );
    }

    return 0;
}