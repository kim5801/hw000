/**
 * @file stash.c
 * @author Adam McIntosh
 *  
 * File for a simple shell program
 */

#include <stdio.h>
#include <ctype.h>
#include <stdlib.h>
#include <stdbool.h>
#include <string.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>

/** the maximum number of characters in a command */
#define MAX_COMMAND_SIZE 1024

/** the number of command-line arguments expected for the exit command */
#define NUM_ARGS_EXIT 2

/** the number of command-line arguments expected for the cd command */
#define NUM_ARGS_CD 2 

/** functions often return -1 for error, so we will have a constant for that */
#define DEFAULT_ERROR_VAL -1

/**
 * Frees each word in an array of pointers to words(chars)
 *
 * @param words the array of pointers to words
 * @param count the number of words
 */
void freeWords(char * words[], int count);

/**
 * Takes a user command and breaks it up into individual words. 
 * 
 * @param line the input command 
 * @param words an array of pointers to the words that are read in 
 * @return int the number of words read in 
 */
int parseCommand( char *line, char *words[] ) {

    int index = 0;
    int wordCount = 0;
    //traverse until we hit the new line
    while(line[index] != '\n') {
        while (isspace(line[index])) {
            index++;

            //we may have just pushed ourself to the very end of the line
            if (line[index] == '\n') {
                return wordCount;
            }
        }
        int wordLen = 0;
        while(!isspace(line[index + wordLen])) {
            wordLen++;
        }
        char* word = (char*)malloc(wordLen + 1);
        for (int i = 0; i < wordLen; i++) {
            word[i] = line[index + i];
        }
        word[wordLen] = '\0'; 
        index += wordLen;
        words[wordCount] = word;
        wordCount++;
    }
    return wordCount;
}

/**
 * Performs the exit command
 * 
 * @param words the words from the user's command
 * @param count the number of words in the words array
 */
void runExit( char *words[], int count ) {
    //validate number of arguments
    if (count != NUM_ARGS_EXIT) {
        fprintf(stdout, "Invalid command\n");
        freeWords(words, count);
        return;
    }
    //grab the status from the second argument
    char* intString = words[1];
    int intVal;
    int matches = sscanf(intString, "%d", &intVal);
    if (matches != 1) {
        fprintf(stdout, "Invalid command\n");
        freeWords(words, count);
        return;
    }

    //free the words array and exit with the given status
    freeWords(words, count);
    exit(intVal);
}

/**
 * Performs the cd command
 * 
 * @param words the words from the user's command
 * @param count the number of words in the words array
 */
void runCd( char *words[], int count ) {
    //validate number of arguments
    if (count != NUM_ARGS_CD) {
        fprintf(stdout, "Invalid command\n");
        freeWords(words, count);
        return;
    }

    //get path string and run command
    char* pathString = words[1];
    int ret = chdir(pathString);
    if (ret != 0) {
        //if chdir's return indicates that the command is invalid, we will report that
        fprintf(stdout, "Invalid command\n");
        freeWords(words, count);
        return;
    }

    //free the words array
    freeWords(words, count);
}

/**
 * Runs a non-built-in command by creating a child process and having it call execvp()
 * 
 * @param words the words from the user's command
 * @param count the number of words in the words array
 */
void runCommand( char *words[], int count ) {
    
    char* words2[count + 1];
    for (int i = 0; i < count; i++) {
        words2[i] = words[i];
    }
    words2[count] = NULL;
    if (strlen(words2[count - 1]) == 1 && words2[count - 1][0] == '&') {
        //run command in background
        //make sure to replace the & with null, so it doesn't end up as part of the command input
        words2[count - 1] = NULL;

        //create child process
        int p1 = fork();
        if (p1 != 0) {
            printf("[%d]\n", p1);
        }
        if (p1 == 0) {
            //child process
            //run the desired command
            int ret = execvp(words[0], words2);
            if (ret == DEFAULT_ERROR_VAL) {
                printf("Can't run command %s\n", words[0]);
            }
            //free words and exit the child process
            freeWords(words, count);
            exit(EXIT_SUCCESS);
        }
        //free words in the parent process
        freeWords(words, count);
    }
    else {
        //create a child process
        int p1 = fork();
        if (p1 == 0) {
            //child process
            //run the desired command
            int ret = execvp(words[0], words2);
            if (ret == DEFAULT_ERROR_VAL) {
                printf("Can't run command %s\n", words[0]);
            }
            freeWords(words, count);
            exit(EXIT_SUCCESS);
            }
            //free words in the parent process
            freeWords(words, count);
            //WAIT for the child process to finish
            wait(NULL);
    }
}

/**
 * Starts the shell program
 * 
 * @return int the exit status of the program
 */
int main() {
    //the loop will run indefinitely
    while(true) {
        printf("stash> ");

        //get and parse a command from the user
        char command[MAX_COMMAND_SIZE + 1];
        fgets(command, MAX_COMMAND_SIZE, stdin);
        char* words[MAX_COMMAND_SIZE / 2 + 1];
        int count = parseCommand(command, words);
        
        //run blank
        if (count == 0) {
            continue;
        }
        //run cd
        else if (strcmp(words[0], "cd") == 0) {
            runCd(words, count);
        }
        //run exit
        else if (strcmp(words[0], "exit") == 0) {
            runExit(words, count);
        }
        //run external
        else {
            runCommand(words, count);
        }
    }
    return EXIT_SUCCESS;
}

/**
 * Frees an array of pointers to chars
 *
 * @param words the array of words
 * @param count the number of words
 */
void freeWords(char * words[], int count) {
    for (int i = 0; i < count; i++) {
        free(words[i]);
    }
    //we do not need to free the actual array reference since it was not dynamically allocated
}