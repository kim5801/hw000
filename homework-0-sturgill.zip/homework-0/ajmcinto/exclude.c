/**
 * @file exclude.c
 * @author Adam McIntosh
 * File for a program that can copy all lines from one file to another excluding a specified line
 */

#include <fcntl.h>
#include <unistd.h>

/** our return value for exiting succesfully, must be defined because we don't have stdlib */
#define EXIT_SUCCESS 0

/** our return value for exiting on failure, must be defined because we don't have stdlib */
#define EXIT_FAIL 1

/** the expected number of command-line arguments for this program */
#define EXPECTED_NUM_ARGS 4

/** the maximum number of bytes that will be read into the buffer at a time */
#define BUFF_SIZE 64

/** number that can be passed to open() to give the user read, write, and execute permission */
#define PERMISSION_NUM 0700

/**
 * Returns the length of a string
 * 
 * @param str the string whose length is requested
 * @return int the length of the string
 */
int strlength(char* str) {
    int len = 0;
    while (str[len] != 0) {
        len++;
    }
    return len;
}

/**
 * Returns the integer value of a string that represents a positive integer
 * 
 * @param str the string to be converted to an int
 * @return int the integer value the string represents or -1 on invalid input
 */
int stringToInt(char* str) {
    //we will start from the beginning and work our way to the end
    int currentNum = 0;
    for (int i = 0; str[i]; i++) {
        //validate the digit 
        if (!(str[i] < '0' || str[i] > '9')) {
            currentNum = currentNum * 10 + str[i] - '0';
        }
        else {
            return -1;
        }

    }
    return currentNum;
}

/**
 * Starts the program that reads and writes lines excluding a line
 * 
 * @param argc the number of command line arguments
 * @param argv the command line arguments
 * @return int the exit status
 */
int main(int argc, char *argv[]) {

    char* errMessage = "usage: exclude <input-file> <output-file> <line-number>\n";

    //validate input
    if (argc != EXPECTED_NUM_ARGS) {
        write(STDERR_FILENO, errMessage, strlength(errMessage));
        _exit(EXIT_FAIL);
    }

    //the last argument is the one to be converted to an int
    char* num = argv[argc - 1];
    int excludeLine = stringToInt(num);
    if (excludeLine == -1) {
        write(STDERR_FILENO, errMessage, strlength(errMessage));
        _exit(EXIT_FAIL);
    }

    //set up our connection to the read file
    char* readFile = argv[1];
    int readFileNum = open(readFile, O_RDONLY);
    //make sure we could open the file
    if (readFileNum == -1) {
        write(STDERR_FILENO, errMessage, strlength(errMessage));
        _exit(EXIT_FAIL);
    }

    //set up our connection to the write file
    char* outFile = argv[2];
    int writeFileNum = open(outFile, O_WRONLY | O_CREAT | O_TRUNC, PERMISSION_NUM);
    //make sure we could open the file
    if (writeFileNum == -1) {
        write(STDERR_FILENO, errMessage, strlength(errMessage));
        _exit(1);
    }

    //the buffer we will use to store characters
    char buff[BUFF_SIZE];
    
    int len = -1;
    int lineNum = 1;
    do {
        len = read(readFileNum, buff, sizeof(buff));
        //we will write one character at a time to make management of lines easier
        for (int i = 0; i < len; i++) {
            if (lineNum != excludeLine) {
                write(writeFileNum, buff + i, 1);
            }
            if (buff[i] == '\n') {
                lineNum++;
            }
        }
    } while (len != 0);


    //close our files
    close(readFileNum);
    close(writeFileNum);

    //exit successfully
    _exit(EXIT_SUCCESS);

}

