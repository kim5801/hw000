/**
 * @file exclude.c
 * @author Abhinav Pratap - aspratap
 * copies input file to an output file with a certain line number excluded
 */
#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>

/** exit status when there is an error */
#define ERROR_STATUS 1

/** buffer size to read in */
#define BUFFER_SIZE 64

/** 
 * returns length of string
 * @param str the string to check
 * @return length of the string
 */
int str_len(char *str)
{
    int counter = 0;
    while (str[counter])
    {
        counter++;
    }

    return counter;
}

/**
 * prints error message to stderr and exits the program with a status of 1
 */
void error_func()
{
    char message[] = "usage: exclude <input-file> <output-file> <line-number>\n";
    write(STDERR_FILENO, message, str_len(message));
    _exit(ERROR_STATUS);
}

/**
 * converts a string to an int and returns the value
 * @param str the string to convert
 * @return the converted string
 */
int str_to_int(char *str)
{
    int multiplier = 1;
    int accumulator = 0;
    for (int i = str_len(str) - 1; i >= 0; i--)
    {
        int num = str[i] - '0';
        if (num < 0 || num > 9)
        {
            error_func();
        }
        accumulator += num * multiplier;
        multiplier *= 10;
    }

    return accumulator;
}

/**
 * copies input file to an output file with a certain line number excluded
 * @param argc the number of command line arguments
 * @param argv the arguments provided from the command line
 * @return exit status
 */
int main(int argc, char *argv[])
{
    if (argc != 4)
    {
        error_func();
    }

    int lineToSkip = str_to_int(argv[3]) - 1;

    if (lineToSkip < 0)
        error_func();

    int fd_input = open(argv[1], O_RDONLY);
    int fd_output = open(argv[2], O_RDWR | O_CREAT, S_IRWXU);

    if (fd_input == -1 || fd_output == -1)
    {
        if (fd_input != -1)
            close(fd_input);
        if (fd_output != -1)
            close(fd_output);
        error_func();
    }

    char buffer[BUFFER_SIZE];
    int lineCounter = 0;

    int toPrint = 0;

    int amountRead = read(fd_input, buffer, BUFFER_SIZE);

    while (amountRead > 0)
    {

        for (int i = 0; i < amountRead; i++)
        {
            if (buffer[i] == '\n') {
                lineCounter++;
            }

            if (lineCounter == lineToSkip) {
                toPrint = 0;
            }
            else {
                toPrint = 1;
            }

            if (toPrint != 0)
            {
                write(fd_output, &buffer[i], 1);
            }
        }

        amountRead = read(fd_input, buffer, BUFFER_SIZE);
    }

    close(fd_input);
    close(fd_output);
}
