/**
 * @file stash.c
 * @author Abhinav Pratap - aspratap
 *
 * basic shell called stash
 */

#include <stdio.h>
#include <unistd.h>
#include <ctype.h>
#include <stdbool.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <sys/wait.h>

/** max length of a command */
#define MAX_LINE_LENGTH 1024

/** max number of words that can be parsed from a line */
#define MAX_WORDS 513

/**
 * returns length of string
 * @param str the string to check
 * @return length of the string
 */
int str_len(char *str)
{
    int counter = 0;
    while (str[counter])
    {
        counter++;
    }

    return counter;
}

/**
 * converts a string to an int and returns the value. can only do positive numbers
 * @param str the string to convert
 * @return the converted string, -1 if failed
 */
int str_to_int(char *str)
{
    int multiplier = 1;
    int accumulator = 0;
    for (int i = str_len(str) - 1; i >= 0; i--)
    {
        int num = str[i] - '0';
        if (num < 0 || num > 9)
        {
            return -1;
        }
        accumulator += num * multiplier;
        multiplier *= 10;
    }

    return accumulator;
}

/**
 * takes a user command (line) as input and breaks it into individual words
 * @param line the line to parse
 * @param words the array to populate with the parsed words
 * @return number of words found in the given line
 */
int parseCommand(char *line, char *words[])
{
    int wordCounter = 0;
    int lineLen = str_len(line);

    if (lineLen < 1)
        return 0;

    bool newWord = true;

    for (int i = 0; i < lineLen; i++)
    {
        if (isspace(line[i]))
        {
            line[i] = '\0';
            newWord = true;
            continue;
        }

        if (newWord)
        {
            newWord = false;
            words[wordCounter] = &line[i];
            wordCounter++;
        }
    }

    words[wordCounter] = NULL;

    return wordCounter;
}

/**
 * performs the built in exit command
 * @param words the words given in user command
 * @param count number of words
 */
void runExit(char *words[], int count)
{
    if (count != 2)
    {
        printf("Invalid command\n");
        return;
    }

    int exitStatus = str_to_int(words[1]);

    if (exitStatus == -1)
    {
        printf("Invalid command\n");
        return;
    }

    exit(exitStatus);
}

/**
 * runs the built in cd command
 * @param words the words given in user command
 * @param count number of words
 */
void runCd(char *words[], int count)
{
    if (count != 2)
    {
        printf("Invalid command\n");
        return;
    }

    int cdStatus = chdir(words[1]);

    if (cdStatus == -1)
    {
        printf("Invalid command\n");
        return;
    }
}

/**
 * runs a non-built in command by creating a child process
 * @param words the words given in user command
 * @param count number of words
 */
void runCommand(char *words[], int count)
{
    int forkReturn = fork();
    if (forkReturn == -1)
    {
        printf("Can't run command %s\n", words[0]);
        return;
    }
    else if (forkReturn == 0)
    {
        execvp(words[0], words);
        printf("Can't run command %s\n", words[0]);
        exit(1);
    }
    else
    {
        wait(NULL);
    }
}

/**
 * starts a basic shell called stash
 * @param argc the number of command line arguments
 * @param argv the arguments provided from the command line
 * @return exit status
 */
int main(int argc, char *argv[])
{
    while (true)
    {
        printf("stash> ");
        // fflush(stdout);
        char line[MAX_LINE_LENGTH + 2];
        char *words[MAX_WORDS];
        // int numRead = read(STDIN_FILENO, line, MAX_LINE_LENGTH);
        char *readStatus = fgets(line, MAX_LINE_LENGTH + 2, stdin);
        if (readStatus == NULL)
            break;

        int wordCount = parseCommand(line, words);

        if (wordCount < 1)
            continue;

        if (strcmp("exit", words[0]) == 0)
        {
            runExit(words, wordCount);
        }
        else if (strcmp("cd", words[0]) == 0)
        {
            runCd(words, wordCount);
        }
        else {
            runCommand(words, wordCount);
        }
    }
}