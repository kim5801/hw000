/**
 * This program functions as a shell interface called stash (simple toy assignment shell).
 * The user can use the cd, exit, or any external commands from this shell.
 * @file stash.c
 * @author Isaac Dunn (ijdunn)
 */

#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <sys/wait.h>

/** Size of the line buffer that captures input from the command line */
#define BUFFER_SIZE 1024
/** Size of the array holding the addresses of each word */
#define WORDS_SIZE 513

/**
 * The parseCommand takes the input string from the user and splits each
 * word from whitespace and adds a pointer to it to the words array. The
 * function returns the number of words parsed from the input string.
 * @param line       The user input from the command-line
 * @param words      The words array to put each word into
 * @return numWords  The number of words from the input
 */
int parseCommand( char *line, char *words[] ) {
  int numWords = 0;
  // Extract the first word from line
  char *word = strtok( line, " \t\r\n\v\f" );
  // Extract the rest of the words from line and put them into the words array
  while ( word != NULL ) {
    words[numWords++] = word;
    word = strtok( NULL, " \t\r\n\v\f" );
  }
  // Return number of words parsed
  return numWords;
}

/**
 * This function will run the exit command with the given error code.
 * The exit command has one argument for the exit status to use. The function
 * will parse the string into an integer. If the command is invalid, the function
 * will print to stdout.
 * @param words  The array of words holding the command arguments
 * @param count  The number of words parsed
 */
void runExit( char *words[], int count ) {
  int exitCode;
  // If cannot parse the integer exit code, print to stdout
  // Otherwise, run the exit command with the given exit code
  if ( sscanf( words[1], "%d", &exitCode ) != 1 ) {
    printf( "Invalid command\n" );
  } else {
    exit( exitCode );
  }
}

/**
 * This function will run the cd command in the shell. It only takes one
 * input: the path of the directory to change to. If the user enters an invalid
 * number of arguments, an error message will print to stdout.
 * @param words  The array of words holding the command arguments
 * @param count  The number of words parsed
 */
void runCd( char *words[], int count ) {
  if ( chdir( words[1] ) == -1 ) {
    printf( "Invalid command\n" );
  }
}

/**
 * Any other command is run through run command. The parent creates a child
 * that will run the command and terminate while the parent waits. If the command
 * is invalid, an error message prints to stdout.
 * @param words  The array of words holding the command arguments
 * @param count  The number of words parsed
 */
void runCommand( char *words[], int count ) {
  // Adds NULL after the last word in the words array for execvp
  words[ count ] = NULL;
  // The new child process runs the command
  // The parent waits for the child process to complete
  int pid = fork();
  if ( pid == 0 ) {
    // Attempts to run the command, if command is invalid, print error message to stdout
    if ( execvp( words[0], words ) == -1 ) {
      printf("Invalid command\n");
      exit(-1);
    }
    exit(0);
  } else {
    wait( NULL );
  }
}

/**
 * The main method prompts the user for input, reads the input from stdin,
 * and runs the command based on what is parsed by parseCommand().
 * @return  Exit code
 */
int main() {
  // Infinite loop to prompt the user, can only be exited using exit command
  for( ;; ) {
    // Prints prompt and reads input into the buffer
    printf("stash> ");
    // Initialize buffer and read input from stdin
    char buffer[BUFFER_SIZE];
    fgets( buffer, BUFFER_SIZE, stdin );
    
    // Initialize words array
    char *words[WORDS_SIZE];
    // Parse commands into words
    int numWords = parseCommand( buffer, words );
    
    // Determine which command to run
    if ( numWords == 0 ) {
      // If no words where parsed, reprompt
    } else if ( strcmp( words[0], "exit" ) == 0 && numWords == 2 ) {
      runExit( words, numWords );
    } else if ( strcmp( words[0], "cd" ) == 0 && numWords == 2 ) {
      runCd( words, numWords );
    } else {
      runCommand( words, numWords );
    }
  }
}
