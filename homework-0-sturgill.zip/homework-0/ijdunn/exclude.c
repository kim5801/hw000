/**
 * This program uses Unix system calls to read an input file
 * from command line arguments and removes the given line number
 * from the input file and prints the output to an output file.
 * @file exclude.c
 * @author Isaac Dunn (ijdunn)
 */

#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>

/** The ASCII value for zero ( 0 ) */
#define ASCII_ZERO 48
/** The ASCII value for nine ( 9 ) */
#define ASCII_NINE 57
/** The size of the buffer reading and writing to the files */
#define BUFFER_SIZE 64

/**
 * Reads the input from the third command line argument to parse into an
 * integer. Reads the argument as a string and determines its integer value
 * using ASCII codes. This will accept leading zeros, but it will not except
 * negative numbers, octal, or hexadecimal values.
 * @param string  The string to parse into an integer
 * @return value    The value of the integer from the parsed string, -1 if invalid argument
 */
int parseInt( char *string ) {
  int i = 0;
  int value = 0;

  // Continue looping until end of string
  while ( string[i] != '\0' ) {
    if ( string[i] >= ASCII_ZERO && string[i] <= ASCII_NINE ) {
      // If the ASCII value is a number, parse its value and add it to the return value
      // value is multiplied by ten to shift the numbers to the next place
      value = value * 10 + ( string[i] - ASCII_ZERO );
      i++;
    } else {
      // Returns -1 if the input is invalid
      return -1;
    }
  }
  return value;
}

/**
 * The main method uses the command line arguments to use the file paths and
 * the line number to parse. Using the designated line number, the contents of
 * the input file are copied to the output file without the specified line.
 * @param argc  Number of command line arguments
 * @param argv  Command line arguments
 * @return      Exit code value, 0 if success, -1 if failure
 */
int main( int argc, char *argv[] ) {
  // Open the input file and create the output file
  int inputFD = open( argv[1], O_RDONLY, 0600 );
  int outputFD = open( argv[2], O_WRONLY | O_CREAT, 0600 );

  // Parses the third command line argument to determine the specified line number
  int excludeLine = parseInt( argv[3] );

  // If the files cannot open, invalid number of command line arguments, or third argument
  // is invalid, print usage message and exit with status of -1
  if ( inputFD == -1 || outputFD == -1 || argc != 4 || excludeLine <= 0 ) {
    write( STDERR_FILENO, "usage: exclude <input-file> <output-file> <line-number>\n", BUFFER_SIZE );
    _exit( -1 );
  }

  // Creates buffer, line number counter, and bytes read counter
  char buffer[ BUFFER_SIZE ];
  int lineNumber = 1;
  int bytesRead = 0;

  do {
    // Reads the input file, 64 bytes at a time, counting the number of new lines
    bytesRead = read( inputFD, buffer, BUFFER_SIZE );
  
    // Loops through each character in the buffer
    for (int i = 0; i < bytesRead; i++ ) {
      // If NOT on the line to exclude, write the character to the output file
      // Characters will not be written if on the line to exclude
      if ( lineNumber != excludeLine) {
        write( outputFD, buffer + i, 1 );
      }
      // If a new line character is found, increment the count
      if ( buffer[i] == '\n' ) {
        lineNumber++;
      }
    }
  } while ( bytesRead > 0 );
  // Close the files and exit
  close ( inputFD );
  close( outputFD );
  _exit( 0 );
}
