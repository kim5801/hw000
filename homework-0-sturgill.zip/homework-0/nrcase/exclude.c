#include <fcntl.h>
#include <unistd.h>

int lineNum = 1; // global vars to update
int line = 1;
char *error = "usage: exclude <input-file> <output-file> <line-number>";

static int getLength(char *string) // homemade strlen function
{
    int length = 0;
    while (string[length] != '\0')
    {
        length++;
    }

    return length;
}

static void isValid(char *check) // checks if the characters are valid in the buffer
{
    int end = getLength(check);

    for (int i = 0; i < end; i++)
    {
        if (check[i] < 48 || check[i] > 57) // only letters
        {
            write(STDERR_FILENO, error, 55);
            _exit(1);
        }
    }
}

static int getLineNum(char *lineArgs) // converts from string to int
{

    int num = 0;
    int end = getLength(lineArgs);

    isValid(lineArgs);

    for (int i = 0; i < end; i++)
    {
        num = num * 10 + (lineArgs[i] - 48); // converty thing
    }
    return num;
}

int main(int argc, char **argv)
{

    if (argc != 4)
    {
        write(STDERR_FILENO, error, 55);
        return 1;
    }

    int readId = open(argv[1], O_RDONLY);
    int writeId = open(argv[2], O_WRONLY | O_CREAT | O_APPEND, 0600); // opens write with create and append because need to create the file
    // and need to write char by char so both needed

    line = getLineNum(argv[3]);

    if (readId == -1 || writeId == -1)
    {
        write(STDERR_FILENO, error, 55);
        return 1;
    }

    char buffer[64];

    for (int i = 0; i < 64; i++) // clearing the buffer
    {
        buffer[i] = ' ';
    }

    int bytesIn = read(readId, buffer, 64);

    while (bytesIn > 0)
    {
        for (int i = 0; i < bytesIn; i++)
        {
            if (buffer[i] == '\n') // finding the new lines or the ends of lines
            {
                line++;
            }
            if (lineNum != line) // writing the char if not on the line that want to exclude
            {
                write(writeId, &buffer[i], 1);
            }
        }
        bytesIn = read(readId, buffer, 64); // read the next buffer in
    }
    close(writeId);
    close(readId);
    return 0;
}
