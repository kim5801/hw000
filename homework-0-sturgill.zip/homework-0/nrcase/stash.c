#include <fcntl.h>
#include <unistd.h>
#include <stdlib.h>
#include <stdio.h>
#include <stdbool.h>
#include <string.h>
#include <sys/wait.h>
#include <assert.h>

char *command;

char *readLine(FILE *fp) // readLine from CSC230 project 4, written by Nick Case, implementation given by CSC230 teaching staff
{                        // remember to close this
    char ch = 0;
    int capacity = 10;
    int len = 0;
    char *str = (char *)malloc(capacity * sizeof(char) + 1);
    while (fscanf(fp, "%c", &ch) == 1)
    {
        if (ch == 0 || ch == EOF)
        {
            return NULL;
        }
        if (ch >= 1 && ch <= 31)
        {
            break;
        }

        if (len >= capacity)
        {
            capacity *= 2;
            str = (char *)realloc(str, capacity * sizeof(char) + 1);
        }

        assert(len < capacity);

        str[len++] = ch;
    }
    str[len] = '\0';
    return str;
}

int parseCommand(char *line, char *words[]) // works
{
    int numWords = 0;
    const char delim[2] = " ";
    char *token;

    token = strtok(line, delim); // get first token, breaking apart by spaces

    while (token != NULL) // iterate over all the other tokens
    {
        words[numWords] = token; // save word
        numWords++;
        token = strtok(NULL, delim); // keep going
    }
    return numWords;
}

void runExit(char *words[], int count) // works
{
    int status;
    int match = sscanf(words[1], "%d", &status); // turns string into int
    if (count != 2 || match != 1)
    {
        printf("Invalid command\n");
    }
    else
    {
        free(command); // free the command right before exit
        exit(status);
    }
}

void runCd(char *words[], int count)
{
    if (count != 2)
    {
        printf("Invalid command\n");
    }
    else
    {
        int end = chdir(words[1]); // try to change directory
        if (end == -1)
        {
            printf("Invalid command\n");
        }
    }
}

void runCommand(char *words[], int count)
{
    words[count] = NULL; // null at end to make sure know end of array
    if (fork() == 0)     // create child
    {
        int status = execvp(words[0], words); // run new program on child
        if (status == -1)
        {
            printf("Can't run command %s\n", words[0]);
        }
        exit(0);
    }
    else
    {
        wait(NULL);
    }
}

int main(int argc, char **argv)
{
    bool done = false; // looping variable
    int num;
    while (!done)
    {
        char *words[512];
        printf("stash> ");
        command = readLine(stdin);
        num = parseCommand(command, words);

        if (strcmp("cd", words[0]) == 0) // doing cd
        {
            if (num != 2) // error checking
            {
                printf("Invalid command\n");
                free(command);
                continue;
            }
            runCd(words, num); // running cd
        }
        else if (strcmp("exit", words[0]) == 0) // running exit
        {
            if (num != 2)
            {
                printf("Invalid command\n");
                free(command);
                continue;
            }
            runExit(words, num);
        }
        else if (strcmp("\n", command) == 0 || strcmp(" ", command) == 0 || strcmp("", command) == 0) // blank command or other jazz similar
        {
            free(command);
            continue;
        }
        else
        {
            runCommand(words, num); // run external commands
            free(command);
            continue;
        }
        free(command);
    }
}
