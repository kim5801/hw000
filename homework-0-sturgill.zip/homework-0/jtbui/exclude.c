/**
 * @file exclude.c
 * @author Jessica Bui (jtbui)
 */
#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <stdio.h>

#define MAX_ARGS 4
#define TENS_PLACE 10
#define ASCII_CONVERT 48
#define MAX_BITS 64

int main( int argc, char *argv[] ) {

    if (argc > MAX_ARGS) {
        write(STDERR_FILENO, "usage: exclude <input-file> <output-file> <line-number>\n", 56);
        _exit(1);
    }

    /** Reading a file */
    int forRead = open(argv[1], O_RDONLY);

    if (forRead < 0) {
        write(STDERR_FILENO, "usage: exclude <input-file> <output-file> <line-number>\n", 56);
        _exit(1);
    }

    /** Writing a file */
    int forWrite = open(argv[2], O_WRONLY | O_CREAT, 0600);
    /** Line number of input file */
    int lineNum = 0;
    /** To keep traack of what line the reader is on */
    int lineCount = 1;

    int numDigits = 0;

    while (argv[MAX_ARGS - 1][numDigits] != '\0') {
        int numb = argv[MAX_ARGS - 1][numDigits] - ASCII_CONVERT;
        if (numb > TENS_PLACE - 1 || numb < 0) {
            write(STDERR_FILENO, "usage: exclude <input-file> <output-file> <line-number>", 56);
            _exit(1);
        }
        lineNum = lineNum * TENS_PLACE + numb;
        ++numDigits;
    }

    char fileLine[MAX_BITS];
    int good = read(forRead, fileLine, sizeof(fileLine));

    while (good > 0) {

        for (int i = 0; i < good; ++i) {
            if (lineCount != lineNum) {
                write(forWrite, &fileLine[i], 1);
            }
            if (fileLine[i] == '\n') {
                ++lineCount;
            }
        }

        good = read(forRead, fileLine, sizeof(fileLine));
    }

    close(forRead);
    close(forWrite);
}