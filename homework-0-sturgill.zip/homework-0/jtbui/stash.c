/**
 * @file stash.c
 * @author Jessica Bui (jtbui)
 */
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <stdbool.h>
#include <ctype.h>
#include <sys/types.h>
#include <sys/wait.h>

#define MAXCHAR 1025
#define MAXWORDS 513

int parseCommand(char *line, char *words[]) {
    int count = 0;
    words[count] = &line[0];
    ++count;

    for (int i = 0; i < strlen(line); ++i) {
        if (isspace(line[i]) != 0) {
            line[i] = '\0';
            words[count] = &line[i + 1];
            ++count;
            while (isspace(line[i]) != 0) {
                ++i;
            }
        }
    }

    return count - 1;
}

void runExit(char *words[], int count) {
    if (count != 1) {
        printf("Invalid command\n");
        return;
    }

    int num;

    if (sscanf(words[1], "%d", &num) != 1) {
        printf("Invalid command\n");
        return;
    }

    exit(num);
}

void runCd(char *words[], int count) {
    if (count != 1) {
        printf("Invalid command\n");
        return;
    }
    // int suc = chdir(words[1]);

    if (chdir(words[1]) < 0) {
        printf("Invalid command\n");
        return;
    }
}

void runCommand(char *words[], int count) {
    if (strcmp(words[0], "cd") == 0) {
        runCd(words, count);
        return;
    }
    else if (strcmp(words[0], "exit") == 0) {
        runExit(words, count);
        return;
    }

    int run = fork();

    if (run < 0) {
        printf("Can't run command ");
        for (int i = 0; i < count + 1; ++i) {
            printf("%s ", words[i]);
        }
        printf("\n");
        exit(1);
    }
    else if (run == 0) {
        int suc = execvp(words[0], words);
        if (suc < 0) {
            printf("Can't run command ");
            for (int i = 0; i < count + 1; ++i) {
                printf("%s ", words[i]);
            }
            printf("\n");
            exit(1);
        }
    }
    else {
        wait(NULL);
    }
}

int main(void) {
    bool conti = true;

    while (conti) {
        printf("stash> ");
        char command[MAXCHAR];
        char *words[MAXWORDS];
        char val;
        int count = 0;
        int numCommand;

        while ((val = fgetc(stdin)) != '\n' && val != EOF) {
            command[count] = val;
            ++count;
        }

        command[count] = '\0';

        if (command[0] == ' ' || command[0] == '\n') {
            continue;
        }

        numCommand = parseCommand(command, words);

        runCommand(words, numCommand);
    }
}