#include <sys/types.h>
#include <unistd.h>
#include <sys/wait.h>
#include <sys/stat.h>
#include <fcntl.h>

#define MAX_BUFFER 64

/**
* Error function for any instance of wrong input in program
*/
static void error() {
  char* error = "usage: exclude <input-file> <output-file> <line-number>";
  write(STDERR_FILENO, error, sizeof(error) - 1);
  _exit( 1 );
}

/**
* This program takes an input file and then prints the data in the input file
* to a specified output file, and leaves out a user-indicated line
* @author Ethan Gilbert
*/
int main( int argc, char *argv[] ) {

    //Checking validity of command line arguments
    if(argc != 4) {
        error();
    }

    //Converts line number argument to integer
    //Goes through each character, changes from ASCII character code to decimal value, until it reaches terminator
    int i = 0;
    int num = 0;
    while(argv[3][i] != '\0') { 
        num = num * 10 + argv[3][i] - '0';
        if(num < 0) {
            error();
        }
        i++;
    }

    //Open file to read from
    int reader = open(argv[1], O_RDONLY);

    //Check that reader was opened, error if not
    if(reader < 0) {
        error();
    }

    //Open file to write to
    int writer = open(argv[2], O_WRONLY | O_CREAT | O_TRUNC, 777);

    //Check that writer was opened, error if not
    if(writer < 0) {
        error();
    }

     // Create buffer to read up to 64 bytes
    char buffer[ MAX_BUFFER ];

    //Start on line one
    int line = 1;

    //Set buffer length
    int length = MAX_BUFFER;

    //While there are bytes to read
    while(length == MAX_BUFFER) {

      //Read however many bytes there are
      length = read( reader, buffer, sizeof( buffer ) ); //Reading 64 bytes at a time

      for(int i = 0; i < length; i++) {
      
        //Increment line count at each line break
        if(buffer[i] == '\n') {
          line++;
        }

        //If the line is not one to be removed, write to output file
        if(line != num) { 
          write(writer, buffer + i, 1);
        }
      }
   
    }
    

  // Closing the read and write files
  close( reader );
  close( writer );

  return 0;
    
}
