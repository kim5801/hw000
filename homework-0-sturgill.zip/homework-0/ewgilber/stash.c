#include <sys/types.h>
#include <sys/stat.h>
#include <sys/wait.h>
#include <fcntl.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <unistd.h>
#include <stdbool.h>
#include <ctype.h>

/**
*  This program creates a shell program that takes in user input and processes it
*  to use external system calls and my own cd and exit calls
*  @author Ethan Gilbert
*/

/** Maximum number of words in array */
#define MAXWORDSIZE 513

/** Maximum number of characters inputted in array */
#define MAXCHARSSIZE 1024

/** 
* Takes in user input command line input, breaks it into individual words, adds
* null termination between words, and fills in a pointer in words array to 
* point to start of each word
*
* @param line Line to parse
* @param words Array to be filled in with parsed line input
* @return Number of words found in given line
*/

int parseCommand ( char *line, char *words[]) {

  int count = 0; //Word counter
  char* pointer; //Pointer

  //Add first word from line to words array
  pointer = strtok(line, " "); 
  words[0] = pointer;
  count++;

  //While pointer is not null, continue through user input, adding input to words array
  while(pointer != NULL) {
    pointer = strtok(NULL, " ");
    words[count] = pointer;
    count++;
  }
  
  // Avoid index error
  count--;

  return count;
}

/**
 * Performs built-in exit command
 *
 *@param words List of pointers to words in user's command
 *@param count Number of words in the array
 */

void runExit (char *words[], int count) {

  //Confirm that second input is a number
  if(!isdigit(*words[1])) { 
    printf("Invalid command\n");
  }

  //Confirm there are only 2 words
  else if(count != 2) {
    printf("Invalid command\n");
  }

  //Convert 2nd word to integer to exit with that number
  else {
    int number = atoi(words[1]);
    _exit(number);
  }

}

/**
 * Uses chdir() system call to change to specified directory
 *
 *@param words cd and directory 
 *@param count Number of words in the array
 */

void runCd (char *words[], int count) {

  // Confirm that there are only two words
  if(count != 2) {
    printf("Invalid command\n");
  }

  //Change directory and check that directory change is successful
  else if(chdir(words[1]) != 0) {
    printf("Invalid command\n");
  }

}

/**
 * Creates a child process to call execvp() to run given command
 *
 *@param words The command the child will run
 *@param count Number of words in the array
 */

void runCommand (char *words[], int count) {

  // Create new child
  pid_t child = fork();
  
  //Check that child was created
  if(child  == -1) {
    printf("%s%s\n", "Can't run command", words[0]);

  //If child was created successfully, run execvp of specific user input
  } else if(child == 0) {
    words[count] = NULL;
    // Run specified function or if function does not exist, error
    if(execvp(words[0], words) == -1) {
        printf("%s%s\n", "Can't run command", words[0]);
        _exit(1);
    };
  }

  //Wait for child to finish
  else {
    wait(NULL);
  }
}

/**
 * Main function calls defined functions based on user input in stash
 */

int main() {

  //Creating maximum sized line and words
  char *words[MAXWORDSIZE];
  char  line[MAXCHARSSIZE];

  //Will run until exitted
  while(1) {
    //Prompt user
    printf("stash> ");

    //Saving user input to line
    if(scanf("%[^\n]%*c", line) == 0) {
      getchar();
      continue;
    }

    //Calls parse commands and saves the number of words in user input
    int numWords = parseCommand(line, words);
    
    // If user has opted to exit, calls runExit function, resets while loop with continue
    if(strcmp(words[0], "exit") == 0) {
      runExit(words, numWords);
      continue;
    }

    // Else if user has opted to cd, calls runCd function, resets while loop with continue
    else if(strcmp(words[0], "cd") == 0) {
      runCd(words, numWords);
      continue;
    }

    // Else user will call external function, calls runCommand function, resets while loop with continue
    else {
      runCommand(words, numWords);
      continue;
    }
  }

  return 0;
}