#include <stdio.h>
#include <stdbool.h>
#include <string.h>
#include <unistd.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/types.h>
#include <sys/wait.h>

/**
 * gets a command from the user and parses it to run the specified command
 * @param line the array to store the command in
 * @param words the array of pointers to point to each word in the command
 */ 
int parseCommand(char *line, char*words[]){

    //get user input
    printf("%s", "stash> ");
    fgets(line, 1024, stdin);

    //the index the words array is on
    int wordsIndex = 0;

    //skip over leading spaces
    int count = 0;
    while(line[count] == 32) count++;

    //mark the first word in the words array
    words[wordsIndex++] = &(line[count]);

    //flag to hold if the previous space should be replaced with a null
    bool replacePrev = false;
    //flag to hold if multiple spaces needed to be skipped (a few in a row)
    bool skipSpaces = false;
    //while we are not at a newline
    while(line[count] != 10){
        //replace the previous space with a null
        if(replacePrev){
            line[count - 1] = 0;
            replacePrev = false;
        }
        //skip spaces (multiple spaces were in a row)
        if(skipSpaces && line[count] == 32){
            count++;
            continue;
        }
        //the start of a word is found after space(s)
        if(skipSpaces && line[count] != 32){
            skipSpaces = false;
            //mark start of word
            words[wordsIndex++] = &(line[count]);
        }
        //if we find a space
        if(line[count] == 32){
            replacePrev = true;
            skipSpaces = true;
        }

        count++;
    }

    //add a null to the end
    if(line[count-1] != 32){
        line[count] = 0;
        line[count+1] = 10;
    }
    return wordsIndex;
}

/**
 * runs if exit is called
 */
void runExit(char *words[], int count){
    //ensures they gave the right number of paramaters
    if(count != 2){
        printf("%s", "Invalid command\n");
    }
    else{
        //convert to int from string
        int status = atoi(words[1]);
        //checks if there is an error
        //it returns 0 on error so a check had to be made to ensure the user did not enter 0
        if(*(words[1]) != '0' && status == 0){
            printf("%s", "Invalid command\n");
        }
        else{
            exit(status);
        }
    }
}

/**
 * runs when cd is called
 */ 
void runCd(char *words[], int count){
    int status = chdir(words[1]);
    if(count != 2 || status == -1){
        printf("%s", "Invalid command\n");
    }
}

/**
 * runs a command thats not one of the built in ones
 */ 
void runCommand(char *words[], int count){
    //add null to end
    words[count] = 0;
    //create a new process
    pid_t pid = fork();
    //child process
    if(pid == 0){
        if(execvp(words[0], words) == -1){
            printf("Can't run command %s\n", words[0]);
        }
        exit(0);
    }
    //parent
    else{
        wait(NULL);
    }
}

int main(){
    //loop until exit is called
    while(1){
        //arrays to hold commands
        char line[1025];
        char * words[513];
        int wordsFound = parseCommand(line, words);
        
        if(strcmp(words[0], "exit") == 0){
            runExit(words, wordsFound);
        }
        else if(strcmp(words[0], "cd") == 0){
            runCd(words, wordsFound);
        }
        else if (strcmp(words[0], "") == 0){
            continue;
        }
        else{
            runCommand(words, wordsFound);
        }
    }
}