#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>

/**
 * Function to run error code when invalid args are given
 */
void invalidArgs(){
    write(STDERR_FILENO, "usage: exclude <input-file> <output-file> <line-number>\n", 57);
    _exit(1);
}

/**
 * Converts a string to a integer if possible
 * @param str the string to convert to a int
 * @return int the converted integer
 */
int convertToInt(char *str){
    //find length of string
    int i = 0;
    while(str[i] != 0){
        //if a digit is not in the string it is invalid
        if(str[i] < 48 || str[i] > 57){
            invalidArgs();
        }
        i++;
    }

    //go through the string backwards and create the integer
    int multiplier = 1;
    int num = 0;
    while(i >0){
        num += (str[--i] - 48) * multiplier;
        multiplier*=10;
    }

    //0 is an invalid number for this program
    if(num == 0){
        invalidArgs();
    }

    return num;
}

/**
 * Reads a input file, and outputs the text to a different file, excluding the line number given as a argument
 * All done using system calls
 * @param argc number of command line arguments given
 * @param argv a list of command line arguments
 * @return int status
 */
int main(int argc, char *argv[]){
    if(argc != 4){
        invalidArgs();
    }

    //Convert number to int
    int lineToSkip = convertToInt(argv[3]);

    //Try and open input file
    int inputFile = open(argv[1], O_RDONLY);
    if(inputFile == -1){
        invalidArgs();
    }

    //Try and open output file
    int outputFile = open(argv[2], O_WRONLY|O_CREAT|O_TRUNC, 0600);
    if(outputFile == -1){
        invalidArgs();
    }

    //read through the file and store 64 bytes at a time in this buffer
    char buffer[64];
    ssize_t readBytes = read(inputFile, buffer, 64);
    //the line the program is on
    int line = 1;
    //keep reading until nothing is left to be read
    while(readBytes != 0){
        //array to hold characters that need to be output
        char charsToWrite[64];
        int writeIndex = 0;
        //go through characters read from file
        for(int i = 0; i < readBytes; i++){
            //put characters not on the line to skip in the array to write
            if(line != lineToSkip){
                charsToWrite[writeIndex++] = buffer[i];
            }
            //if we get to a newline, increment the current line
            if(buffer[i] == 10){
                line++;
            }
        }
        //write all characters in the output array
        write(outputFile, charsToWrite, writeIndex);
        //read the next set of characters
        readBytes = read(inputFile, buffer, 64);
    }


    //close files
    close(inputFile);
    close(outputFile);
}






