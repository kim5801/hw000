// this header is needed for system calls like read
#include <unistd.h>
// include header for open system call
#include <fcntl.h>

// argc will be equal to 4 when the command line is valid
#define ARG_COUNT 4
// invalid input
#define INVALID_INPUT 1
// this is the size of the error message
#define ERROR_MSG_SIZE 56
// the size of our buffer
#define BUFFER_SIZE 1

// this is a function to convert a string number to integer number 
int convertToInt( char *number ) 
{
    // the value of the number
    int val = 0;

    // the number of iterations 
    int iteration = 0; 

    // start with the left most digit
    char current = number[iteration++]; 

    // iterate through every value 
    while( current ) 
    {
        // determine the validity of the current character
        if( current >= '0' && current <= '9') {
            // the input character is valid
            // the previously read character needs to be left shifted
            val  *= 10; 

            // increment value by the current rightmost integer read
            val += current - '0';
        }

        else {
            // otherwise the input was not valid and you should return -1 for failure
            return INVALID_INPUT; 
        }

        // increment current 
        current = number[iteration++];
    }

    // return the value 
    return val; 

}


int main ( int argc, char *argv[] )
{
    // ensure only 3 arguments are passed
    // this means argc will equal 4 (because the program name is included)
    if ( ! ( argc == ARG_COUNT ) ) {
        // print error message
        char *err = "usage: excluse <input-file> <output-file> <line-number>\n";
        // this writes the output to standard output (the file descriptor for standard output is defined)
        write( STDERR_FILENO, err, ERROR_MSG_SIZE);
        // exit with failure 
        _exit( INVALID_INPUT );
    }

    // pass the first paramater as the input to open
    int readFile = open( argv[1], O_RDONLY );
    // ensure the file was read in
    if ( readFile < 0 ) {
        // print error message
        char *err = "usage: excluse <input-file> <output-file> <line-number>\n";
        // this writes the output to standard output (the file descriptor for standard output is defined)
        write( STDERR_FILENO, err, ERROR_MSG_SIZE);
        // exit with failure 
        _exit( INVALID_INPUT );
    }

    // pass the second paramater to create, which is the equivalent of open( file, O_CREAT | O_WRONLY | O_TRUNC , 0600)
    int writeFile = creat( argv[2], 0600 );
    // ensure the file was opened
    if ( writeFile < 0 ) {
        // print error message
        char *err = "usage: excluse <input-file> <output-file> <line-number>\n";
        // this writes the output to standard output (the file descriptor for standard output is defined)
        write( STDERR_FILENO, err, ERROR_MSG_SIZE);
        // exit with failure 
        _exit( INVALID_INPUT );
    }

    // this is the line to skip
    int lineToSkip = convertToInt( argv[3] );

    // read the readfile and write to the writefile
    char buffer[BUFFER_SIZE];

    int currentLine = 1; 

    // read the file until you reach the new line character
    while ( read( readFile, buffer, 1) > 0 ) {
        // only add the byte to the file if the old line was not 
        if( currentLine != lineToSkip) {
            write( writeFile, buffer, 1);
        }
        // check for new line character 
        if( *buffer == '\n') {
            currentLine++;
        }
    }
    
    // close the files
    close( readFile );
    close( writeFile );
}
