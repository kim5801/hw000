// this is the c standard library
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <ctype.h>
#include <stdbool.h>
// these are system calls libraries
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>

// the maximum allowed length of the input including the null terminator
#define MAX_INPUT_LENGTH 1025
// invalid input
#define INVALID_INPUT -1
// the maximum possible length for the words array
#define WORDS_ARRAY 513

int parseCommand( char *line, char *words[] ) 
{
    // keep track of the number of words parsed
    int wordCount = 0;
    
    // sameWord flag
    bool sameWord = false;

    // set the length of the string up here
    int length = strlen( line );

    // iterate through every word in line
    for( int i = 0; i < length ; i++) {
        // handle non whitespace character
        if( !isspace( line[i] ) && !sameWord ) {
            // we're starting a new word
            sameWord = true;

            // add pointer to the beginning of this word and post increment wordcount 
            words[wordCount++] = &line[i];
        }
        // handle whitespace character
        else if ( isspace( line[i] ) && sameWord ) {
            // change the current character to the null terminator
            line[i] = '\0';

            // make sameWord false 
            sameWord = false;
        }
    }

    // return the number of words parsed
    return wordCount; 
}


void runExit( char *words[], int count ) 
{
    // create an exit status variable
    int exitStatus;
    
    // check exit status and only 2 arguments are passed
    if( count != 2 || (exitStatus = atoi( words[1] )) == 0 ) {
        // prompt invalid command
        printf("Invalid command\n");
    }
    else {
        // exit program
        printf("The else executed\n");
        exit( exitStatus );
        printf("And the after also executed, but there was no exit");
    }
}

void runCd( char *words[], int count ) 
{
    // try to change directory
    // we use 2 because only 2 arguments are allowed: cd and the directory
    if ( count != 2 || chdir ( words[1] ) == -1 ) {
        // print error message
        printf("Invalid command\n");
    }
}

void runCommand( char *words[], int count ) 
{
    // change the count element in word to be NULL 
    words[count] = NULL;

    // fork a child process
    pid_t childID = fork();

    // For this part of the code, I referenced this guide right here: 
    // http://www.cs.ecu.edu/karl/4630/sum01/example1.html
    // This is similar but not exactly the same as the code in the guide

    // conditionally run code depending on which process is running
    if( childID == 0 ) {
        // child process
        // execute the command
        if( execvp( words[0], words ) == -1) {
            // if execvp returns, it failed
            printf("Can't run command %s\n", words[0]);
        };
    }
    else {
        // parent process
        // wait for the child process to finish
        waitpid( childID, NULL, 0 );
    }
}

int main ( int argc, char *argv[] ) 
{
    // create a buffer that supports max input length
    char buffer[MAX_INPUT_LENGTH];
    // make an array of char pointers 
    char *words[WORDS_ARRAY];

    // this will run until the user exits the program
    while ( true ) {
        // clear the buffer with null terminators
        memset( buffer, '\0', MAX_INPUT_LENGTH);

        // prompt the user for input
        printf("stash> ");

        // strcpy(buffer, "exit -1");
        // get up to 1024 bytes of user input and store it in the buffer
        fgets( buffer, MAX_INPUT_LENGTH, stdin );
        
        // parse the input into words
        int count = parseCommand( buffer, words );
        
        // only execute if some arguments are passed
        if ( count > 0) {
            // check if the first word is exit
            if( strcmp( words[0], "exit" ) == 0 ) {
                // run the exit command
                runExit( words, count );
            }
            // check if the first word is cd
            else if ( strcmp( words[0], "cd" ) == 0 ) {
                // run the cd command
                runCd( words, count );
            }
            else {
                // run the command
                runCommand( words, count );
            }
        }
    }
}
