#include <unistd.h>
#include <fcntl.h>


/** Gets the power of two numbers
 * @param x the base
 * @param y the power
 * @return the computed power function
 */
int calcPower(int x, int y) {
    int rtn = 1;
    for (int i = 0; i < x; i++) {
        rtn *= y;
    }
    return rtn;
}

/** Main method for exclude
 * @param argc the number of command line arguments
 * @param argv list of command line arguments
 * @return the program exit status
 */
int main( int argc, char *argv[] ) {
    //Parse the line number from command line arguments
    char *lineNum = argv[3];
    char counter = lineNum[0];
    int num = 0;
    int len = 0;
    while (counter != '\0') {
        len++;
        counter = lineNum[len];
    }
    //Parse to an integer
    char ch = lineNum[0];
    for (int i = 0; i <  len; i++) {
        if (ch >= '0' && ch <= '9') {
            num += (ch - '0') * calcPower(i, 10);
        } else {
            write(STDERR_FILENO, "Invalid line number\n", sizeof(char) * 21);
            _exit(29);
        }
        ch = lineNum[i];
    }

    //Read in input file
    int infile = open(argv[1], O_RDONLY, 0600);
    if (infile < 0) {
        write(STDERR_FILENO, "Cannot open the input file.\n", sizeof(char) * 23);
        _exit(29);
    }
    int outfile = open(argv[2], O_CREAT | O_WRONLY, 0600);
    if (outfile < 0) {
        write(STDERR_FILENO, "Cannot open the output file.\n", sizeof(char) * 23);
        _exit(29);
    }
    char buffer[64] = {};
    int count = 1;
    int amt = read(infile, buffer, 64);
    while(amt == 64) {
        
        for (int i = 0; i < amt; i++) {
            if (buffer[i] == '\n') {
                count++;
            }
            if (num != count) {
                write(outfile, &(buffer[i]), 1);
            }
        }
        amt = read(infile, buffer, 64);
    }
    write(outfile, buffer, amt);

    close(infile);
    close(outfile);
}
