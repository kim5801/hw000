#include <stdlib.h>
#include <stdbool.h>
#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/wait.h>

int parseCommand( char *line, char *words[] ) {
    //scanf ("%[^\n]s", line);
    fgets(line, 100, stdin);
    int count = 1;
    int letterCount = 0;
    int wordCount = 0;
    char word[500] = {};
    char ch = line[0];
    //parse input, store in an array of pointers to strings
    while (ch != '\0') {
        word[letterCount] = ch;
        if (ch == ' ' || ch == '\n') {
            wordCount++;
            words[wordCount - 1] = (char *)malloc(100);
            strncpy(words[wordCount - 1], word, letterCount);
            letterCount = 0;
            ch = line[count];
        } else {
            ch = line[count];
            letterCount++;
        }
        count++;
    }
    //wordCount++;
    //word[count] = '\0';
    //words[wordCount - 1] = word;
    return wordCount;
}

void runExit( char *words[], int count ) {
    if (words[1] == NULL) {
        printf("Invalid command\n");
        return;
    }
    int status = atoi(words[1]);
    if (status == 0) {
        printf("Invalid command\n");
        return;
    }
    exit(status);
}

void runCd( char *words[], int count ) {
    int x = chdir(words[1]);
    if (x == -1 || count != 2) {
        printf("Invalid command\n");
    }
}

void runCommand( char *words[], int count ) {
    words[count] = ((void *)0);
    int rtn;
    if (strstr(words[count - 1], "&") ) {
        //Remove the asterisk from the arguments array
        char *newWords[100] = {}; 
        for (int i = 0; i < count; i++) {
            newWords[i] = words[i];
        }
        //Run execvp
        int id = getpid();
        if (id == 0) {
            rtn = execvp(newWords[0], newWords);
        }
    } else {
        int id = fork();
        if (id == 0) {
            rtn = execvp(words[0], words);
            wait(&id);
        }
    }
    if (rtn == -1) {
        printf("Can’t run command %s\n", words[0]);
        return;
    }
    fflush(stdout);
}

/** Main method for stash shell program.
 * @param argc the number of command line arguments
 * @param argv list of command line arguments
 * @return the program exit status
 */
int main( int argc, char *argv[] ) {
    char line[1024] = {}; //input from the user
    char *words[100] = {};
    int wordCount = 1;
    write(STDOUT_FILENO, "stash> ", 8);
    while(wordCount) {
        wordCount = parseCommand(line, words);
        if (strcmp(words[0], "cd") == 0) { //change directory
            runCd(words, wordCount);
        } else if (strcmp(words[0], "exit") == 0) { //exits the program
            runExit(words, wordCount);
        } else if (words[0] == NULL) {
            continue;
        } else {
            runCommand(words, wordCount);
        }
        write(STDOUT_FILENO, "stash> ", 8);
        
    }
    return 0;
}