#include <fcntl.h>
#include <unistd.h>
int len(char* str) {
  int count = 0;

  for(int i = 0; str[i]; i++) {
      count++;
  }
  return count;
}

int main(int argc, char *argv[]) {
    int pid1 = open(argv[1], O_RDWR);
    int pid2 = open(argv[2], O_RDWR | O_CREAT, 0600);
 
    if(pid1 < 0 || pid2 < 0) {
      char* errMsg = "usage: exclude <input-file> <output-file> <line-number>\n";
      write(STDERR_FILENO, "usage: exclude <input-file> <output-file> <line-number>\n", len(errMsg));
      _exit(1);
    }
    
    char* lineNumStr = argv[3];
    int lineNum = 0;
    int k = 0;
    for(int i = len(lineNumStr) - 1; i >= 0; i--) {
      if(k == 0) {
        lineNum += lineNumStr[i] - 48; 
      } else {
        lineNum += (lineNumStr[i] - 48) * (k * 10);
      }
      k++;
    }

    if(lineNum <= 0) {
      char* errMsg = "usage: exclude <input-file> <output-file> <line-number>\n";
      write(STDERR_FILENO, "usage: exclude <input-file> <output-file> <line-number>\n", len(errMsg));
      _exit(1);
    } 

    int bytes = 64;
    int count = 0;
    while(bytes == 64) {
       char buffer[64];
       bytes = read(pid1, buffer, 64);
       
       for(int i = 0; i < bytes && buffer[i]; i++) {
        if(buffer[i] == '\n') {
           count++;
        }
        if(count != lineNum - 1 && buffer[i] != '\1') {
          write(pid2, &buffer[i], 1); 
        }
       }
 
    } 

   
    return 0; 
}


