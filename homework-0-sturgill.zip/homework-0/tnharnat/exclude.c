#include <fcntl.h>
#include <unistd.h>

int main(int argc, char *argv[]) {
    
    // If passed with anything but 4 arguments, must be wrong
    if (argc != 4) {
        write(STDERR_FILENO, "usage: exclude <input-file> <output-file> <line-number>", 55);
        _exit(1);
    }

    int lineI;
    int expo = 1;
    int digits = -1;
    // count the number of chacters in the line number parameter
    for (int i = 0; argv[3][i]; i++) {
        digits++;
    }
    // check each character is a digit, and if it is, add it to the number conversion
    for (int i = digits; argv[3][i]; i--) {
        if (argv[3][i] < '0' || argv[3][i] > '9') {
            write(STDERR_FILENO, "usage: exclude <input-file> <output-file> <line-number>", 55);
            _exit(1);
        }
        lineI += (argv[3][i] - '0') * expo;
        expo *= 10;
    }

    // try to open files
    int rfid = open(argv[1], O_RDONLY);
    int wfid = open(argv[2], O_WRONLY|O_CREAT|O_TRUNC, 0600);
    if(rfid == -1 || wfid == -1) {
        write(STDERR_FILENO, "usage: exclude <input-file> <output-file> <line-number>", 55);
        _exit(1);
    }

    // print out the input file, ignoring all characters between the correct two null terminators
    char block[64] = {0};
    int lineCount = 0;
    int charsRead = read(rfid, block, 64);
    while(charsRead) {
        for (int i = 0; i < charsRead; i++) {
            if (block[i] == '\n')
                lineCount++;    
            if (lineCount == lineI - 1)
                continue;
            write(wfid, &block[i], 1);
        }
        charsRead = read(rfid, block, 64);    
    }

}