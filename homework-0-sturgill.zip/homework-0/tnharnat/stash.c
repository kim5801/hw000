#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h>
#include <fcntl.h>
#include <unistd.h>
#include <sys/wait.h>

/**
 * @brief takes in a user input line, and an empty array of char pointers, and converts all whitespace
 * to null terminators, pointing a pointer in words to the start of each argument. Returns the 
 * number of words
 * 
 * @param line user input line
 * @param words empty character pointer array
 * @return int the number of words
 */
int parseCommand( char *line, char *words[] ){
    int len = strlen(line);
    int wordCounter = 0;
    if(line) {
        words[wordCounter] = &line[0];
        wordCounter++;
    }
    for (int i = 0; i < len; i++) {
        if(isspace(line[i])) {
            line[i] = '\0';
            continue;
        }
        else if(!isspace(line[i]) && i != 0 && !line[i - 1]) {
            words[wordCounter] = &line[i];
            wordCounter++;
        }
        else {
            continue;
        }
    }

    return wordCounter;
}

/**
 * @brief runs the exit command
 * 
 * @param words words array containing arguments
 * @param count the number of args
 */
void runExit( char *words[], int count ){
    int errCode;
    if(count != 2 || sscanf(words[1], "%d", &errCode) != 1) {
        printf("Invalid Command\n");
    }
    else {
        _exit(errCode);
    }
}

/**
 * @brief runs the cd command
 * 
 * @param words words array containing arguments
 * @param count the number of args 
 */
void runCd( char *words[], int count ){
    char pathname[1025] = {0};
    if(count != 2 || sscanf(words[1], "%s", pathname) != 1) {
        printf("Invalid command\n");
    }
    else {
        if(chdir(pathname) == -1)
            printf("Invalid command\n");
    }
}

/**
 * @brief Runs all other commands through a child process using execvp.
 * Runs a program in the background if the last argument is an ampersand.
 * 
 * @param words words array containing arguments
 * @param count the number of args
 */
void runCommand( char *words[], int count ){
    int pid = fork();
    if (pid == 0) {
        if(*words[count - 1] == '&')
            words[count - 1] = NULL;
        if(execvp(words[0], words) < 0) {
            if(*words[0])
                printf("Can't run command %s\n", words[0]);
            exit(100);
        }
    }
    else {
        int pidBack = 0;
        if (*words[count - 1] == '&') {
            printf("[%d]\n", pid);
            pidBack = waitpid(-1, NULL, WNOHANG);
            if (pidBack)
                printf("[%d Done]\n", pidBack);
        }
        else {
            pidBack = waitpid(-1, NULL, WNOHANG);
            if (pidBack)
                printf("[%d Done]\n", pidBack);
            waitpid(pid, NULL, 0);
        }
        
    }
}

/**
 * @brief prompts for user input, directing the parsed command to the correct function.
 * 
 * @return int status
 */
int main(void) {
    while(1) {
        printf("stash> ");
        char line[1025] = {0};
        fgets(line, 1024, stdin);
        char * words[1025] = {0};
        int wordCount = parseCommand(line, words);
        if (!strcmp("cd", words[0]))
            runCd(words, wordCount);
        else if (!strcmp("exit", words[0]))
            runExit(words, wordCount);
        else
            runCommand(words, wordCount);
    }
}