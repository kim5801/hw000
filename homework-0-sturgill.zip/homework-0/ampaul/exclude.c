#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>
#include <stdio.h>
#include <fcntl.h>

/*
 * Parses int value from command line parameter
 */
int parse( char* str)
{
  int len = 0;
  int loop = 1;
  while(loop) {
    if(str[len] != '\0') {
      len++;
    }
    else {
      loop = 0;
    }
  }

  int sum = 0;

  int place = 1;
  for(int i = len; i > 0; i--) {

    sum = sum + (((int)str[i - 1] - 48) * place);

    place *= 10;

  }

  return sum;
}

int main( int argc, char *argv[] ) {

  if(argc != 4) { //check amount of arguments passed
    write(STDERR_FILENO, "usage: exclude <input-file> <output-file> <line-number>\n", 56);
    _exit(1);
  }

  //read from a file
  int in = open( argv[1], O_RDONLY);

  // write to a file
  int out = open( argv[2], O_WRONLY | O_CREAT, 0600 );

  int exclude = parse(argv[3]) - 1; //index of line to exclude

  if(out == -1 || in == -1 || exclude < 0) {
    write(STDERR_FILENO, "usage: exclude <input-file> <output-file> <line-number>\n", 56);
    _exit(1);
  }

  char buffer[10];
  int val = 1;
  int line = 0;

  while(val) {
    val = read(in, buffer, 1); //read 1 character
    if(val != 0 && buffer[0] == 0x0a) { //count line numbers by new line char
      line++;
    }
    if(val != 0 && line != exclude)   { //decide whether to write char
      write(out, buffer, 1); //write char to file
    }
  }

  //close open files
  close( in );
  close( out );
  return 0;
}
