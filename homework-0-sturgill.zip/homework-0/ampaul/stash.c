#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <stdbool.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <ctype.h>

// Parses entered line into words
int parseCommand( char *line, char *words[] ) {
  int idx = 0;
  char s[2] = " ";
  char *read;

  // breaks string into tokens
  read = strtok(line, s);
  while(read != NULL) {
    words[idx] = read;
    idx++;
    read = strtok(NULL, s );
  }

  return idx; //return num of words
}

//Exits with given status
void runExit( char *words[], int count ) {

  char *check;

  if(count != 2) { //check for correct number of parameters
    printf("Invalid command\n");
  }
  else {
    int status = strtol(words[1], &check, 10); //Parses integer from string

    if(strlen(check) != 0) {
      printf("Invalid command\n");
    }
    else {
      exit(status);
    }
  }

}

//Runs cd command with given parameter
void runCd( char *words[], int count ) {

  int val = 0;

  if(count != 2) {
    printf("Invalid command\n");
  }
  else {
    val = chdir(words[1]);
  }

  if(val == -1) {
    printf("Invalid command\n");
  }

}

//Creates a child to run system command
void runCommand( char *words[], int count ) {
    words[count] = NULL;

    pid_t id = fork();

    if(id == 0) {
      int val = execvp(words[0], words);

      if(val == -1) { //invalid command check
          fprintf(stderr, "Can't run command %s\n", words[0] );
      }

      exit(0);
    }
    else {
      wait(NULL); //wait for child to finish
    }
}

int main (int num, char *args[] )
{

    bool quit = false;
    char *words[513];

    while( !quit ) {

        printf( "stash> " );
        char line[1025];
        fgets(line, 1024, stdin); //get line from user and add null terminator
        line[strlen(line) - 1] = '\0';


        int num = parseCommand(line, words);
        words[num] = '\0';

        if(words[0] == NULL) { //check for empty string
          continue;
        }
        else if(strcmp(words[0], "cd") == 0) { //check for cd command
          runCd(words, num);
        }
        else if(strcmp(words[0], "exit") == 0) { //check for exit command
          runExit(words, num);
        }
        else {
          runCommand(words, num);
        }

      }

    return 0;
}
