#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <sys/wait.h>
#include <fcntl.h>
#include <unistd.h>

// Keep track of background commands that are going and finished
static pid_t backgroundCommands[1024];

int isspace(char letter) 
{
    if(letter == 0x20) {
		    return 1;
		} else {
		    return 0;
		}
}

int parseCommand(char *line, char *words[]) 
{
    int flag = 1;
    int index = 0;
    int wordStarted = 0;
    int wordIndex = 0;
    int wordLength = 0;
    if(!line) {
		    return wordIndex;
		}
    while(flag) {
		    flag = 0;
	      if(line[index] != 0x00) {
	          if(wordStarted) {
						    if(isspace(line[index]) || line[index] == 0x0A) {
								    line[index] = 0x00;
		 	 			        wordStarted = 0;	 	 		
										wordIndex++; 	        
								} else {
								    wordLength++;
								}
						} else {
						    if(!isspace(line[index])) {
								    wordStarted = 1; 
		 			          words[wordIndex]= line + index;
								}
						}
				    flag = 1;
	 	        index++;
				}
		}
	  return wordIndex;
}

void runExit(char *words[], int count) 
{
    if(count != 2) {
		    printf("Invalid command\n");
		} else {
		    int status = atoi(words[1]);
		    exit(status);
		}
}

void runCd(char *words[], int count)
{
    if(count != 2) {
		    printf("Invalid command\n");
		} else {
		    int path = chdir(words[1]);
        if(path == -1) {
		        printf("Invalid command\n");
	    	}
		}
}

void runCommand(char *words[], int count)
{
    words[count] = NULL;
    pid_t childPID = fork();
   
	  if(strcmp(words[count - 1], "&") == 0) {
		    words[count - 1] = NULL;
		    if(childPID == 0) {
		        execvp(words[0], words);
			      printf("Can't run command %s\n", words[0]);
	    	} else if(childPID > 0) { // Returns the ID of the child process to the parent
    	      int flag = 1;
            int i = 0;
            while(flag) {
						    flag = 0;
	 	 	          if(backgroundCommands[i]) {
								    i++;
										flag = 1;	
						    }
						}
 				    printf("[%d]\n", childPID);
		 		    backgroundCommands[i] = childPID;
				}
		} else {
		    if(childPID == 0) {
		        execvp(words[0], words);
			      printf("Can't run command %s\n", words[0]);
	    	}
		}
}

char *getLine() 
{
    int flag = 1;
    char *list = (char *)malloc(1024);
    char letter;
    int index = 0;
    while(flag) {
		    flag = 0;
        letter = getchar();
        if(letter != EOF && letter != 0x0A) {
				    list[index] = letter;
			      index++;
		        flag = 1;
				} else if(letter == 0x0A) {
				    list[index] = 0x0A;
				}
		}
	  return list;
}

void reportFinishedCommands() 
{

     int status;
     for(int i = 0; backgroundCommands[i]; i++) {
		     pid_t commandStatus =  waitpid(backgroundCommands[i], &status, 0x00 | WNOHANG);
	       if(commandStatus == backgroundCommands[i]) {
				     printf("[%d done]\n", backgroundCommands[i]);
				 }
		 }    
}

int main(int argc, char *argv[])
{
    int flag = 1;
    int numWords = 0;
    char *words[513];
    while(flag) {
		    flag = 0;
      	printf("\nstash> ");
	      char *input = getLine();
	      numWords = parseCommand(input, words);
				      
				if(numWords == 0) {
				    flag = 1;
				} else if(strcmp(words[0], "cd") == 0) {
	          runCd(words, numWords);
				    flag = 1;
				} else if (strcmp(words[0], "exit") == 0) {
				    runExit(words, numWords);
			      flag = 1;
				} else if(strcmp(words[0], "") == 0 ) {
				    flag = 1;
				} else {
				    runCommand(words, numWords);
				    reportFinishedCommands();
				    flag = 1; 
				}
		}
}


















