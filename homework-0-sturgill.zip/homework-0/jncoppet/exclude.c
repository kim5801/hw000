#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>

int main( int argc, char *argv[] ) {
		// Create buffer to store read calls
    char buffer[] = "----------------------------------------------------------------";
    char *lineNum;
    int line = 0;
    // Determine which line to omit
    if(argc == 4) {
            if(*argv[3] - 48 <= 0) {
						    write(STDERR_FILENO, "usage: <input-file> <output-file> <line-number>\n", 48);
	 			        _exit(1);
						} else {
						    lineNum = argv[3];
						}
    				
		} else {
		    write(STDERR_FILENO, "usage: <input-file> <output-file> <line-number>\n", 48);
	      _exit(1);
		}
    
    // Determines the number of digits in the lineNum string
    int lineDigits = 0;
    int flag = 1;
    int i = 0;
    while(flag) {
		    flag = 0;
	      if(lineNum[i] != '\0') {
				    lineDigits++;
		 	      flag = 1;
	          i++; 
				}
		}
	  
    // Loop through until line lineNum as an int
	  for(int i = 0; i < lineDigits; i++) {
        // Move the place we are adding a digit in. Line starts at 0 so ones place will be hit.
		    line = line * 10;
		 
		    // Adds the decimal represnetation of the char (0-9 have ASCII values 48-57 so substract 48 to get 0-9)
		    line = line + (lineNum[i] - 48);
		}
		 
    // Create and open the output file which will be written over
    int fpo = open(argv[2], O_WRONLY | O_CREAT, 0600);
    if (fpo == -1) {
      write(STDERR_FILENO, "usage: <input-file> <output-file> <line-number>\n", 48);
      _exit(1); // Terminate program if the output could not be opened
    }
    int fpi = open(argv[1], O_RDONLY | O_CREAT, 0600);
    if(fpi == -1) {
      write(STDERR_FILENO, "usage: <input-file> <output-file> <line-number>\n", 48);
		  _exit(1); // Terminate program if the output could not be opened
		}
		 
 	  flag = 1;
	  int bytesRead = 0;
	  int newLineCounter = 0;
	  int removed = 0;
    int wait = 0;
    char tempBuf[64];
    int tempInd = 0;
	  while(flag) {
		    flag = 0;
	      bytesRead = read(fpi, buffer, 64);
	      if(!removed) {
            //printf("Buffer: \n%s\n", buffer);
				    for(int i = 0; i < bytesRead; i++) {
				        tempBuf[tempInd] = buffer[i];
			          tempInd++;
							  if(newLineCounter == line - 1 && removed == 0) {
						       wait = 1;
		 			 	       removed = 1;
								}
						    if(buffer[i] == 0x0a) {
			 		          if(!wait) {
									      write(fpo, tempBuf, tempInd); //Prints each line 
									  }
	                  tempInd = 0;
                    newLineCounter++;
								}
						}
 					  if(tempInd != 0) { // If the buffer doesn't end with a newline there is leftover characters in tempBuf to print. This fixes that
								    write(fpo, tempBuf, tempInd);
				 		        tempInd = 0;
						}
   					flag = 1;
				} else {
	          if(bytesRead == 64) {
				        flag = 1;
	 	            write(fpo, buffer, bytesRead);
			    	} else {
				        write(fpo, buffer, bytesRead);
			    	}
				}
		}
	  
}