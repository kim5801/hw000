#include <unistd.h>
#include <fcntl.h>

static void usage(char *msg) {
    write(STDERR_FILENO, msg, sizeof(msg));    
}

/**
 * Starting point for program.
 * @return Exit Status
 */ 
int main(int argc, char *argv[]) {
    // Usage message
    char *msg = "usage: exclude";
    
    // Checking for valid arguments
    if (argc != 4) {
        usage(msg);
        usage(*argv);
        _exit(1);
    }
    // Converting last argument to int
    char *str = argv[3];
    int lineNum = 0;
    for (int i = 3; i > 0; i--) {
        if (str[i] == '\0') {
           lineNum = str[i - 1] - 48;
           if (str[i - 2] >= '1' && str[i - 2] <= '9') {
              lineNum = lineNum + (10 * (str[i - 2] - 48));
           }
        }
    }
    if (lineNum <= 0) {
        usage(msg);
        usage(*argv);
        _exit(1);
    }
    // Opening input file
    int fd_input = open(argv[1], O_RDONLY, 0600);
    if (fd_input < 0) {
        usage(msg);
        usage(*argv);
        _exit(1);
    }
    // Opening output file
    int fd_output = open(argv[2], O_WRONLY | O_CREAT, 0600);
    if (fd_output < 0) {
        usage(msg);
        usage(*argv);
        _exit(1);
    }
    char buffer[64];
    int len = read(fd_input, buffer, sizeof(buffer));
    int lineCount = 1; 
    while (len > 0) {
        for (int i = 0; i < len; i++) {
            // skip line if line Number equals line count
            if (lineNum == lineCount) {
              for (int j = i; j < len; j++) {
                i++;
                if (buffer[j] == '\n') {
                   lineCount++;
                   break;
                }
              }
            }
            write(fd_output, &buffer[i], 1);
            if (buffer[i] == '\n') {
                lineCount++;
            }
        }    
        len = read(fd_input, buffer, sizeof(buffer));
    }
    close(fd_input);
    close(fd_output);
    return 0;
}

