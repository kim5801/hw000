/**
 * @file stash.c
 * @author Kush Patel
 * @brief toy terminal program with limited capability
 * 
 */
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
#include <sys/wait.h>
#include <string.h>
#include <ctype.h>


/**
 * tokenize the inserted string and return the amount of strings
 * 
 * @param line string to tokenize
 * @param words array to add the words into
 * @return int amount of words in the string
 */
int parseCommand(char *line, char *words[])
{
    int i = 1;
    int numOfWords = 0;
    char *tok = strtok(line, " ");
    words[i - 1] = tok;
    while (tok != NULL)
    {
        tok = strtok(NULL, " ");
        words[i++] = tok;
        numOfWords++;
    }
    return numOfWords;
    
}

/**
 * exits the program
 * 
 * @param words the commands
 * @param count amount of words in command
 */
void runExit(char *words[], int count)
{
    if (count != 2)
    {
        fprintf(stdout, "Invalid command\n");
    }
    else
    {
        //change the exit status from a string to int
        exit(strtol(words[1], NULL, 10));
    }
}

/**
 * changes directory
 * 
 * @param words command
 * @param count amount of words in the command
 */
void runCd(char *words[], int count)
{
    if (count != 2)
    {
        fprintf(stdout, "Invalid command\n");
    }
    else
    {
        //pass in the path
        int ch = chdir(words[1]);
        //if chdir fails
        if (ch == -1)
        {
            fprintf(stdout, "Invalid command\n");
        }
    }
}

/**
 * make a child, if the child is made sucessfully run execvp with the command 
 * 
 * @param words commands
 * @param count the amount of words in the command
 */
void runCommand(char *words[], int count)
{
    words[count] = NULL;
    int pid = fork();
    if (pid == 0)
    {
        int flag = execvp(words[0], words);
        //if the execvp fails
        if (flag == -1)
        {
            fprintf(stdout, "Can't run command %s\n", words[0]);
        }
        exit(EXIT_SUCCESS);
    }
    //wait for the funciton to end before continuing
    wait(NULL);
}


/**
 * main looping and user input processing
 * 
 * @param argc amount of arguments
 * @param argv string array of the arguments entered
 * @return int exit status
 */
int main(int argc, char *argv[])
{
    char userCommand[1025];
    char *words[513];

    //keep looping till they type the exit keyword
    while (1)
    {
        printf("%s", "stash> ");
        char ch = getchar();
        int i = 0;
        //if they just hit enter
        if (ch == '\n')
        {
            // empty body
        }
        //first character to enter the while loop below
        userCommand[i] = ch;
        while (ch != '\n')
        {
            i++;
            ch = getchar();
            userCommand[i] = ch;
        }
        //parse the user input
        int count = parseCommand(userCommand, words);


        //go into the appropriate function for the input
        if (strcmp(words[0], "cd") == 0)
        {
            runCd(words, count);
        }
        else if (strcmp(words[0], "exit") == 0)
        {
            runExit(words, count);
        }
        else
        {
            runCommand(words, count);
        }
    }

    return EXIT_SUCCESS;
}
