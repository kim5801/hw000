/**
 * @file exclude.c
 * @author Kush Patel
 * @brief writes a program to exclude a line in a input file and write the result to a output file
 */

#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>

/**
 * changes string containg a number to a int
 * 
 * @param str string to convert
 * @return int number that was in the string to return
 */
int arg3ToInt(const char str[])
{
    int i = 0;
    int rtn = 0;
    rtn *= 10;
    rtn += ((int) (str[i] - 48));
    return rtn;
}

/**
 * prints the failure message if a wrong usage occurs
 * 
 */
static void fail()
{
    write(STDERR_FILENO, "usage: exclude <input-file> <output-file> <line-number>\n", 56);
    _exit(STDERR_FILENO);
}


/**
 * opens the input output streams and excludes the line given in argv[3]
 * 
 * @param argc number of command line args
 * @param argv array of the arguments as strings
 * @return int exit status
 */
int main(int argc, char const *argv[])
{
    //open both of the streams we need with the correct flags
    int input = open(argv[1], O_RDONLY);
    int output = open(argv[2], O_WRONLY | O_CREAT | O_TRUNC, 0600);

    //check if the streams could be opened and if there is the right amount of command line args
    //else throw usage message
    if (!input || !output|| argc != 4)
    {
        fail();
    }

    //change arg3 from string to int and check if its a positive number
    int line2Rmv = arg3ToInt(argv[3]);
    if (line2Rmv < 0)
    {
        fail();
    }

    int newLines = 0;
    char buffer[64];

    // read 64 bytes into buffer
    int rd = read(input, buffer, 64);

    //while there are still characters to be read
    while (rd > 0)
    {
        //iterate over the buffer
        for (int i = 0; i < rd; i++)
        {
            //if we are on the line we want to exclude dont write to the output stream but keep incrementing the number of newlines
            if (newLines == line2Rmv - 1)
            {
                if (buffer[i] == '\n' )
                {
                    newLines++;
                }
                //dont write to output
            }
            //else (if not on the excluded line) increment the number of newLines and write to the output file
            else
            {
                if (buffer[i] == '\n')
                {
                    newLines++;
                }
                write(output, buffer + i, 1);
            }
        }
        //read the next 64 bytes
        rd = read(input, buffer, rd);
    }

    //close streams
    close(input);
    close(output);
    return 0;
}