#include <unistd.h>
#include <fcntl.h>


#define ITERATIONS 50000
//open(), read(), write() and close()
/**
   main method that excludes a line based on command line argument
   @param argc, amount of command line arguments
   @param argv, array of char pointers
   @return exit status
*/
int main( int argc, char *argv[] ) {
	if(argc != 4) {
		write(STDERR_FILENO, "usage: exclude <input-file> <output-file> <line-number>\n", 56);
		_exit(1);
	}
	//check if the first letter is '-'
	if(argv[3][0] == '-') {
		write(STDERR_FILENO, "usage: exclude <input-file> <output-file> <line-number>\n", 56);
		_exit(1);
	}
	int fd = open(argv[1], O_RDONLY, 0600);
	if(fd == -1) {
		write(STDERR_FILENO, "usage: exclude <input-file> <output-file> <line-number>\n", 56);
		_exit(1);
	}
	int fdOut = open(argv[2], O_WRONLY | O_CREAT, 0600);
	if(fdOut == -1) {
		write(STDERR_FILENO, "usage: exclude <input-file> <output-file> <line-number>\n", 56);
		_exit(1);
	}
	//getting the length of the string/command line argument for line number
	// int count = 0;
// 	//up to argv[3] for null terminated string/ try with while loop
// 	for(int i = 0; argv[3]; i++) {
// 		count++;
// 	}
	char *arr = argv[3];
	int num = 0;
	for(int i = 0; arr[i]; i++) {
		num = (num * 10) + (arr[i] - 48);
	}
	char buff[10];
	int newLine = 0;
	for(int i = 0; i < ITERATIONS; i++) {
		
		while(0 != read(fd, buff, 1)) {
			if(buff[0] == '\n') {
				newLine++;
			}
			if((num - 1) != newLine) {
				write(fdOut, buff, 1);
			}
			
		}
		lseek(fdOut, 0, SEEK_SET);
	}
	
	
	//0a is new line character
	
	close(fd);
	close(fdOut);
	return 0;
}