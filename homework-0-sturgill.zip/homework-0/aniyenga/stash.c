#include <unistd.h>
#include <fcntl.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <sys/wait.h>
#include <sys/types.h>
#include <stdbool.h>


int globalVar = 0;
// This function takes a user command (line) as input. 
// As described above it breaks the line into individual words, adds null termination between 
// the words so each word is a separate string, and it fills in a pointer in the words array to point 
// to the start of each word. It returns the number of words found in the given line. 
// The words array should be at least 513 elements in length, so 
// it has room for the largest possible number of words that could fit in a 1024-character input line.
/**
   parses line given by user
   @param words, array of char pointers
   @param line, line to be parsed
   @return amount of arguments
*/
int parseCommand(char *line, char *words[]) {
	int count = 1;
	for(int i = 0; line[i]; i++) {
		if(line[i] == ' ') {
			count++;
		}
	}
	
	int indexC = 0;
	char *token = strtok(line, " ");
	while(token != NULL) {
		words[indexC] = token;
		token = strtok(NULL, " ");
		indexC++;
	}
// 	for(int i = 0; i < count; i++) {
// 		printf("words yuh%s\n", words[i]);
// 	}
	// for(int i = 0; line[i]; i++) {
// 		buff[i] = line[i];
// 		
// 	}
	//printf("buff %s", buff);
	//printf("indexC %d", indexC);
	words[indexC++] = NULL;
	return count;
}
// This function performs the built-in exit command. The words array is the 
// list of pointers to words in the user’s command and count is the number of words in the array.
/**
   runs exit command
   @param words, array of char pointers
   @param count, number of arguments
*/
void runExit(char *words[], int count) {
	
	//printf("\ncount %d\n", c);
	
	char *arr = words[1];
	
	//printf("d %d", d);
	
	int num = 0;
	for(int i = 0; arr[i]; i++) {
		num = (num * 10) + (arr[i] - 48);
	}
	//printf("num %d", num);
	exit(num);
	
	
}
// This function performs the built-in cd command. 
// As with runExit(), the parameters give the words in the command entered by the user.
/**
   runs cd command
   @param words, array of char pointers
   @param count, number of arguments
*/
void runCd(char *words[], int count) {
	int directory = chdir(words[1]);
	if(directory == -1) {
		printf("Invalid command\n");
		globalVar = -1;
		return;
	}
}


// This function runs a (non-built-in) 
// command by creating a child process and having it call execvp() to run the given command.
/**
   runs command given by user
   @param words, array of char pointers
   @param count, number of arguments
*/
void runCommand(char *words[], int count) {
	//printf("d");
	pid_t conditional = fork();
	int status;
	if(conditional == 0)
	execvp(words[0], words);
	while(wait(&status) != conditional){
		return;
	}
	
	//exit();
}
/**
   main class
   @param argv, array of char pointers
   @param argc, amount of arguments
   @return exit status
*/
int main(int argc, char *argv[]) {

	//start:
	
// 	int ayo = scanf("%s", buff);
// 	printf("%d", ayo);
		//printf("\ncount%d\n", count);
// 			for(int i = 0; i < count; i++) {
// 		printf("words yuh%s\n", words[i]);
// 	}
	//@@@@@@@@@@@@@@@@//
	// have a goto and boolean if the thing entered is empty??
	//@@@@@@@@@@@@@@@@//
	// int bool = 0;
	//char asdf[100];
	
	printf("stash> ");
	char buff[1024];
	buff[0] = '\0';

	while(scanf("%[^\n]%*c", buff) != 0) {
		
		// if(strcmp(buff, "exit") == 0) {
// 			break;
// 		}
		
		//malloc or keeep like this
		//printf("buff %s\n", buff);
		char *words[513];
		int count = parseCommand(buff, words);
		int c = 0;
		while(words[++c] != NULL);
		//CHANGE HERE
		
		if(strcmp(words[0], "exit") == 0) {
			
			if(c > 2) {
				printf("Invalid command\n");
				goto label;
			}
			char *arr = words[1];
			int d = atoi(arr);
			int num = 0;
			for(int i = 0; arr[i]; i++) {
				num = (num * 10) + (arr[i] - 48);
			}
			if(num != d) {
				printf("Invalid command\n");
				goto label;
			}
			runExit(words, count);
			//printf("exit\n");
		} else if(strcmp(words[0], "cd") == 0) {
			if(c > 2) {
				printf("Invalid command\n");
				goto label;
			}
			if(globalVar == -1) {
				printf("Invalid command\n");
				goto label;
			}
			runCd(words, count);
		} else {
			//fork();
			//printf("run\n");
			runCommand(words, count);
			
		}
		
		
		
		label:
		printf("stash> ");
		// bool = 1;
	}
	
	
	return 0;
}