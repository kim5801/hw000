#define _SVID_SOURCE 1

#include <sys/shm.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <stdbool.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <unistd.h>

#define PROMPT "stash> "
#define IN_LIM 1024 + 1
#define BLOCK_SIZE 2048
#define INV_MSG "Invalid command\n"
#define ERR_MSG "Can't run command "

// Function prototypes
int parseCommand(char *line, char *words[]);
void runCd(char *words[], int count);
void runExit(char *words[], int count);
void runCommand(char *words[], int count);

/**
 * Parse a command from a given string into a list of words
 *
 * Arguments:
 * - The line the user entered
 * - A pointer to a list of words
 *
 * Returns:
 * - The number of words counted
 */
int parseCommand(char *line, char *words[]) {
  int count = 0;
  bool trackNext = true;

  // Repeat until the end of the line
  while (*line) {
    // Replace spaces with null terminators
    if (*line == ' ') {
      *line = '\0';
      trackNext = true;
    }
    // Keep track of the next non-whitespace character
    else if (trackNext) {
      words[count++] = line;
      trackNext = false;
    }
    line++;
  }
  words[count] = NULL;

  return count;
}

/**
 * Changes the user's current directory
 *
 * Arguments:
 * - A list of words to run the cd command
 * - A count of the number of words
 */
void runCd(char *words[], int wordc) {
  // Check for a valid command call
  if (wordc != 2) {
    printf(INV_MSG);
    return;
  }

  // Attempt to change the directory
  if (chdir(words[1]) == -1) {
    printf(INV_MSG);
    return;
  }
}

/**
 * Exits from the shell
 *
 * Arguments:
 * - A list of words to run the cd command
 * - A count of the number of words
 */
void runExit(char *words[], int wordc) {
  // Check for a valid command call
  if (wordc != 2) {
    printf(INV_MSG);
    return;
  }

  // Get the status integer
  int status;
  if (sscanf(words[1], "%d", &status) != 1) {
    printf(INV_MSG);
    return;
  }

  exit(status);
}

/**
 * Executes an external command
 *
 * Arguments:
 * - A list of words to run the cd command
 * - A count of the number of words
 */
void runCommand(char *words[], int wordc) {
  // Create a child process and make it run the external command
  int pid = fork();
  if (pid == 0) {
    execvp(words[0], words);

    printf(ERR_MSG);
    for (int i = 0; i < wordc; i++) {
      printf("%s ", words[i]);
    }
    printf("\n");
    exit(1);
  }

  // Wait for the child process
  int wstatus = 1;
  waitpid(pid, &wstatus, WUNTRACED);
}


int main() {
  // Create shared memory for dual process communication
  int shmid = shmget(98765, BLOCK_SIZE + 1, 0666 | IPC_CREAT);
  if (shmid == -1) {
    printf("Can't create shared memory");
    exit(1);
  }

  // Map the shared memory
  char *msg = (char *)shmat(shmid, 0, 0);
  if (msg == (char *)-1) {
    printf("Can't map shared memory segment");
    exit(1);
  }

  // Set the flag of the last byte of the buffer to indicate a present message
  msg[BLOCK_SIZE] = 0;

  while (true) {
    printf(PROMPT);

    // Read in a line
    char line[IN_LIM];
    if (fgets(line, IN_LIM, stdin) == NULL) {
      continue;
    }
    line[strlen(line)-1] = '\0'; // Get rid of the newline

    // Get a list of words from the line
    char *words[IN_LIM/2];
    int wordc = parseCommand(line, words);

    // Continue if there are no words
    if (wordc == 0) continue;

    // See if any background commands need to be printed
    if (msg[BLOCK_SIZE] == 1) {
      printf("%s", msg);
      msg[BLOCK_SIZE] = 0;
    }

    // Determine if shell should run in the background
    int pid = -1;
    if (strcmp(words[wordc-1], "&") == 0) {
      // Remove the '&' from the word list
      words[wordc-1] = NULL;

      // Create a child process, skip the iteration on error
      pid = fork();
      if (pid == -1) {
        printf(INV_MSG);
        continue;
      }

      // Print out the child's pid and setup the pipe
      if (pid != 0) {
        printf("[%d]\n", pid);
      }
    }

    // Run the associated command
    if (pid <= 0) {
      if (strcmp(words[0], "cd") == 0) {
        runCd(words, wordc);
      } else if (strcmp(words[0], "exit") == 0) {
        runExit(words, wordc);
      } else {
        runCommand(words, wordc);
      }
    }

    // If there is a child process, print out it's pid when it's done
    if (pid == 0) {
      // Update the status string
      snprintf(msg, BLOCK_SIZE, "[%d done]\n", getpid());
      msg[BLOCK_SIZE] = 1;
      exit(0);
    }
  }

  // Release the memory segment
  shmdt(msg);
  shmctl(shmid, IPC_RMID, 0);
}
