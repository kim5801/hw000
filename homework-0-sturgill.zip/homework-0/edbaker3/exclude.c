#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>

#define USAGE_STR "usage: exclude <input-file> <output-file> <line-number>\n"
#define BUF_LEN 64

// Prototypes
int _strlen(char *str);
void fail();
int atoi(char *str);

/**
 * Get the length of a null terminated string (does not count the null terminator)
 *
 * Arguments:
 * - A string to get the length of
 *
 * Returns:
 * - The length of the string
 */
int _strlen(char *str) {
  int count = 0;
  while (str[count]) {
    count++;
  }
  return count;
}

/**
 * Fail the program and output the usage string
 */
void fail() {
  write(STDERR_FILENO, &USAGE_STR, _strlen(USAGE_STR));
  _exit(1);
}

/**
 * Convert a string representing a positive integer to an integer
 *
 * Arguments:
 * - String to convert (cannot be negative)
 *
 * Returns:
 * - The converted integer
 */
int atoi(char *str) {
  int total = 0;
  int place = 1;

  // For each character of the string
  for (int i = _strlen(str)-1; i >= 0; i--) {
    // Fail on a non-digit (including negative sign)
    if (str[i] < 48 || str[i] > 57) {
      fail();
    }

    // Add the digit to the placeholder
    total += (str[i]-48) * place;

    place *= 10;
  }

  return total;
}

/**
 * Copies everything from the input file to the output file, excluding the line provided by the user.
 *
 * Arguments:
 * - Name of an input file
 * - Name of an output file
 * - Integer for a line of the input file
 */
int main(int argc, char *argv[]) {
  // Check for invalid argument count
  if (argc != 4) {
    fail();
  }

  // Get/check the input/output files
  int ifp = open(argv[1], O_RDONLY);
  int ofp = open(argv[2], O_WRONLY);
  if (ifp == -1 || ofp == -1) {
    fail();
  }

  // Get/check the exclusion line
  int exLine = atoi(argv[3]);
  if (exLine < 0) {
    fail();
  }

  // Read in bytes from the input file in 64 byte chunks
  int readBytes;
  int line = 1;
  char buf[BUF_LEN];
  do {
    readBytes = read(ifp, buf, BUF_LEN);

    // Write bytes to the file
    for (int i = 0; i < readBytes; i++) {
      // Write all lines except the exclusion line to the file
      if (line != exLine) {
        write(ofp, &buf[i], 1);
      }

      // Increment the line counter on a newline
      if (buf[i] == '\n') {
        line++;
      }
    }
  } while (readBytes == 64);
}
