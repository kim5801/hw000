#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>

/// @brief a function that exits the program and writes a message to standard error
/// @param msg the message to write to standard error
/// @param msgLen the length of the message
void fail(char msg[], int msgLen) {
    write(STDERR_FILENO, msg, msgLen);
    _exit(1);
}

/// @brief converts a string to an integer. If the integer is negative or not an integer then this returns -1
/// @param s the string to conver to an integer
/// @return -1 if the string is negative or invalid, otherwise an integer from the parameter string
int strToPosInt(char *s) {
    char *c = s;
    int strlen = 0;
    //skip to the end of the string
    while (*c) {
        c++;
        strlen++;
    }
    c--;

    //initial total
    int total = 0;

    //set the multiplier for a digit
    int digitVal = 1;

    //loop through and add up each digit
    for (int i = 0; i < strlen; i++) {
        if (*c >= '0' && *c <= '9') {
            total += digitVal * (*c - '0');
            digitVal *= 10;
        }
        else {
            return -1;
        }
        c--;
    }
    return total;
}

/// @brief copies over all lines from fdIn to fdOut except for the line that should be excluded
/// @param fdIn the file to copy from
/// @param fdOut the file to copy to
/// @param excludeLineNum the line to exclude from fdIn
void copyOver(int fdIn, int fdOut, int excludeLineNum) {

    int bufferByteSize = 64;
    int bytesRead = 0;
    int currentLineNum = 1;
    //repeatedly write to file.
    do {
        //reads bytes
        char buf[bufferByteSize];
        bytesRead = read(fdIn, buf, bufferByteSize);

        //scans thru each byte, if it is a newline then it increments the current line.
        //does not write chars that are on the given exclude line
        for (int i = 0; i < bytesRead; i++) {
            if (currentLineNum != excludeLineNum) {
                write(fdOut, &buf[i], 1);
            }
            if (buf[i] == '\n') {
                currentLineNum++;
            }
        }
    } while (bytesRead != 0);
}

/// @brief this program copies one file over to the other while excluding a given line
int main(int argc, char *argv[]) {
    char argErrorMsg[] = "usage: exclude <input-file> <output-file> <line-number>\n\0";
    int msgLen = sizeof(argErrorMsg);

    //make sure arg count is correct
    if (argc != 4) {
        //output error message to standard error
        fail(argErrorMsg, msgLen);
    }
    //read args
    char *inputFileLocation = argv[1];
    char *outputFileLocation = argv[2];
    char *excludeLineNumArg = argv[3];

    //fail after each so that we do not do any extra work
    int excludeLineNum = strToPosInt(excludeLineNumArg);
    if (excludeLineNum < 1) {
        fail(argErrorMsg, msgLen);
    }
    int fdIn = open(inputFileLocation, O_RDONLY, 0400);
    if (fdIn < 0) {
        fail(argErrorMsg, msgLen);
    }
    int fdOut = open(outputFileLocation, O_WRONLY + O_CREAT + O_TRUNC, 0600);
    if (fdOut < 0) {
        close(fdIn); //if it got to here and failed that means that the first file was opened
        fail(argErrorMsg, msgLen);
    }
    
    copyOver(fdIn, fdOut, excludeLineNum);

    close(fdIn);
    close(fdOut);
    //check that last arg is a postive int and that the two files provided can be opened
    _exit(0);
}