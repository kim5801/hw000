#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <string.h>
#include <unistd.h>
#include <sys/wait.h>
#include <sys/types.h>

/**
 * @brief This function performs the built-in exit command. The words array is the list of pointers to words
 * in the user’s command and count is the number of words in the array.
 */
void runExit( char *words[], int count ) {
    if (count != 3) {
        fprintf(stdout, "Invalid command\n");
        return;
    }
    char *endPtr;
    int status = strtol(words[1], &endPtr, 10);
    if (*endPtr != '\n') {
        fprintf(stdout, "Invalid command\n");
    } else {
        exit(status);
    }

}

/**
 * @brief This function performs the built-in cd command. As with runExit(), the parameters give the
 * words in the command entered by the user.
 */
void runCd( char *words[], int count ) {
    if (count != 3) {
        fprintf(stdout, "Invalid command\n");
        return;
    }
    int output = chdir(words[1]);
    if (output != 0) {
        fprintf(stdout, "Invalid command\n");
    }
}

/**
 * @brief This function runs a (non-built-in) command by creating a child process and having it call execvp()
 * to run the given command.
 */
void runCommand( char *words[], int count ) {
    // Make a child process
    int id = fork();
    if (id == -1) {
        fprintf(stdout, "Cant't run command %s\n", words[0]);
    }
    if (id == 0) {
        int argCount = 0;
        //child
        execvp(words[0], words);
    } else{
        //parent
        wait(NULL);
    }
}

/**
 * @brief This function takes a user command (line) as input. As described above it breaks the line into
 * individual words, adds null termination between the words so each word is a separate string, and
 * it fills in a pointer in the words array to point to the start of each word. It returns the number
 * of words found in the given line. The words array should be at least 513 elements in length, so it
 * has room for the largest possible number of words that could fit in a 1024-character input line.
 */
int parseCommand( char *line, char *words[] ) {
    int index = 0;
    char *token = strtok(line, " ");
    words[index++] = token;
    while (token) {
        token = strtok(NULL, " ");
        words[index++] = token;
    }

    if (strcmp("cd", words[0]) == 0) {
        runCd(words, index);
    }
    else if (strcmp("exit", words[0]) == 0) {
        runExit(words, index);
    }
    else if (strcmp("\n", words[0]) == 0) {
    }
    else {
        runCommand(words, index);
    }
    return 0;
}


int main() {
    while (true) {
        fprintf(stdout, "stash> ");
        int maxLineSize = 1024;
        char buf[maxLineSize];
        fgets(buf, maxLineSize, stdin);
        char *words[513];
        parseCommand(buf, words);
    }
}