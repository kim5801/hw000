/**
 * @file stash.c
 * @author Thomas Welch
 * Stash is a shell program that prompts a user for input to run built in or external
 * functions. This is accomplished through a mix of C function and system calls
 */

#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <ctype.h>
#include <string.h>
#include <unistd.h>
#include<sys/wait.h>

/** Maximum number of words that can be stored */
#define MAX_WORDS 513
/** Maximum number of character that can be stored */
#define MAX_LINE 1025


//DESCRIBE FUNCTION
int parseCommand( char *line, char *words[] ) {
    /** Set initial word count to 0 */
    int count = 0;
    /** Loop through line until null terminator is reached */
    int i = 0;
    bool lastSpace = true;
    while(line[i] != '\0' && line[i] != '\n') {
        /** Replace wite space with null terminator */
        if (isspace(line[i])) {
            line[i] = '\0';
            /** Indicate that the previous char was whitespace */
            lastSpace = true;
        } else {
            /** Add the new word to the pointer array */
            if (lastSpace) {
                words[count] = &(line[i]);
                ++count;
            }
            /** Indicate that the previous char was not whitespace */
            lastSpace = false;
        }
        ++i;
    }
    /** Null terminate last word */
    line[i] = '\0';

    /** Return the number of words found */
    return count;
}

//DESCRIBE FUNCTION
void runExit( char *words[], int count ) {
    /** Print an error if there is not exactly one argument */
    if (count != 2) {
        fprintf(stderr, "Invalid command\n");
        return;
    }

    int exitInt = 0;
    /** Parse integer value of string */
    int i = 0;
    while(words[1][i] != '\0' && words[1][i] != '\n') {
        int dig = (words[1][i] - '0');
        /** Invalid character encountered; print error message and return for reprompt*/
        if (dig < 0 || dig > 9) {
            fprintf(stderr, "Invalid command\n");
            return;
        }
        /** Multiple current value of exitInt by 10 to account for the new digit, then add new digit */
        exitInt = exitInt * 10 + dig;
        ++i;
    }
    exit(exitInt);
}

//DESCRIBE FUNCTION
void runCd( char *words[], int count ) {
    /** Print an error if there is not exactly one argument */
    if (count != 2) {
        fprintf(stderr, "Invalid command\n");
        return;
    }

    /** Attempt to change directory to provided path */
    int dirResult = chdir(words[1]);

    /** Error in changing directory, print error message */
    if (dirResult == -1) {
        fprintf(stderr, "Invalid command\n");
        return;
    }
}

//DESCRIBE FUNCTION
void runCommand( char *words[], int count ) {
    /** Create a child process */
    int PID = fork();

    /** Failed to create child */
    if (PID == -1) {
        // Child failure error
        return;
    }

    /** Parent waits for child */
    if (PID != 0) {
        wait(NULL);
    }

    /** Run the command in the child process */
    if (PID == 0) {
        /** Add null pointer to end of array */
        words[count] = NULL;

        /** Run command with execvp */
        int errCheck = execvp(words[0], words);

        /** Print an error message if execvp returned an error */
        if (errCheck == -1) {
            fprintf(stderr, "%s%s\n", "Can't run command ", words[0]);
            /** Kill the child process */
            exit(0);
        }
    }
}

int main() {
    /** Allocate space for storing the array of word pointers */
    char **words = (char **)malloc(MAX_WORDS * sizeof(char*));
    /** Allocate space for storing the read line */
    char *line = (char *)malloc(MAX_LINE * sizeof(char));

    /** String value of exit command */
    char *exitCom = "exit";
    /** String value of change directory command */
    char *cdCom = "cd";

    /** Prompt the user for initial input */
    printf("stash> ");

    /** Get line of user input */
    char *getRet = fgets(line, MAX_LINE, stdin);

    //Prompt user until done (ignore and reprompt blank lines (\n))
    while (getRet) {

        /** Separate line into null terminated words */
        int count = parseCommand(line, words);

        /** Reprompt if line was empty and go back to start of input loop */
        if (count == 0) {
            printf("\n");
            printf("stash> ");
            /** Get line of user input */
            getRet = fgets(line, MAX_LINE, stdin);
            continue;
        }

        if (strncmp(words[0], cdCom, strlen(cdCom)) == 0) {
            /** Handle change directory command */
            runCd(words, count);

        } else if (strncmp(words[0], exitCom, strlen(exitCom)) == 0) {
            /** Handle exit command */
            runExit(words, count);

        } else {
            /** Handle external command */
            runCommand(words, count);
        }

        /** Prompt the user for input */
        printf("\n");
        printf("stash> ");

        /** Get line of user input */
        getRet = fgets(line, MAX_LINE, stdin);
    }

    /** Free dynamically allocated space before process termination */
    free(words);
    free(line);
}