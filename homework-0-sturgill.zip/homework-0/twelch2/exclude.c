/**
 * @file exclude.c
 * @author Thomas Welch
 * The exclude program uses system calls to read in an input file and write it
 * to an output, excluding a specified line. The input file, output file, and 
 * excluded line number are provided as command line arguments
 */
#include <sys/types.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>

#define BLOCK_SIZE 64
#define ARG_ERR 10
#define OPEN_ERR 50
#define LINE_ERR 100

int main(int argc, char *argv[]) {
    /** Standard error message */
    char errMessage[] = "usage: exclude <input-file> <output-file> <line-number>\n";

    /** Incorrect number of command line arguments */
    if (argc != 4) {
        write(STDERR_FILENO, errMessage, sizeof(errMessage));
        _exit(ARG_ERR);
    }

    /** Open the input file */
    int rf = open(argv[1], O_RDONLY);
    /** Error in input file; print usage error message */
    if (rf == -1) {
        write(STDERR_FILENO, errMessage, sizeof(errMessage));
        _exit(OPEN_ERR);
    }

    /** Open the output file */
    int wf = open( argv[2], O_WRONLY | O_TRUNC | O_CREAT, 0600 );

    /** Error in output file; print usage error message */
    if (wf == -1) {
        write(STDERR_FILENO, errMessage, sizeof(errMessage));
        _exit(OPEN_ERR);
    }

    int skipLine = 0;
    /** Parse integer value of string */
    int i = 0;
    while(argv[3][i] != '\0') {
        int dig = (argv[3][i] - '0');
        /** Invalid character encountered; exit with error message */
        if (dig < 0 || dig > 9) {
            write(STDERR_FILENO, errMessage, sizeof(errMessage));
            _exit(LINE_ERR);
        }
        /** Multiple current value of skipLine by 10 to account for the new digit, then add new digit */
        skipLine = skipLine * 10 + dig;
        ++i;
    }
    
    /** Line to skip is not a positive integer; print usage error message */
    if (skipLine < 1) {
        write(STDERR_FILENO, errMessage, sizeof(errMessage));
        _exit(LINE_ERR);
    }

    /** Current line being read */
    int lineCount = 1;

    /** Buffer to read into */
    char buffer[64];
    /** Buffer to write into */
    char printBuf[64];

    //Read in bytes 64 at a time, and process individually to be written
    int bytes = read(rf, buffer, 64);
    /** Count of bytes currently in the print buffer */
    int byteCount = 0;
    while(bytes != 0) {
        /** Process buffer contents in for loop */
        for (int i = 0; i < bytes; ++i) {
            char current = buffer[i];
            /** If not currently processing the skipped line */
            if (lineCount != skipLine) {
                printBuf[byteCount] = current;
                ++byteCount;
            }
            /** Increment line count when newline is encountered */
            if (current == '\n') {
                lineCount++;
            }
        }
        /** Write the buffer to output */
        write( wf, &(printBuf[0]), byteCount);
        /** Read in another block of bytes */
        bytes = read(rf, buffer, 64);
        /** Set byteCount back to zero to prepare for next print */
        byteCount = 0;
    }

    /** Close the input file */
    close(rf);
    /** Close the output file */
    close(wf);
}