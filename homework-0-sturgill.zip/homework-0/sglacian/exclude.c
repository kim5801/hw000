/**
 * This program copies everything from a given input file to a given output file,
 * except for the line which the user chooses to skip. This program utilizes Unix
 * system calls and doesn't use functionality from the C standard library.
 * @file exclude.c
 * @author Sophia Laciano
 */
 
#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>

/** The decimal value for ASCII character code 0 */
#define ASCIIZERO 48

/** The decimal value for ASCII character code 9 */
#define ASCIININE 57

/** Sixty bytes to be written */
#define SIXTYBYTES 60

/** Sixty-four bytes to be read in */
#define SIXTYFOUR 64

/** The number to represent accessing command line argument 3 */
#define THREE 3

/** Total number of command line arguments that should be provided by user */
#define NUMARGS 4

/** 
 * Main method of the program. Receives command line arguments in order to open
 * the correct input and output files for reading and writing.
 * @param argc the number of comand line arguments.
 * @param argv[] the command line arguments input from the user.
 * @return successful exit status when the program is successfully completed.
 */
int main( int argc, char *argv[] ) {
    
    // Usage message for errors.
    char failOutput[] = "usage: exclude <input-file> <output-file> <line-number>\n";
    // Print usage message if there aren't enough command line arguments.
    if ( argc != NUMARGS ) {
        write( STDERR_FILENO, failOutput, SIXTYBYTES );
        // Exit unsuccessfully.
        _exit( 1 );
    }

    // Input file name from command line argument.
    char const *fileName = argv[1];
    // Output file name from command line argument.
    char const *fileOutName = argv[2];
   
    // The value to represent the line number to be skipped.
    int skip = 0;
    // The number that will represent the digit place in the decimal value.
    int place = 1;
    // Temporary value holder for coverting ASCII to decimal values.
    int temp = 0;
    // Index location for going character by character through argv[3].
    int ind = 0;
    // Figure out how many characters there are, and if all are valid.
    while ( argv[ THREE ][ ind ] != '\0') {
        // Print usage message & exit unsuccessfully if character is invalid.
        if ( argv[ THREE ][ ind ] < ASCIIZERO || argv[ THREE ][ ind ] > ASCIININE ) {
            write( STDERR_FILENO, failOutput, SIXTYBYTES );
            _exit( 1 );
        }
        ind++;
    }
    
    // Convert argv[3] into its valid decimal value
    for ( int i = ind - 1; i >= 0; i-- ) {
        temp = ( argv[ THREE ][ i ] - ASCIIZERO ) * place;
        skip += temp;
        // Increase the decimal place we are finding the value for.
        place = place * 10;
    }
     
    // Open the input file for reading.
    int fd = open( fileName, O_RDONLY );
    // Print usage message & exit unsuccessfully if file didn't open.
    if ( fd < 0 ) {
        write( STDERR_FILENO, failOutput, SIXTYBYTES );
        close( fd );
        _exit( 1 );
    }
    // Create an output file for writing. Truncate the file if it already exists.
    int fp = open( fileOutName, O_WRONLY | O_TRUNC | O_CREAT, 0600 );
    // Print usage message & exit unsuccessfully if file didn't open.
    if ( fp < 0 ) {
        write( STDERR_FILENO, failOutput, SIXTYBYTES );
        close( fd );
        close( fp );
        _exit( 1 );
    }
    
    // Read up to 64 bytes from the file.
    char buffer[ SIXTYFOUR ];
    int len = read( fd, buffer, sizeof( buffer ) );
    
    // The line in the file we are currently reading.
    int lineCount = 1;
    
    // Write the contents of the input file until nothing is read in anymore.
    while ( len > 0 ) {
        // Write each character one at a time to the output file.
        for ( int i = 0; i < len; i++ ) {
            // If we read a new line character, increase lineCount.
            if ( buffer[ i ] == '\n' ) {
                lineCount++;
            }
            // If we aren't on the line to be skipped, write to the file.
            if ( lineCount != skip ) {
                write( fp, &buffer[ i ], 1 );
            }
        }
        // Try to read up to 64 more bytes from the file.
        len = read( fd, buffer, sizeof( buffer ) );
    }
    
    close( fd );
    close( fp );
    _exit( 0 );
}