/**
 * This is a shell program that prompts the user for commands and executes
 * them if they are valid. Otherwise, the user is prompted again until a 
 * successful exit of the program. 
 * @file stash.c
 * @author Sophia Laciano
 */
 
 #include <unistd.h>
 #include <stdbool.h>
 #include <ctype.h>
 #include <string.h>
 #include <stdlib.h>
 #include <stdio.h>
 #include <sys/types.h>
 #include <sys/wait.h>

/**
 * Breaks a given line from user input into individual words, separates them by a
 * null termination, and fills in a pointer in the given array to point to the 
 * beginning of each word.
 * @param line user command input.
 * @param words array of pointers that will point to start of every word.
 * @return number of words found in the given line.
 */
int parseCommand( char *line, char *words[] ) {
     // The count of words read in from user input.
    int wCount = 0;
    // The index location in line (from user input).
    int lineI = 0;
    // The index location in the words array.
    int copyI = 0;
    
    // Make sure line of input has characters, and continue until reach the end.
    while( line[ lineI ] != '\n' && line[ lineI ] != '\0') {
        // If the character is whitespace, skip over it.
        if ( isspace( line[ lineI ] != 0 ) ) {
            lineI++;
        }
        // Else, if the character is not whitespace, read in the characters and 
        // replace spaces with null terminators before adding words to pointer array.
        else {
            int firstCharI = lineI;
            // Increment index until it is at the end of the word.
            while( isspace( line[ lineI ] ) == 0 ) {
                lineI++;
            }
            // Change space between words to a null terminator.
            line[ lineI ] = '\0';
            lineI++;
            // Add start of word into array of pointers.
            words[ copyI ] = &line[ firstCharI ];
            // Increment word count and index location in array of pointers.
            wCount++;
            copyI++;
        }
    }

    return wCount;
}

/**
 * Performs the built-in exit command.
 * @param words list of pointers to words in the user's command.
 * @param count number of words in the words array.
 */
void runExit( char *words[], int count ) {

    // False if the 2nd argument is not a valid integer when parsed.
    bool validInt = true;
    // Iterate through 2nd argument to make sure it is a valid integer.
    for( int i = 0; i < strlen( words[ 1 ] ); i++ ) {
        if( isdigit( words[ 1 ][ i ] ) == 0 ) {
            validInt = false;
        }
    }
    // Print error message if 2nd argument is invalid or there are too many arguments.
    if( validInt == false || count > 2 ) {
        write( STDERR_FILENO, "Invalid command\n", 16 );
    }
    // If no cause for error, exit with given status.
    else {
        int status = atoi( words[ 1 ] );
        exit( status );
    }
}

/**
 * Performs the built-in cd command.
 * @param words list of pointers to words in the user's command.
 * @param count number of words in the words array.
 */
void runCd( char *words[], int count ) {
    // runs 0 on success, -1 on error.
    int validCommand = chdir( words[ 1 ] );
    // Print error message if argument is invalid or there are too many arguments.
    if( validCommand != 0 || count > 2 ) {
        write( STDERR_FILENO, "Invalid command\n", 16 );
    }
}

/**
 * Runs a command by creating a child process that can make a call  
 * to run the given command.
 * @param words list of pointers to words in the user's command.
 * @param count number of words in the words array.
 */
void runCommand( char *words[], int count ) {
    // Create a child process using fork().
    pid_t id = fork();
    // Add null pointer to end of given array.
    words[ count ] = NULL;

    // If we have the child, run a different executable in the child.
    if ( id == 0 ) {
        // I'm the child, run the ls program, it's in the /bin directory.
        execvp( words[ 0 ], words );
        // If execvp fails, ouput error message.
        printf( "%s", "Can't run command " );
        printf( "%s", words[ 0 ] );
        printf( "%s", "\n" );
        exit( 1 );
    } else {
        // Parent waits for child to finish.
        wait( NULL );
    }
}

/** 
 * Main method of the program.
 * @param argc the number of comand line arguments.
 * @param argv[] the command line arguments input from the user.
 * @return successful exit status when the program is successfully completed.
 */
int main( int argc, char *argv[] ) {
    
    // Prompt user for commands.
    printf( "stash> " );
    // Read up to 1024 characters from user input.
    char line[ 1024 +1];
    // Array of pointers with one pointer pointing to each word.
    char *wordsA[ 513 +1];
    // Keeps count of words read in.
    int wordCount = 0;
    
    // Read in user input and parse the command.
    if ( fgets( line, 1024, stdin ) > 0 ) {
        wordCount = parseCommand( line, wordsA );
    } 
    
    while( wordCount >= 0 ) {        
        // Run exit command if user ran this command.
        if( strcmp( "exit", wordsA[ 0 ] ) == 0 ) {
            runExit( wordsA, wordCount );
        }
        // RUn cd command if user ran this command.
        else if( strcmp( "cd", wordsA[ 0 ] ) == 0 ) {
            runCd( wordsA, wordCount );
        }
        // Otherwise, run the command the user intended to run, if they entered words.
        else if ( wordCount > 0 ) {
            runCommand( wordsA, wordCount );
        }
        
        // Prompt user for commands.
        printf( "stash> " );
        fgets( line, 1024, stdin );
        wordCount = parseCommand( line, wordsA );
    }
    
    // return successful exit status.
    return 0;
}