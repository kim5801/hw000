/*
   Runs shell commands by prompting user for commands, parsing them,
   and running the corresponding command or reprompting the user.
   @file stash.c
   @author Madeline Snyder (mdsnyde3)
 */
#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include <unistd.h>
#include <ctype.h>
#include <sys/wait.h>
//maximum amount of words than can be made from input
#define WORD_MAX 513
//maximum amount of characters that can be read in a single line of input, plus space for the null terminator
#define CHAR_MAX 1025
/**
  Takes a user command as input, breaks line into individual words,
  and puts those words into a word array with pointers.
  @param *line the command line to be parsed
  @param *words[] the array of words to be filled in
  @return The number of words found in the given line
*/
int parseCommand( char *line, char *words[] )
{
  //if newline, return as 0 words
  if( line[ 0 ] == '\n' ) {
    return 0;
  }
  //set word total and character counter
  int wordTotal = 0;
  int charCount = 0;
  //while there are still characters in the line
  while( line[ charCount ] ) {
    //if we reach a space, count a word and add a null terminator
    if( isspace( line[ charCount ] ) ) {
      wordTotal++;
      line[ charCount ] = '\0';
      
    }
    //increase character count
    charCount++;
  }
  //value to help assign pointer to word
  int wordBit = 1;
  //helper counting variable
  int counter = 0;
  //loop through line again
  for( int i = 0; i < charCount; i++ ) {
    //if this is the start of a word, assign pointer
    if( wordBit ) {
      words[ counter ] = &line[ i ];
      wordBit = 0;
    }
    //if null terminator, set the wordBit to 1 and increase counter
    if( *(line + i) == '\0' ) {
      wordBit = 1;
      counter++;
    }
  }
  return wordTotal;
}

/**
  Performs the built-in exit command
  @param *words[] the array of words to be filled in
  @param count the number of words in the array
*/
void runExit( char *words[], int count )
{
  //if there aren't 2 commands, it is invalid
  if( count != 2 ) {
    fprintf( stdout, "Invalid command\n" );
    return;
  } 
  else {
    //if the path is zero, exit with status 0
    if( *words[ 1 ] == '0' ) {
      exit( 0 );
    }
    //convert status string to int
    int status = atoi( words[ 1 ] );
    //if return from atoi was zero, status was not valid
    if( status == 0 ) {
      fprintf( stdout, "Invalid command\n" );
      return;
    }
    //exit with given status
    exit( status );
  }
}

/**
  Performs the built-in cd command
  @param *words[] the array of words to be filled in
  @param count the number of words in the array
*/
void runCd( char *words[], int count )
{
  //if there are not exactly two commands, it is invalid
  if( count != 2 ) {
    fprintf( stdout, "Invalid command\n" );
    return;
  }
  else {
    //call command to change directory
    int dir = chdir( words[ 1 ] );
    //if return from chdir() is -1, the path was invalid
    if( dir == -1 ) {
      fprintf( stdout, "Invalid command\n" );
      return;
    }
  }
}

/**
  Performs a non-built-in command by creating a child process, which
  calls execvp() to run a specified command
  @param *words[] the array of words to be filled in
  @param count the number of words in the array
*/
void runCommand( char *words[], int count )
{
  //create new array with length of count
  char *newWords[ count + 1 ];
  //loop through and put null in the last spot
  for( int i = 0; i < count; i++ ) {
    newWords[ i ] = words[ i ];
  }
  newWords[ count ] = NULL;
  //make child process
  int id = fork();
  //check which id (parent or child)
  if( id == 0 ) {
  //if child, run execl( words[0], new array)
    int err = execvp( words[ 0 ], newWords );
    //fail check? then exit
    if( err == -1 ) {
      fprintf( stdout, "Can’t run command %s\n", words[ 0 ] );
      exit( 1 );
    }
    exit( 1 );
  } else {
  //parent, wait for child
    wait( NULL );
  }
}

/**
  Main method, calls helper methods and creates an array with all the
  words from the commands entered by the user. 
  Loops until the user enters the exit command.
  @return exit status
*/
int main()
{
  //big infinite loop
  while( 1 ) {
    //create word array (size 513)
    char *wordList[ WORD_MAX ];
    //print stash>
    printf( "stash> ");
    //take in command (scanf)
    char line[ CHAR_MAX ];
    fgets( line, CHAR_MAX, stdin );
    //call parseCommand
    int wordCount = parseCommand( line, wordList );
    //four checks:
      //newline -> reprompt
      if( wordCount == 0 ){
      //do nothing
      }
      //path -> call path
      else if( strcmp( wordList[ 0 ], "cd" ) == 0 ) {
        runCd( wordList, wordCount );
      }
      //exit -> call exit
      else if( strcmp( wordList[ 0 ], "exit" ) == 0 ) {
        runExit( wordList, wordCount );
      }
      //not newline -> call custom
      else {
        runCommand( wordList, wordCount );
      }
    }  
}
