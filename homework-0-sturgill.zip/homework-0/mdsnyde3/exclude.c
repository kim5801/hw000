/*
   Reads bytes from an input file and excludes the line specified in the command line arguments, then prints to an output file
   @file exclude.c
   @author Madeline Snyder (mdsnyde3)
 */
#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
/**
  Helper method to turn command line argument into an int
  @param *lineString the command line argument to be converted
  @return The line number as an int
*/
int toInt( char *lineString )
{
  int i = 0;
  char digit = lineString[ i ];
  int total = 0;
  //count digits and check validity
  while( digit ) {
    if( digit < '0' || digit > '9' ) {
      write( STDERR_FILENO, "usage: exclude <input-file> <output-file> <line-number>\n", 56 );
      _exit( 1 );
    }
    i++;
    digit = lineString[ i ];
  }
  //Set digit count
  int digitCount = i;
  i = 0;
  int temp = 0;
  //get numerical value of digit
  while( digitCount > 0 ) {
    temp = lineString[ i ] - '0';
    //multiply by the appropriate power of 10
    for( int j = 0; j < digitCount - 1; j++ ) {
      temp *= 10;
    }
    //add to total
    total += temp;
    i++;
    //decrease digit count
    digitCount--;
  }
  return total;
}
/**
  Main method, takes in file names and line number to print to output with one line excluded.
  @param argc number of arguments
  @param *argv[] array of arguments from command line
  @return exit status
*/
int main( int argc, char *argv[] )
{
  //open input and output files, and give permissions to output
  int fd = open( argv[1], O_RDONLY );
  int fd2 = open( argv[2], O_WRONLY | O_CREAT, 0600 );
  //call helper method
  int lineNum = toInt( argv[3] );
  //check if files are able to be opened/created
  if( fd < 0 || fd2 < 0 ) {
    write( STDERR_FILENO, "usage: exclude <input-file> <output-file> <line-number>\n", 56 );
    _exit( 1 );
  }
  //create buffer to read into
  char buffer[ 64 ];
  int len = read( fd, buffer, 64 );
  int lineCount = 1;
  int k = 0;
  //while bytes are still being read, write to the file and keep reading
  while( len > 0 )
  {
    while( k < len ) {
      //if we aren't in the skipped line, write the characters!
      if( lineCount != lineNum ) {
        write( fd2, &buffer[k], 1 );
      }
    //if we have reached a new line, increase line count
    if( buffer[k] == '\n' ) {
          lineCount++;
    }
    k++;
    }
    len = read( fd, buffer, 64 );
    k = 0;
  }
  //
  close( fd );
  close( fd2 );
  //successful exit status
  _exit( 0 );
  
}
