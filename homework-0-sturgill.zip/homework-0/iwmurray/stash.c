/**
 * Homework 0 - Problem 4 - CSC 246
 * @author Ian Murray (iwmurray)
 */

#include <ctype.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <unistd.h>

/**
 * Parses an interger from string.
 * @param str string to parse
 * @return parsed interger, or -1 if invalid
 */
int parseInt( char *str ) {
    char *ch = str;
    int acc = 0;
    
    // Loop until null terminator
    while( *ch != '\0') {
        acc *= 10;

        if( *ch < '0' || *ch > '9')
            return -1; // Invalid character

        acc += *ch - '0'; // Normalize value
        ch++;
    }

    return acc;
}

/**
 * Takes a user command line as input and breaks it into words.
 * @param line the input line, a string of at most 1024 characters.
 * @param words array of strings of at least 513 elements, where the parsed
 *  words are stored.
 * @return The number of words found in the user's command.
 */
int parseCommand( char *line, char *words[] )
{
    char *ch = line;
    int count = 0;
    bool createWord = true;

    while( *ch != '\0' ) {
        if( isspace(*ch) ) {
            // Add null seperator and next non-space will be a new word
            *ch = '\0';
            createWord = true;
        } else if( createWord ) {
            // Create new item in word array
            words[count++] = ch;
            createWord = false;
        }

        ch++;
    }

    return count;
}

/**
 * Executes the built-in exit command.
 * @param words the words in the user's command, an array of strings
 * @param count the number of words found in the user's command.
 */
void runExit( char *words[], int count )
{
    if( count != 2 ) { // Invalid argument count
        printf( "Invalid command\n" );
        return;
    }

    int exitStatus = parseInt( words[1] );
    if(exitStatus < 0 || exitStatus > 255) { // Invalid exit status
        printf( "Invalid command\n" );
        return;
    }

    exit(exitStatus);
}

/**
 * Executes the built-in cd command.
 * @param words the words in the user's command, an array of strings
 * @param count the number of words found in the user's command.
 */
void runCd( char *words[], int count )
{
    if( count != 2 ) { // Invalid argument count
        printf( "Invalid command\n" );
        return;
    }

    if( chdir( words[1] ) != 0) // Print error if chdir fails
        printf( "Invalid command\n" );
}

/**
 * Executes a non built-in command. [Adapted from 01-OS-Intro.pdf slide 33.]
 * @param words the words in the user's command, an array of strings
 * @param count the number of words found in the user's command.
 */
void runCommand( char *words[], int count )
{
    // Extra credit -- Check if any child has ended but don't hang. Loop if
    // multiple.
    pid_t bg_pid;
    while( (bg_pid = waitpid(-1, NULL, WNOHANG)) > 0 )
        printf("[%d done]\n", bg_pid );

    // If the command ends with an amberstand, set a run-in-background flag.
    bool background = false;
    if(strncmp(words[count-1], "&", 2) == 0) {
        background = true;
        count--; // Remove & from command
    }

    pid_t pid = fork();

    // Cannot create child.
    if( pid == -1 ) {
        fprintf( stderr, "Can't run command %s\n", words[0] );
        return;
    }

    // Child process
    if( pid == 0 ) {
        // Copy words into a new array so we can append NULL.
        char *argv[514];
        for(int i = 0; i < count; i++) {
            argv[i] = words[i];
        }
        words[count] = NULL;
        
        execvp( words[0], argv );

        // On success, never returns; error otherwise.
        fprintf( stderr, "Can't run command %s\n", words[0] );
        exit(0);
    } else {
        // Parent process
        if(background) // Print pid if in background
            printf("[%d]\n", pid );
        else // Wait for the processed we just spawned and nothing else.
            waitpid( pid, NULL, 0 );
    }
}

/**
 * Reads a line from the input. [Adapted from own work from CSC230, p5/input.c.]
 * @param line String of 1026 byte length (1024 without terminatation)
 * @returns returns new line
 */
void readLine(char* line) {
    char ch = '\0';
    int length = 0;

    while ( ( scanf( "%c", &ch ) ) == 1 ) {
        if( ch == '\n' )
            break;

         line[length++] = ch;
    }

    line[length] = '\0';
}

/**
 * Entry point of the program.
 * @param argc number of arguments.
 * @param argv array of arguments.
 * @return exit status.
 */
int main( int argc, char *argv[] ) {

    // Run REPL forever
    while( 1 ) {
        // Prompt
        printf("stash> ");
        char line[1026];
        readLine(line);

        // Parse
        char *words[513];
        int count = parseCommand(line, words);

        // Built-in "command" -- empty.
        if(count == 0)
            continue;

        // Built-in command cd
        if(strncmp(words[0], "cd", 3) == 0)
            runCd( words, count );

        // Built-in command exit
        else if(strncmp(words[0], "exit", 5) == 0)
            runExit( words, count );

        // Run a non built-in
        else
            runCommand( words, count );
    }

    // This should never happen
    return EXIT_FAILURE;
}
