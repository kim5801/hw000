/**
 * Homework 0 - Problem 3 - CSC 246
 * @author Ian Murray (iwmurray)
 */

#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>

/**
 * Prints the usage of the program and exits.
 */
void printUsage() {
    write(STDERR_FILENO, "usage: exclude <input-file> <output-file> <line-number>\n", 57);
    _exit(1);
    
}

/**
 * Parses an interger from string.
 * @param str string to parse
 * @return parsed interger, or -1 if invalid
 */
int parseInt( char *str ) {
    char *ch = str;
    int acc = 0;
    
    // Loop until null terminator
    while( *ch != '\0') {
        acc *= 10;

        if( *ch < '0' || *ch > '9') // Invalid character
            return -1; 

        acc += *ch - '0'; // Normalize value
        ch++;
    }

    return acc;
}

/**
 * Entry point of the program.
 * @param argc number of arguments.
 * @param argv array of arguments.
 * @return exit status.
 */
int main( int argc, char *argv[] ) {
    if(argc != 4) // Must have 3 arguments
        printUsage(); 

    int excludeLine = parseInt(argv[3]);
    if(excludeLine < 0) // Invalid line number
        printUsage(); 

    int inFile = open( argv[1], O_RDONLY );
    if(inFile < 0) // Unable to open input file
        printUsage(); 

    int outFile = open( argv[2], O_WRONLY | O_CREAT | O_TRUNC, 0600 );
    if(outFile < 0) { // Unable to open output file
        close(inFile);
        printUsage();
    }

    char readBuffer[64];
    int bytesRead;
    int currentLine = 1;
    
    // Read and write characters in a loop while characters remain
    while( (bytesRead = read( inFile, &readBuffer, 64 )) ) {
        char outputBuffer[64];
        int bytesToWrite = 0;

        // Scan through each character and add it to an output buffer if we are
        // not in the line to exclude.
        for( int i = 0; i < bytesRead; i++ ) {
            if( currentLine != excludeLine )
                outputBuffer[bytesToWrite++] = readBuffer[i];
            
            // Increment the line if we hit a line feed
            if( readBuffer[i] == '\n' )
                currentLine++;
        }

        write( outFile, &outputBuffer, bytesToWrite );
    }

    close(inFile);
    close(outFile);

    return 0;
}
