/**
    @file exclude.c
    @author Erin Grouge
    It takes the given input file and line number, skipping that specified line when 
    writing to the output file.
 */

#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>

/** Indicates an error in execution used for error checking */
#define ERR -1

/** Checks if the character is a valid number (0-9)
    @param ch the character to check
    @return true if the character is valid
 */
static int isValid(char ch)
{
    return (ch >= '0' && ch <= '9');
}
/**
    Prints the usage and exits with failure. 
 */
static void usage()
{
    const char usage[] = "usage: exclude <input-file> <output-file> <line-number>\n";
    write(STDERR_FILENO, &usage, sizeof(usage));
    _exit(1);
}

/** Parses the given string to an integer value
    @param the string to parse
    @return val the integer value of the string
 */
static int parse(char * str)
{
    int val = 0;
    int i = 0;
    // While not at the end, read digits left to right, updating decimal value as you go.
    while(str[i] != '\0'){
        // If not valid characters, return -1
        if(!isValid(str[i])){
            return ERR;
        }

        // Convert to integer value
        int num = str[i] - '0';
        // Shift left digits over by multiplying by 10
        val = val * 10 + num;
        i++;
    }
    return val;
}

/**
    Reads the input file, skipping over the specified line when rewriting
    it to the output file
    @param argc the number of arguments
    @param argv the array of arguments
    @return exit status
 */
int main( int argc, char *argv[] ) 
{
    // Print usage if incorrect # of args
    if(argc != 4){
        usage();
    }

    // Parse line number and print usage if line # not valid
    int line = parse(argv[3]);
    if(line == ERR || line == 0){
        usage();
    }

    // Open input file and print usage if file doesn't exist
    int input = open(argv[1], O_RDONLY);
    if(input == ERR ){
        usage();
    }

    // Open output file, creating a new one if it doesn't exist
    int output = open(argv[2], O_WRONLY | O_CREAT | O_TRUNC, 0600);
    
    // Start at 1 since it counts lines after they are read
    int lineCount = 1;

    // Keeps track of bytes read
    int bytes = 1;

    // Array to read bytes into
    char buffer[64];

    // If its the first line to be deleted, flag it so the first newline isn't printed
    int first = line == 1;

    // Read in bytes and print to output until there are no more bytes to be read
    while(bytes != 0){
        bytes = read(input, buffer, 64);
        // Loop through each byte checking for newline characters and skipping the specified line
        for(int i = 0; i < bytes; i++){
            if(buffer[i] == '\n'){
                lineCount++;
                // If the first line, don't write the newline character
                if(first){
                    first = 0;
                    continue;
                }
            }
            // If on the skip line, don't write
            if(lineCount == line){
                continue;
            }
            else{
                write(output, &buffer[i], sizeof(buffer[i]));
            }
        }
    }

    // Close files and return success
    close(input);
    close(output);

    _exit(0);
}

