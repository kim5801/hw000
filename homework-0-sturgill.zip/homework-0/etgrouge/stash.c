/**
    @file stash.c
    @author Erin Grouge
    This program runs just like a standard shell program, reading in input from the user,
    executing shell commands appropriately, and notifying the user when commands are invalid.
 */
#include <stdlib.h>
#include <stdio.h>
#include <string.h>

#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>
#include <sys/wait.h>

/**
    Prints the error message when the user tries to enter an invalid command
 */
static void error()
{
    char errormsg[] = "Invalid command";
    printf("%s\n", errormsg);
}

/**
    Prints the command prompt
 */
static void prompt()
{
    char promptmsg[] = "stash> ";
    printf("%s", promptmsg);
}

/** Checks if the character is a valid number (0-9)
    @param ch the character to check
    @return true if the character is valid
 */
static int isValid(char ch)
{
    return (ch >= '0' && ch <= '9');
}

/** Parses the given string to an integer value
    @param the string to parse
    @return val the integer value of the string
 */
static int parse(char * str)
{
    int val = 0;
    int i = 0;
    // While not at the end, read digits left to right, updating decimal value as you go.
    while(str[i] != '\0'){
        // If not valid characters, return -1
        if(!isValid(str[i])){
            return -1;
        }
        // Convert to integer value
        int num = str[i] - '0';
        // Shift left digits over by multiplying by 10
        val = val * 10 + num;
        i++;
    }
    return val;
}

/** Takes a line of input, breaking it word by word into the array
    and returning the number of words found.
    @param line the string to break up
    @param words the array to hold each word
    @return count the number of words in the line
 */
int parseCommand(char * line, char * words[])
{
    int count = 0;
    char ch = line[0];
    // Check for empty string
    if(ch == '\0'){
        return 0; 
    }

    int i = 0;
    int newWord = 1; // boolean flag for indicating the start of a new word

    // While the end of the string has not yet been reached, replace the spaces with null characters,
    // keep track of the word count, and fill in the array of command word pointers. 
    while(ch != '\0'){
        // If space, replace with null and notify newWord flag that a new word is coming next
        if(ch == ' '){
            line[i] = '\0';
            newWord = 1;
        } 
        // When characters after space, increase count and add pointer to words
        else if(newWord){
            newWord = 0;
            words[count] = &line[i];
            count++;
        }
        i++;
        ch = line[i];
    }
    // Add null to indicate end of array
    words[count] = NULL;

    return count;
}

/** Performs the built-in exit shell command
    @param words the array of words
    @param count the number of words
 */
void runExit( char * words[], int count)
{
    // If incorrect argument amount, print error message
    if(count != 2){
        error();
        return;
    }
    int status = parse(words[1]);
    // If the line number is invalid, print error message
    if(status == -1){
        error();
        return;
    }

    exit(status);
}

/** Performs the built-in cd shell command
    @param words the array of words
    @param count the number of words
 */
void runCd( char * words[], int count)
{
    // If incorrect argument amount, print error message
    if(count != 2){
        error();
        return;
    }

    int valid = chdir(words[1]);

    // If directory doesn't exist, print error message
    if(valid == -1){
        error();
        return;
    }

}

/** Performs the runs the given shell command by creating a child process
    @param words the array of words
    @param count the number of words

    Citation: Referenced OS Intro Slide 33
 */
void runCommand( char * words[], int count)
{
    // fork to create child process
    pid_t pid = fork();

    char msg[] = "Can't run command";

    // If the child could not be created, print error message
    if( pid == -1){
        printf("%s %s\n", msg, words[0]);
        return;
    }
    // If forking a child process successful, have it run command
    if(pid == 0){
        int err = execvp(words[0], words);
        // If running the command was unsuccessful, print error message and exit child.
        if(err == -1 ){
            printf("%s %s\n", msg, words[0]);
            exit(EXIT_FAILURE);
        } 
    }
    else{
        wait(NULL);
    }
    
}

/** Reads the command line from standard input, returning it as a string pointer
    @return line the command line entered from user
 */
char * readLine(){
    // Get character one by one from input
    char ch = fgetc(stdin);
    // Allocated a big enough string to hold it
    char * line = (char *)malloc(1024 * sizeof(char));
    int i = 0;
    // Until end of input, read each character and add them to the line
    while(ch != EOF && ch != '\n')
    {
        line[i] = ch;
        i++;
        ch = fgetc(stdin);
    }
    // Add null terminator and return 
    line[i] = '\0';
    return line;
}


/** Starts the main program. Requests commands from user and executes them as shell commands.
    @param argc number of arguments
    @param argv the array of arguments
 */
int main(int argc, char * argv[]){
    // Declare and define variables
    int done = 0;
    int wordCount = 0;
    // Declare the command line and array of command words
    char * comLine;
    char ** comWords;

    // Until the user exits, request shell commands and run them accordingly.
    while(!done){
        // Prompt the user for a command, read their input, 
        // parse the command line, and run the command
        prompt();
        comLine = readLine();
        comWords = (char **)malloc(512 * sizeof(char *));
        wordCount = parseCommand(comLine, comWords);
        // If empty, skip this iteration and reprompt
        if(wordCount == 0){
            // do nothing
        } 
        // If cd command, runCd
        else if(strcmp(comWords[0], "cd") == 0){
            runCd(comWords, wordCount);
        } 
        // If exit command, runExit
        else if( strcmp(comWords[0], "exit") == 0){
            runExit(comWords, wordCount);
        } 
        // If any other command, runCommand
        else {
            runCommand(comWords, wordCount);
        }
        // Free allocated memory 
        free(comWords);
        free(comLine);
    }

    return EXIT_SUCCESS;
}

