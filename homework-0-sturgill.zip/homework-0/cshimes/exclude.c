/**
 * @file exclude.c
 * @author Cameron Himes
 * @brief Copies one text file to another, excluding a line based on a command-line argument
 */
#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>

/** The user must pass three command-line arguments */
#define REQUIRED_NUM_CMD_ARGS 3

/** Used to convert ascii to decimal */
#define ZERO_ASCII 48

/** The number of bytes to read in at a time */
#define BYTES_TO_READ 64

/** The hexadecimal code for a newline character */
#define NEWLINE_HEX_CODE 0x0a

/**
 * @brief Writes to STDERR indicating the program was being misused, exits with status code 1
 * 
 */
void handleInvalidCmdArguments() {
    int bufferSize = sizeof("usage: exclude <input-file> <output-file> <line-number>\n");
    write(STDERR_FILENO, "usage: exclude <input-file> <output-file> <line-number>\n", bufferSize);
    _exit(1);
}

int strToInt(char * txt) {
    // Determine the size of the given string
    int size = 0;

    for (int i = 0; txt[i] != '\0'; i++) {
        size++;
    }

    int num = 0;

    // Convert the string to an integer using multiplication and typecasting
    for (int i = size - 1, j = 1; i >= 0; i--, j *= 10) {
        num += ((int) txt[i] - ZERO_ASCII) * j;
    }
    return num;
}

int main( int argc, char *argv[] ) {
    // Check the validity of the commandline arguments
    if (argc - 1 != REQUIRED_NUM_CMD_ARGS) {
        handleInvalidCmdArguments();
    }

    int lineToExclude = strToInt(argv[3]);
    if (lineToExclude < 0) {
        handleInvalidCmdArguments();
    }

    // Try to open the file passed as the first argument
    int inputFileDesc = open(argv[1], O_RDONLY, S_IRWXU);
    if (inputFileDesc == -1) {
        handleInvalidCmdArguments();
    }

    // Try to open the output file for later
    int outputFileDesc = open(argv[2], O_WRONLY | O_CREAT | O_TRUNC, S_IRWXU);
    if (outputFileDesc == -1) {
        handleInvalidCmdArguments();
    }

    char buffer[BYTES_TO_READ];
    int bytesRead = read(inputFileDesc, buffer, BYTES_TO_READ);
    int lineBeingRead = 1;

    do {
        // Find the newline characters and write to the output file
        for (int i = 0; i < bytesRead; i++) {
            if (lineBeingRead != lineToExclude) {
                write(outputFileDesc, &buffer[i], 1);
            }
            if (buffer[i] == NEWLINE_HEX_CODE) {
                lineBeingRead++;
            }
        }

        // Read in 64 bytes
        bytesRead = read(inputFileDesc, buffer, BYTES_TO_READ); 
    } while (bytesRead != 0);

    close(inputFileDesc);
    close(outputFileDesc);
}