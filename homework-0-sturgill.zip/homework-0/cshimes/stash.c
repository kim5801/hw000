/**
 * @file stash.c
 * @author Cameron Himes
 * @brief A command-line with three built-in functions and the ability to delegate
 * to others inherent to the OS
 * 
 * @date 2022-09-01
 */

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h>
#include <errno.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <unistd.h>

/** The max command length is 1024 characters */
#define MAX_COMMAND_LENGTH 1024

/** The maximum number of words that could fit in 1024 characters */
#define MAX_WORDS 513

int parseCommand( char *line, char *words[] ) {
    // Replace all spaces with null terminators
    int lineLength = strlen(line);    
    for (int i = 0; i < lineLength; i++) {
        if (isspace(line[i])) {
            line[i] = '\0';
        }
    }

    // Make the words array point to the words in the user input line
    int wordCount = 0;
    for (int i = 0; i < lineLength; i++) {
        // Special case - grabbing the first word 
        if (i == 0 && line[i] != '\0') {
            words[wordCount] = &line[i];
            wordCount++;
        }
        else if (line[i] == '\0' && i != lineLength - 1 && line[i + 1] != '\0') {
            words[wordCount] = &line[i + 1];
            wordCount++;
        }
    }
    return wordCount;
}

void runCd( char *words[], int argCount ) {
    if (argCount != 1) {
        printf("Invalid command\n");
        return;
    }
    int chdirStatus = chdir(words[1]);

    if (chdirStatus == -1) {
        printf("Invalid command\n");
    }
}

void runExit( char *words[], int argCount ) {
    if (argCount != 1) {
        printf("Invalid command\n");
        return;
    }

    char *endptr; // Used to store characters that could not be converted to nums
    int exitStatus = strtol(words[1], &endptr, 10);
    if (strlen(endptr) != 0) {
        printf("Invalid command\n");
        return;
    }

    exit(exitStatus);
}

void runCommand( char *words[], int wordCount ) {
    int pid = fork();
    if (pid == 0) { // pid should be 0 for the child process
        words[wordCount] = NULL;
        
        int cmdStatus = execvp(words[0], words);
        if (cmdStatus == -1) {
            printf("Can't run command %s\n", words[0]);
        } 
        exit(EXIT_SUCCESS);
    } else {
        int returnStatus;
        waitpid(pid, &returnStatus, 0);
    }
}

int main( int argc, char *argv[] ) {
    while (1) {
        // Prompt the user for input
        printf("stash> ");

        // Get the user's input line
        char line[MAX_COMMAND_LENGTH + 1];
        char ch;
        int i = 0;
        while ((ch = getchar()) != '\n') {
            line[i] = ch;
            i++;
        }
        line[i] = '\0';
        
        // Parse the command from the input line
        char *words[MAX_WORDS];
        int wordCount = parseCommand(line, words);

        // Handle the three built-in commands
        if (wordCount == 0) {
            continue;
        }
        
        char * cmd = words[0];
        int argCount = wordCount - 1; // First word is the command
        if (strcmp(cmd, "cd") == 0) {
            runCd(words, argCount);
        } else if (strcmp(cmd, "exit") == 0) {
            runExit(words, argCount);
        } else {
            runCommand(words, wordCount);
        }
    }
}