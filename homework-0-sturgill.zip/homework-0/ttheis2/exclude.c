/**
 * @file exclude.c
 * @author Tadeo Theis ttheis2
 * Reads contents from an input file and copies it to an output file excluding
 * the chosen line from user input.
 */
 
#include <unistd.h>
#include <fcntl.h>

/** Correct number of args the program should receive */
#define NUM_ARGS 4

/** Place of the line to skip in argv */
#define LINE_NUMBER 3

/** Place in argv for the output file */
#define OUTPUT_FILE 2

/** Used to multiply the place value when reading in the line number to exclude */
#define TEN_MULTIPLIER 10

/** Max number of bytes to read into the buffer */
#define MAX_BYTES 64

/** Value large enough to print out the error message with write system call */
#define ERROR_LENGTH 70

/** Successfully exiting the program */
#define EXIT_SUCCESS 0
 
static void fail()
{
  write(STDERR_FILENO, "usage: exclude <input-file> <output-file> <line-number>", ERROR_LENGTH);
  _exit(1);
}
/**
 * Starting point of the program.
 * @param argc number of args
 * @param argv array of char pointers
 * @return exit status 0 if successful, or 1 if there was an error.
 */
int main(int argc, char *argv[])
{
  //If there are not four args the program fails and sends an error message
  if(argc != NUM_ARGS) {
    fail();
  }
  
  //values for the line number to exclude and keeping track of the ones, tens, hundreds, etc. place
  int line = 0;
  int place = 1;
  int cnt = 0;
  
  //gets length of the fourth command line argument
  while(argv[LINE_NUMBER][cnt]) {
    cnt++;
  }
  
  //Loops through the last string in argv and converts to an integer
  for(int i = cnt - 1; argv[LINE_NUMBER][i]; i--) {
    if(argv[LINE_NUMBER][i] >= '0' && argv[LINE_NUMBER][i] <= '9') {
      line += (argv[LINE_NUMBER][i] - '0') * place;
      place *= TEN_MULTIPLIER;
    } else {
      fail(); //fails if the char is not a number 0 to 9
    }
  }
  
  //constants for number of lines and skipping or not skipping a line
  int line_cnt = 0;
  _Bool skip = 0;
  
  //opening the files to read from and write to
  int fd = open(argv[1], O_RDONLY);
  int fd2 = open(argv[OUTPUT_FILE], O_WRONLY | O_CREAT, 00700);
  if(fd == -1 || fd2 == -1) {
    fail();
  }
  
  //creat a char buffer to hold the characters from the input file and begin reading
  char buffer[MAX_BYTES];
  int len = read( fd, buffer, sizeof(buffer));
  if(len == -1) {
      fail();
  }
  
  //loop until there are no more chars in the input file
  while(len > 0) {
    //loop through the char buffer and skip the correct line
    for(int i = 0; i < len; i++) {
      //checks if at the line to skip
      if(line_cnt == line - 1) {
        skip = 1; //true
      }
      if(buffer[i] == '\n'){
        line_cnt++;
      }
      if(skip) {
        //means the line to skip is done so we can continue writing
        if(buffer[i] == '\n') {
          line_cnt++;
          skip = 0; //false
        }
      }else {
        //write to the output file one char at a time
        write(fd2, buffer + i, 1);
        //add code to fail if return is -1
      }
    }
    len = read( fd, buffer, sizeof(buffer));
    if(len == -1) {
      fail();
    }
  }
  
  //close the files I opened earlier
  close(fd);
  close(fd2);
  
  //exit successfully
  return EXIT_SUCCESS;
}