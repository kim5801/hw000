/**
 * @file stash.c
 * @author Tadeo Theis ttheis2
 * Shell program that takes three commands and sends others to a child
 * process
 */
 
#include <stdlib.h>
#include <stdbool.h>
#include <stdio.h> 
#include <string.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/wait.h>

/** Max number of chars in a line */
#define MAX_CHARS 1024

/** max number of strings in a line */
#define MAX_STRINGS 513

/** max number of arguments for the cd and exit commands */
#define MAX_ARGS 2

/**
 * Parses a given char array and adds null terminators in place of spaces
 * @param line an array of chars.
 * @param words an array of char pointers used to point to all the individual
 * strings in the line array.
 * @return the number of strings, non null pointers, in the words array.
 */
int parseCommand( char *line, char *words[] )
{
  //printf("I reached parseCommand\n");
  bool isSpace = false;
  int num_words = 0;
  for(int i = 0; line[i]; i++) {
    if(i == 0) {
      words[num_words] = line;
      num_words++;
    }
    if(line[i] == ' ') {
      line[i] = '\0';
      isSpace = true;
    } else if(isSpace) {
      words[num_words] = line + i;
      num_words++;
      isSpace = false;
    }
  }
  return num_words;
}

/**
 * Runs the exit command, prints invalid command and returns to main if anything
 * is wrong with the command. Exits with the given exit status if everything is right.
 * @param words an array of char pointers used to point to all the individual
 * strings from the user.
 * @param count the number of strings in the words array.
 */
void runExit( char *words[], int count )
{
  int val;
  if(count != MAX_ARGS) {
    printf("Invalid command\n");
  } else if(!(strcmp(words[1], "0"))) {
    exit(0);
  } else if((val = atoi(words[1])) == 0) {
    printf("Invalid command\n");
  } else {
    exit(val);
  }
}

/**
 * Runs the cd command, prints invalid command and returns to main if anything
 * is wrong with the command. Changes to the desired directory if everything is correct.
 * @param words an array of char pointers used to point to all the individual
 * strings from the user.
 * @param count the number of strings in the words array.
 */
void runCd( char *words[], int count )
{
  int check = chdir(words[1]);
  if (count != MAX_ARGS) {
    printf("Invalid command\n");
  } else if (check ==  -1) {
    printf("Invalid command\n");
  }
}

/**
 * Runs commands by making a child process and using execvp(). If something goes wrong
 * an error message is printed out and the program returns to main.
 * @param words an array of char pointers used to point to all the individual
 * strings from the user.
 * @param count the number of strings in the words array.
 */
void runCommand( char *words[], int count )
{
  int pid = fork();
  words[count] = NULL;
  if ( pid == 0 ) {
    int status = execvp(words[0], words);
    
    if(status == -1) {
      printf("Can’t run command %s\n", words[0]);
    }
    
    exit( EXIT_SUCCESS );
  }
  
  wait(NULL);
}

/**
 * The starting point of the program. Runs an infinite loop that keeps addressing 
 * the user until it is exited. Works with the other methods to run the small stash 
 * shell window.
 */
int main()
{
  //naming all constants needed to run the loop
  char command[MAX_CHARS];
  char ch;
  int ch_cnt;
  char *words[MAX_STRINGS];
  int word_cnt;
  
  //infinite loop that keeps queuing the user
  while(true) {
    //reseting values to zero from last command
    ch_cnt = 0;
    word_cnt = 0;
    printf("stash> ");
    ch = getchar();
    //while on the same line keep reading chars
    while(ch != '\n') {
      //printf("I made it into the getchar loop\n");
      command[ch_cnt] = ch;
      ch_cnt++;
      if(ch_cnt >= MAX_CHARS) {
        exit(1);
      }
      ch = getchar();
    }
    
    //if no chars were read go to the next iteration of the loop
    if(ch_cnt == 0) {
      //printf("I made it into the blank checker\n");
      continue;
    }
    
    //parse the line
    word_cnt = parseCommand(command, words);
    
    //run the appropriate command
    if(!(strcmp(words[0], "exit"))) {
      //printf("I made it into the exit check\n");
      runExit(words, word_cnt);
      //resetWords(words, word_cnt);
    } else if(!(strcmp(words[0], "cd"))) {
      runCd(words, word_cnt);
      //resetWords(words, word_cnt);
    } else {
      runCommand(words, word_cnt);
      //resetWords(words, word_cnt);
    }
    
    //reset the arrays so that no data is left over from the last command
    for(int i = 0; i < ch_cnt; i++) {
      command[i] = '\0';
    }
    for(int i = 0; i < ch_cnt; i++) {
      words[i] = NULL;
    }
  }
  return 0;
}