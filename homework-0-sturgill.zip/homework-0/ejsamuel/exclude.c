/**
	@file exclude.c
	@author Eric Samuel (ejsamuel)
	A program that excludes a user specified line of text from the text file.
*/

#include <fcntl.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>

/** The number 10 to help us traverse the string and convert to int */
#define TENSTRAVERSAL 10

/**
 * This is a manual method that converts a given string to an integer
 * @param arr is the "string" that is the line that needs to be excluded. It will be converted to the line number integer
 * @return the integer value for the string passed
 */
int stringtoint(char *arr) {
    int total = 0;
    for(int i = 0; arr[i] != '\0'; i++) {
        total = total * TENSTRAVERSAL + arr[i] - '0';
    }
    return total;
}


/**
 * The main function that facilitates the program
 * @param argc the number of cl arguments
 * @param argv the array of cl arguments
 * @return exit status
 */
int main( int argc, char *argv[] ) {

    
    int fd = open(argv[1], O_RDONLY);
    int fp = open(argv[2], O_WRONLY | O_CREAT | O_TRUNC, 0600);
    int exclude = stringtoint(argv[3]);

    if(fd < 0) {
        char msg[] = "usage: exclude <input-file> <output-file> <line-number>\n";
        write(STDERR_FILENO, msg, sizeof(msg));
        _exit(1);
    }

    char buffer[64];
  
    int length;
    int count = 1;
    while((length = read(fd, buffer,64)) > 0) {
        
        int stop = 0;
        for(int i = 0; i < length; i++) {
            if(buffer[i] == '\n') {
                count++;
                
            }
            if(count == (exclude)) {
                stop = 1;
            } else {
                stop = 0;
            }

            if(stop != 1) {
                write(fp, &buffer[i], 1);
            }
           
        }
    }
    
    close(fd);
    close(fp);
    return 0;
}

