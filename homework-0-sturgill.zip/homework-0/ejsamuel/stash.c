/**
	@file stash.c
	@author Eric Samuel (ejsamuel)
	A program where I create my own 'terminal'
*/

#include <stdio.h>
#include <string.h>
#include <stdbool.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <stdlib.h>
#include <ctype.h>

/** The max amount of characters in input */
#define MAXL_LINE_OF_INPUT 1025

/** The max amount of words in input */
#define MAX_WORDS 513


/**
 * This function takes a user command (line) as input. It breaks the line into
    individual words, adds null termination between the words so each word is a separate string, and
    it fills in a pointer in the words array to point to the start of each word.
 * @param line the line of input from user
 * @param wordsp the array of char pointers (the array of words)
 * @return s the number of words found in the given line
 */
int parseCommand(char *line, char *wordsp[]) {
    
    int wordCount = 0;
    int index = 0;
    int startWord = 0;
    bool spaceFound = false;
    while(line[index] != '\0') {
        if(line[index] == ' ' && !spaceFound) {
            line[index] = '\0';
            wordsp[wordCount] = &line[startWord];
            spaceFound = true;
            wordCount++;
           
        } else if (line[index] != ' ' && spaceFound) {
            startWord = index;
            spaceFound = false;
            if(line[index + 1] == '\0') {
                wordsp[wordCount] = &line[startWord];
                wordCount++;
            }
            

        } else if (line[index + 1] == '\0') {
            wordsp[wordCount] = &line[startWord];
            wordCount++;
        }
        
        index++;
    }
    wordsp[wordCount] = '\0';
    return wordCount;
}
/**
 * This function performs the built-in exit command.
 * @param words list of pointers to words in the user’s command
 * @param count number of words in the array
 */
void runExit(char *words[], int count) {

    int testExit = 0;
    if(count > 2) {
        printf("Invalid command\n");
        return;
    }
    if(count == 2) {
        testExit = atoi(words[1]);
        if(strcmp(words[1], "0") == 0) {
            exit(EXIT_SUCCESS);
        } else if(testExit == 0) {
            printf("Invalid command\n");
            return;
        }
    }
 
    if(count == 1) {
        
        exit(EXIT_SUCCESS);
        
    } else if (strcmp(words[1], "0") == 0) {
        
         exit(EXIT_SUCCESS);
         
    } else if (testExit != 0) {
        
        exit(testExit);
       
    } else if (isdigit(words[1]) != 0) {
        
        printf("Invalid command\n");
    } else {
         printf("Invalid command\n");
    }


    
    
}

/**
 * performs the built-in cd command
 * @param words list of pointers to words in the user’s command
 * @param count number of words in the array
 */
void runCd(char *words[], int count) {
    if(count > 2 || chdir(words[1]) != 0) {
        printf("Invalid command\n");
        
    } else {
        chdir(words[1]);
    }

}

/**
 * runs a (non-built-in) command by creating a child process and having it call execvp() to run the given command
 * @param words list of pointers to words in the user’s command
 * @param count number of words in the array
 */
void runCommand(char *words[], int count) {
    pid_t pid = fork();
    if(pid == -1) {
        printf("Can't create child");
    }
    if(pid == 0) {
        int commandCheck = execvp(words[0], words);
        if(commandCheck == -1) {
            printf("Can't run command %s\n", words[0]);
            exit(EXIT_SUCCESS);
        }
    } else {
        wait(NULL);
    }
   
}

int main(int argc, char *argv[] ) {
    bool running = true;
    while(running) {
        char buffer[MAXL_LINE_OF_INPUT];
        char *words[MAX_WORDS];
        printf("stash> ");
        char c;
        int i = 0;
        while ((c = getchar()) != '\n'){
            buffer[i++] = c;
        }
        buffer[i] = '\0';
        // printf("%s", buffer);
        if(buffer[0] == '\0') {
            continue;
        }
        int length = parseCommand(buffer, words);
       
        if(strcmp(words[0], "cd") == 0) {
            runCd(words, length);
        } else if (strcmp(words[0], "exit") == 0) {
            runExit(words, length);
        } else {
            runCommand(words, length);
        }
        
    }
    


}