/**
 * @file exclude.c
 * @author Drew Cada aecada2
 * @brief a program that takes 3 command line inputs: an input file, an output file and the line number to remove.
 * It then removes the line associated with the line number in question
 */

#include <fcntl.h>
#include <stdio.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <unistd.h>

void fail(char *message, int messageLength)
{
    write(STDERR_FILENO, message, messageLength);
    _exit(1);
}

int myPow(int x, int y)
{
    int rtn = 1;
    for (int i = 0; i < y; i++) {
        rtn *= x;
    }
    return rtn;
}

int main(int argc, char const *argv[])
{
    // checks that there are the correct number of args
    if (argc != 4) {
        fail("Incorrect arguments\n", 21);
    }
    // initialize values to 0, n is line to remove
    int len = 0, n = 0;

    // interprets the line to parse, constructing it in n
    while (argv[3][len]) {
        len++;
    }
    for (int i = len; i > 0; i--) {
        if (argv[3][i - 1] >= '0' && argv[3][i - 1] <= '9') {
            n += (argv[3][i - 1] - '0') * myPow(10, len - i);
        } else {
            fail("Argument 4 is NaN\n", 19);
        }
    }

    // opening the files
    // fail if you cant open either file properly
    int in = -1, out = -1;
    in = open(argv[1], O_RDONLY);
    if (in == -1) {
        close(in);
        fail("Could not open input file\n", 27);
    }
    out = open(argv[2], O_WRONLY | O_CREAT, 0600);
    if (out == -1) {
        close(out);
        fail("Could not open output file\n", 28);
    }

    // start reading the file in
    char arr[64] = {};
    int lenRead = read(in, arr, 64);
    // lines read so far
    int lineCounter = 1;
    // contiues until eof is reach or the break condition is met below
    while (lenRead != 0) {
        // fail if there is an error reading in the file
        if (lenRead == -1) {
            close(in);
            close(out);
            fail("failure while reading in file\n", 31);
        }
        for (int i = 0; i < lenRead; i++) {
            if (arr[i] == '\n') {
                lineCounter++;
            }
            // if you are on the line to be deleted dont write
            if (n - lineCounter != 0) {
                write(out, &(arr[i]), 1);
            }
        }
        // stops when length read is less than 64
        if (lenRead < 64)
            break;

        lenRead = read(in, arr, 64);
    }
    close(in);
    close(out);

    return 0;
}
