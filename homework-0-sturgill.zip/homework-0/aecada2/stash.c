#define _POSIX_C_SOURCE 1
#define _SVID_SOURCE 1
#include <errno.h>
#include <signal.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/ipc.h>
#include <sys/shm.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <unistd.h>

int parseCommand(char *line, char *words[])
{
    if (line[0] != '\0') {
        // printf("line length: %zu\n", strlen(line));
        int wordCnt = 0;
        int lastWordIdx = 0;
        int len = strlen(line);
        for (size_t i = 0; i < len; i++) {
            if (line[i] == ' ') {
                line[i] = '\0';
                // printf("got here 1\n");
                words[wordCnt] = malloc(i - lastWordIdx + 1);
                for (size_t j = lastWordIdx; j < i + 1; j++) {
                    words[wordCnt][j - lastWordIdx] = line[j];
                }
                wordCnt++;
                lastWordIdx = i + 1;
            } else if (line[i] == '\n') { // only 1 command is given
                line[i] = '\0'; // makes sure I dont copy the nl char over to
                                // the words array

                // printf("got here 2\n");
                words[wordCnt] = malloc(i - lastWordIdx + 1);
                for (size_t j = lastWordIdx; j < i + 1; j++) {

                    words[wordCnt][j - lastWordIdx] = line[j];
                }
                if (i != 0) {
                    wordCnt++;
                }
            }
        }
        return wordCnt;
    } else {
        return 0;
    }
}

void runExit(char *words[], int count)
{
    if (count != 2) { // checks that there are the right number of args
    fail:
        printf("Invalid command\n");
        return;
    } else {
        int i = 0;
        while (words[1][i]) {
            if (words[1][i] < '0' ||
                words[1][i] > '9') { // checks that the second arg is a number
                goto fail;
            }
            i++;
        }
        int exitCode = atoi(words[1]);

        shmctl(shmget(9876, 8, 0), IPC_RMID, 0); // deletes shared memory
        i = 0;
        while (words[i]) { // frees malloced words from memory
            free(words[i]);
            i++;
        }

        _exit(exitCode);
    }
}

void runCd(char *words[], int count)
{
    if (count != 2 ||
        chdir(words[1]) == -1) { // checks that there are the right number of
                                 // args and that chdir doesnt return a failure
        printf("Invalid command\n");
        return;
    }
}

void runCommand(char *words[], int count)
{
    pid_t pid = fork();

    if (pid != 0) {

        int shmid =
            shmget(9876, 8,
                   0666 | IPC_CREAT); // setting up the shared memory space
        if (shmid == -1) {
            perror("shmget failed");
        }

        char *sbuffer =
            (char *)shmat(shmid, 0, 0); // add shared memory to address space
        if (strcmp(words[count - 1], "&") ==
            0) { // if you are about to run a background task wait for the pid
                 // value to be printed to console before returning
            sbuffer[7] = 1;
            while (sbuffer[7] == 1)
                ;
        } else {
            // wait(NULL);
            waitpid(pid, NULL, 0); // waits if it isnt a background process
        }
        shmdt(sbuffer); // detach from shared memory
    }

    if (pid == 0) {
        // printf("pid: %d", getpid());
        int shmid = shmget(9876, 8, 0); // set up child access to share memory
        char *sbuffer =
            (char *)shmat(shmid, 0, 0); // add shared memory to address space

        // checks if any elements of the buffer used for the
        // background pid are not 0, and if they are checks if the
        // background process has finished before printing done and
        // resetting the saved background pid
        if (waitpid(atoi(sbuffer), NULL, WNOHANG) != 0 && atoi(sbuffer) != 0) {

            printf("[%s done]\n", sbuffer);
            memset(sbuffer, 0, 7);
            sbuffer[7] = 0;
        }

        //============
        //=DEPRECATED=
        //============
        // for (size_t i = 0; i < 7;
        //      i++) { // checks if any elements of the buffer used for the
        //             // background pid are not 0, and if they are checks if
        //             the
        //             // background process has finished before printing done
        //             and
        //             // resetting the saved background pid

        //     if (sbuffer[i] != '\0' && kill(atoi(sbuffer), 0) == -1) {
        //         sbuffer[7] = 1;
        //         printf("[%s done]\n", sbuffer);
        //         memset(sbuffer, 0, 7);
        //         sbuffer[7] = 0;
        //         break;
        //     }
        // }

        if (strcmp(words[count - 1], "&") == 0) {
            snprintf(sbuffer, 7, "%d", getpid());
            printf("[%s]\n", sbuffer); // prints pid for background process
            sbuffer[7] = 0; // frees master from waiting so it is able to go
                            // back to cmd line

            words[count - 1] =
                (char *)NULL; // prevents ampersand from being parsed in command
        } else {
            words[count] = (char *)NULL;
        }

        shmdt(sbuffer); // detach from shared memory

        if (execvp(words[0], words) == -1) { // executes the new command
            printf("Can't run command %s\n", words[0]);
            return;
        }
    }
}

int main(int argc, char const *argv[])
{
    // line to be read into
    char line[1026] = {};
    char *words[513] = {};

    while (true) {
        // prompts the user
        printf("stash> ");
        // reads into the line from stdin
        fgets(line, sizeof(line), stdin);
        // parses the command into words
        int wordCnt = parseCommand(line, words);
        // for (size_t i = 0; i < wordCnt; i++) {
        //     printf("words[%zu]: %s\n", i, words[i]);
        // }
        // printf("wordCnt: %d\n", wordCnt);

        // determining which command to run
        if (wordCnt == 0) { // if no words were entered
            continue;
        } else if (strcmp(words[0], "exit") == 0) { // if the first word is exit
            // printf("attempted to exit");
            runExit(words, wordCnt);
        } else if (strcmp(words[0], "cd") == 0) { // if the first word is cd
            runCd(words, wordCnt);
        } else { // do the other things
            runCommand(words, wordCnt);
        }
    }
    return 0;
}
