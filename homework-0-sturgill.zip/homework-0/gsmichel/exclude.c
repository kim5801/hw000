#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>
/**
  This program takes an input file, an output file and a line number. It writes everything from the input file to the output file except for
  the one line number provided.
  @file exclude.c
  @author Gabriella Micheli gsmichel
*/
int main(int argc, char *argv[]){
  //Throws errors if the arguments are wrong
  if(argc < 4 || argc > 4){
    write(STDERR_FILENO, "usage: exclude <input-file> <output-file> <line-number>\n", 56);
    _exit(-1);
  }
  int places = 1;
  char *buff = argv[3];
  int line_num = 0;
  //read number of digits in number
  while(buff[places] != '\0'){
    places++;
  }
  //convert number to integer
  int count = 0;
  for(int i = places - 1; i >= 0; i--){
    int temp = 0;
    if (buff[i] < '0' || buff[i] > '9'){
      write(STDERR_FILENO, "usage: exclude <input-file> <output-file> <line-number>\n", 56);
      _exit(-1);
    }
    temp += (buff[i] - '0');
    for ( int j = 0; j < count; j++){
       temp *= (10);
    }
    line_num += temp;
    count++;
  }
  //open file and read and write 64 bytes at a time
  int lines = 1;
  int fpR = open( argv[1], O_RDONLY);
  int fpW = open( argv[2], O_CREAT | O_WRONLY | O_TRUNC, 0600);
  if (fpR == -1 || fpW == -1){
    write(STDERR_FILENO, "usage: exclude <input-file> <output-file> <line-number>\n", 56);
    _exit(-1);
  }
  char buffer[65];
  int check = 64;
  while(check == 64){
    //read the bytes
    check = read(fpR, buffer, 64);
    //write to file
    for ( int i = 0; i < check; i++){
      //writes unless the line number excluded

      if(lines != line_num)
        write(fpW, buffer + i, 1);
      
      //check for new lines
      if(buffer[i] == '\n'){
        lines++;
      }
    }
  }
  
  
  close(fpR);
  close(frW);
  _exit(0);
  
}