#include <sys/types.h>
#include <sys/stat.h>
#include <sys/wait.h>
#include <fcntl.h>
#include <unistd.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <ctype.h>

/**
  This function takes a user command (line) as input. As described above it breaks the line into
  individual words, adds null termination between the words so each word is a separate string, and
  it fills in a pointer in the words array to point to the start of each word. It returns the number
  of words found in the given line. The words array should be at least 513 elements in length, so it
  has room for the largest possible number of words that could fit in a 1024-character input line
  @param line the full line with the command and arguments
  @param words an array of pointers that point to the start of each word
  @return the number of words parsed
*/
int parseCommand( char *line, char *words[] ){
  int len = strlen(line);
  //char temp[1025];
  //int j = 0;
  int num = 0;
  for(int i = 0; i < len ; i++){
    if( i == 0){
       words[num] = &line[0];
       num++;
    }
    if(isspace(line[i])){
      line[i] = '\0';
      i++;
      while(isspace(line[i])){
        i++;
      }
      if ( i != len){
        words[num] = &line[i];
        num++;
      }
      i--;
    }
   
  }
  

  //line = temp;
  line[len] = '\0';
  return num;
}
/**
  This function performs the built-in exit command. The words array is the list of pointers to words
  in the user�s command and count is the number of words in the array.
  @param words an array of pointers that point to the start of each word
  @param count the number of words in the line
*/
void runExit( char *words[], int count ){

  if(count > 2 || count < 2){
    printf("Invalid Command\n");
  } else {
    //parse status into integer
    int len = strlen(words[1]);
    char *buff = words[1];
    int status = 0;
    int flag = 0;
    int num = 0;
    for(int i = len - 1; i >= 0; i--){
      int temp = 0;
      if (buff[i] < '0' || buff[i] > '9'){
        printf("Invalid Command\n");
        flag = 1;
      }
      temp += (buff[i] - '0');
      for ( int j = 0; j < num; j++){
         temp *= (10);
      }
      status += temp;
      num++;
    }
    
    //if not invalid, exit
    if (flag == 0){
      exit(status);
    }
  }
}
/**
  This function performs the built-in cd command. As with runExit(), the parameters give the
  words in the command entered by the user.
  @param words an array of pointers that point to the start of each word
  @param count the number of words in the line 
*/
void runCd( char *words[], int count ){
  if(count > 2 || count < 2){
    printf("Invalid Command\n");
  } else {
    int check = chdir(words[1]);
    if (check == -1){
      printf("Invalid Command\n");
    }
  }
}

/**
  This function runs a (non-built-in) command by creating a child process and having it call execvp()
  to run the given command.
  @param words an array of pointers that point to the start of each word
  @param count the number of words in the line
*/
void runCommand( char *words[], int count ){
  int id = fork();
  if (id == 0){
    pid_t err = execvp(words[0], words);
    if (err == -1){
      printf("Cannot run command %s\n", words[0]);
    }
    exit(1);
  } else {
    wait(NULL);
  }
}

/**
  Main function of the program
  @param argc number of arguments
  @param argv the arguments
  @return the exit status
*/
int main(int argc, char *argv[]){
  printf("stash> ");
  char line[1025];
  char *words[1025];
  fgets(line, 1024, stdin);
  line[1025] = '\0';
  int num_words = parseCommand(line, words);
  words[num_words] = '\0';
  int cont = 0;
  while ( cont == 0){
    if (strcmp(words[0],"cd") == 0){
      runCd(words, num_words);
    } else if (strcmp(words[0],"exit") == 0){
      runExit(words, num_words);
    } else if (strcmp(words[0],"") != 0){
      runCommand(words, num_words);
    }
    line[0] = '\0';
    printf("stash> ");
    fgets(line, 1024, stdin);

    line[1025] = '\0';
    num_words = parseCommand(line, words);
    words[num_words] = '\0';
  }
  
}