/**
 * This file contains a shell program that prompt the user for commands in the terminal and performs UNIX 
 * commands depending on the user's input.
 * 
 * @file stash.c
 * @author Sania Bolla (sbolla2)
 * @brief stash.c program is a shell program that prompts user for input
 * @date 2022-08-30
 * 
 * Using https://pages.github.ncsu.edu/engr-csc246-staff/web/sample/chapter01/forkExecWait.c code given during exercise 1 as reference
 * to do the runCommand() method: seeing how to do fork() and see who's functioning [the child or parent].
 * 
 */
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <stdbool.h>
#include <sys/wait.h>

/** Size of the word that can be input by the user */
#define WORD_SIZE 1024
/** ASCII value for a space */
#define SPACE 32
/** Number of words that can be input by the user */
#define WORD_AMOUNT 513
/** ASCII value for new line charcter */
#define NEW_LINE 10

/**
 * Parses a command by going through the command string and breaking up the words
 * The broken up words are then stored into a words array
 * 
 * @param line is the entire argument that the user put into the command line
 * @param words is the array of words that made up the users input in the command line
 * @return int wordArrayLocation is how many words were found in the input string
 */
int parseCommand( char *line, char *words[] )
{
    /**
     * Creating another 2D array so that it is easier to move words to the words array.
     * Gets rid of the use of pointers and makes it easier to work with the words
     */
    int currPointerRow = 0;
    int currPointerColumn = 0;
    int wordArrayLocation = 0;
    int spaceCount = 0;
    bool startOfLine = true;
    char myArray[WORD_SIZE][WORD_SIZE];
    // Need to perform this function to clear out myArray
    for (int i = 0; i < WORD_SIZE; i++) {
        for (int j = 0; j < WORD_SIZE; j++) {
            myArray[i][j] = 0;
        }
    }
    for(int i = 0; i < strlen(line); i++) {
        // Handles the situation where there is a lot of whitespace at the start
        if (startOfLine && line[i] == SPACE) {
            continue;
        }
        // Handles the situation where a space has not been hit in the command yet
        if (line[i] != SPACE) {
            startOfLine = false;
            spaceCount = 0;
            myArray[currPointerRow][currPointerColumn] = line[i];
            currPointerColumn++;
        // Handles the situation for when a space is input
        // If spaceCount is zero it means that this is the first space and therefore the last word can now be added to the words array
        } if (spaceCount == 0 && line[i] == SPACE) {
            spaceCount++;
            // curr[currPointerRow][currPointerColumn] = 0;
            words[wordArrayLocation] = myArray[currPointerRow];
            currPointerRow++;
            currPointerColumn = 0;
            wordArrayLocation++;
        }
    }
    // Taking care of the last word that was just processed before breaking out of the for loop
    myArray[currPointerRow][currPointerColumn] = 0;
    // Handling whitespace at the end of the line
    if (strcmp(myArray[currPointerRow], "") != 0) {
        words[wordArrayLocation] = myArray[currPointerRow];
        wordArrayLocation++;
    }
    words[wordArrayLocation] = 0;
    return wordArrayLocation;
}

/**
 * This method performs the basic exit function. If the user inputs exit and an integer,
 * this method will exit with the given integer being the return status.
 * 
 * @param words is the array of words that the user input into the command line
 * @param count is how many words are present in the words array
 */
void runExit( char *words[], int count )
{
    int exitStatus;
    //Using sscanf rather than atoi because there is no way to know if value was originally 0 with exit status
    int found = sscanf(words[1], "%d", &exitStatus);
    if (count != 2 || found != 1) {
        fprintf(stderr, "Invalid command\n");
    } else {
        exit(exitStatus);
    }
}

/**
 * Runs the basic cd command and switches to whichever location is specified by the user in the second argument.
 * This methode uses chdir() to change locations.
 * 
 * @param words is the array of words that the user input into the command line
 * @param count is how many words are present in the words array
 */
void runCd( char *words[], int count )
{
    int result = chdir(words[1]);
    // Handling necessary error checking like making sure the command is 2 arguments and that the chdir didn't return an error
    if (count != 2 || result == -1) {
        fprintf(stderr, "Invalid command\n");
    }

}

/**
 * This function runs any commands by the user that are more complicated than exit and cd.
 * It uses fork() to create a child and run that command on the child process.
 * 
 * @param words is the array of words that the user input into the command line
 * @param count is how many words are present in the words array
 */
void runCommand( char *words[], int count )
{
    // Putting the words from the words array into a smaller array (usefulArr)
    char *usefulArr[count + 1];
    for (int i = 0; i <= count; i++) {
        usefulArr[i] = words[i];
    }
    pid_t id = fork();
    // Checking to see if the call to fork succeed
    if ( id == -1 )
        fprintf(stderr, "Can't create child");
    // Processing the given command if the fork function created a child 
    if (id == 0) {
        execvp(words[0], words);
        fprintf(stderr, "%s%s\n", "Can't run command ", usefulArr[0]);
    } else {
        wait(NULL);
    }
}

/**
 * The main method prints stash> and asks the user to input a command
 * Depending on the command the program acts accordingly or exits.
 * If it does not exit, it reprompts the user after one command has been executed.
 * 
 * @return int the exit status of the program.
 */
int main()
{
    bool keepRunning = true;
    int commandLocation = 0;
    int wordArrSize = 0;
    // First display of stash
    printf("stash> ");
    // Keeps running unless an exit call is made
    while (keepRunning) {
        char input[WORD_SIZE];
        char *allWords[WORD_AMOUNT];
        int character = getchar();
        // Handling the situation when an empty command is passed
        if (character == EOF || character == NEW_LINE) {
            printf("stash> ");
            continue;
        }
        // Reading in the input line
        while (character != EOF && character != 0 && character != NEW_LINE) {
            input[commandLocation] = character;
            commandLocation++;
            character = getchar();
        }
        input[commandLocation] = 0;
        // Parsing the input line by putting it into the parseCommand function
        wordArrSize = parseCommand(input, allWords);
        // Checking to see what the first command line word was to see which function needs to be called
        if (strcmp(allWords[0], "exit") == 0) {
            runExit(allWords, wordArrSize);
        } else if (strcmp(allWords[0], "cd") == 0) {
            runCd(allWords, wordArrSize);
        } else {
            runCommand(allWords, wordArrSize);
        }
        // Resetting the input string
        input[0] = '\0';
        // Resetting the entire input string
        for (int i = 0; i < commandLocation; i++) {
            input[i] = 0;
        }
        // Resetting the allWords array
        for (int i = 0; i <= wordArrSize; i++) {
            allWords[i] = NULL;
        }
        // Resetting the command location back to zero
        commandLocation = 0;
        printf("stash> ");
    }
    return EXIT_SUCCESS;
}
