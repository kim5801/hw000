/**
 * Excludes a given line from an input file based on command line arguments
 * HW0 exlude.c file
 * Uses the unix system call interface and shows us how the C standard library functions
 * are similiar to the system calls of a linux system.
 * 
 * @file exclude.c
 * @author Sania Bolla (sbolla2)
 * 
 * 
 */
#include <fcntl.h>
#include <unistd.h>
/** The amount of characters in the error message given to us in the HW requirements */
#define CHAR_IN_ERROR_MSG 56
/** ASCII value for a space */
#define SPACE 32
/** ASCII value for new line charcter */
#define NEW_LINE 10
/** ASCII value for a negative */
#define NEG 45
/** ASCII value for one */
#define ONE 49
/** ASCII value for nine */
#define NINE 57
/** ASCII value for zero */
#define ZERO 48
/** Multiplier to increase the value of the decimal */
#define INCREMENT_DECIMAL 10
/** Third command from the command line arguments */
#define THIRD_COMMAND 3
/** Total command line arguments */
#define TOTAL_COMMAND_ARGS 4


/**
 * stringToInt converts an integer value that is in a string format into a decimal, so that
 * it can be evaluated as a decimal
 * 
 * @param str is the integer that's in string format
 * @return int decimal is the decimal version of the string
 */
int stringToInt(char str[])
{
    int decimal = 0;
    int pointer = 0;

    // Handling the situation where a negative number is given
    if (str[0] == NEG) {
        pointer = 1;
        while(str[pointer] == 0) {
            pointer++;
        }
        // Checks to see what the first number is. If the number is not a valid number (1-9)
        // it writes an error message to an error file.
        if (str[pointer] < ONE || str[pointer] > NINE) {
            write(STDERR_FILENO, "usage: exclude <input-file> <output-file> <line-number>\n", CHAR_IN_ERROR_MSG);
            _exit(1);
        }
        decimal = str[pointer] - ZERO;
        decimal = decimal * -1;
    } else {
        // Handles the situation if the number is a positive number
        pointer = 0;
        while(str[pointer] == 0) {
            pointer++;
        }
        // Checks to see what the first number is. If the number is not a valid number (1-9)
        // it writes an error message to an error file.
        if (str[pointer] < ONE || str[pointer] > NINE) {
            write(STDERR_FILENO, "usage: exclude <input-file> <output-file> <line-number>\n", CHAR_IN_ERROR_MSG);
            _exit(1);
        }
        decimal = str[pointer] - ZERO;
    }
    pointer++;
    int current = 0;
    // Continuously reads in numbers and adds them into the decimal value
    while (str[pointer] != 0) {
        // Coninuously checks that the user is inputing a number, which is ASCII values 48-57
        if (str[pointer] < ZERO || str[pointer] > NINE) {
            write(STDERR_FILENO, "usage: exclude <input-file> <output-file> <line-number>\n", CHAR_IN_ERROR_MSG);
            _exit(1);
        }
        current = str[pointer] - ZERO;
        decimal = decimal * INCREMENT_DECIMAL;
        decimal = decimal + current;
        pointer++;
    }
    return decimal;
}

/**
 * Using the readFile.c example that was given with exercise 0
 * 
 * @param argc is the number of command line arguments that were given
 * @param argv is the array of command line arguments
 * @return if the program was able to successfully execute
 */
int main( int argc, char *argv[] )
{
    // Opens the input file to read
    int input = open( argv[1], O_RDONLY );
    // Opens the output file to write. The flag O_TRUNC resets the file if it already exists
    int output = open( argv[2], O_CREAT | O_WRONLY | O_TRUNC, 0600);
    int intThirdArg = stringToInt(argv[THIRD_COMMAND]);

    // Taking care of all the error handling
    if (argc != TOTAL_COMMAND_ARGS || input < 0 || output < 0 || intThirdArg < 0) {
        write(STDERR_FILENO, "usage: exclude <input-file> <output-file> <line-number>\n", CHAR_IN_ERROR_MSG);
        _exit(1);
    }

    // Starting implementation of reading the words from the input file into the output file
    char curr[] = "a";
    int linePointer = 1;
    // Handling the case for when the user wants to omit the first line of the file
    if (intThirdArg == 1) {
        read(input, curr, 1);
        while (curr[0] != NEW_LINE) {
            read(input, curr, 1);
        }
        read(input, curr, 1);
        write(output, curr, 1);
        read(input, curr, 1);
        while (curr[0] != 0) {
            write(output, curr, 1);
            read(input, curr, 1);
        }
    } else {
        int newLineCount = 0;
        read(input, curr, 1);
        while (curr[0] != 0) {
            while (curr[0] != NEW_LINE && curr[0] != 0) {
                // Only writes if the linePointer is not at the line that needs to be excluded from the file.
                // If the line needs to be excluded, the characters are read in but do not get written out.
                if (linePointer != intThirdArg) {
                    write(output, curr, 1);
                }
                read(input, curr, 1);
                if (curr[0] == NEW_LINE) {
                    newLineCount = 1;
                }
            }
            // Only writing out the newLine if the line is not the one that needs to be omitted
            if (intThirdArg != linePointer && curr[0] != 0) {
                write(output, curr, 1);
            }
            linePointer++;
            read(input, curr, 1);
            if (curr[0] == NEW_LINE) {
                newLineCount = 2;
            }
            // Necessary if statement for the last line of the file. Was having an issue where new line kept
            // getting printed at the end after the words of the file had been printed.
            // With this, if there are two newlines in a row, the value of curr is changed to null so that we break
            // out of the while loop
            if (newLineCount == 2) {
                curr[0] = 0;
            }
        }
    }
    // Closing both the files that were opened in the beginning to handle memory leaks.
    close(input);
    close(output);
    return 0;
}
