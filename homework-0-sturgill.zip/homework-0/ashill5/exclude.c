#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <stdio.h>

/*
 * Method to write a string
 * @param buffer source of string
 * @param fileDescritor the location to write
 */
void printString(char *buffer, int fileDescriptor) {
  
  int length = 0;
  for (; buffer[length]; length++);

  write(fileDescriptor, buffer, length);
}

/*
 * Method to convert the string to int
 * @param buffer string to convert
 * @return -1 if invalid or number
 */
int lineNumber(char *buffer) {
  int num = 0;
  for (int i = 0; buffer[i]; i++) {
    if (buffer[i] < '0' || buffer[i] > '9') {
      return -1;
    }
    num = num * 10 + buffer[i] - '0';
  }
  return num;
}

/*
 * Main program function
 * @param argc number of command line arguments
 * @param argv pointer  to the command line arguments
 * @return 0 for successfull, 1 for failure
 */
int main (int argc, char *argv[]) {
  
  //usage message
  char *usage = "usage: exclude <input-file> <output-file> <line-number>";
  
  //invalid arguments
  if (argc != 4) {
    printString(usage, STDERR_FILENO); 
    _exit(1);
  } 

  int fdRead = open(argv[1], O_RDONLY);
  int fdWrite = open(argv[2], O_WRONLY | O_CREAT | O_TRUNC, 0600); 
  int num = lineNumber(argv[3]); 
  
  //invalid arguments
  if (argc != 4 || fdRead == -1 || fdWrite == -1 || num == -1) {
    printString(usage, STDERR_FILENO); 
    _exit(1);
  } 
  
  char buffer[65];
  int lineNum = 1;
  int count = 0;
  do {
    count = read(fdRead, buffer, 64);
    buffer[count] = '\0';
    
    for (int i = 0; buffer[i]; i++) {
      if (lineNum != num) {
        write(fdWrite, &buffer[i], 1);
      }
      if (buffer[i] == '\n') {
        lineNum++;
      }
    }
  } while (count > 0);
  
  //close file descriptors
  close(fdRead);
  close(fdWrite);
}
