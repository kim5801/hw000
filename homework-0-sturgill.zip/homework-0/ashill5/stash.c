#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>
#include <unistd.h>
#include <sys/wait.h>

// character limit for command
const int COMMAND_LIMIT = 1024;
// word limit in command
const int WORD_LIMIT = 513;

int parseCommand(char *command, char *words[]) {
  char ch;
  int len = 0, num = 0;
  bool word = 0;
  while ((ch = getchar()) != '\n' && ch != EOF && len < COMMAND_LIMIT) {
    if (ch == ' ') {
      ch = '\0';
      word = 0;
    }
    else if (word == 0) {
      num++;
      word = 1;
    }
    command[len++] = ch;
  }
  command[len] = '\0';
  
  num = 0;
  word = 0;
  for (int i = 0; i < len; i++) {
    if (command[i] == '\0') {
      word = 0;
    }
    else if (word == 0) {
      words[num++] = command + i;
      word = 1;
    }
  }
  return num;
}

void build_words(char **words, char *command, int *length) {
  int num = 0, word = 0;
  for (int i = 0; i < *length; i++) {
    if (command[i] == '\0') {
      word = 0;
    }
    else if (word == 0) {
      words[num++] = command + i;
      word = 1;
    }
  }
}

/*
 * Method to convert string to int
 * @param str string to convert
 * @param error returns error code
 * @return converted int value
 */
int myAtoi(char *str, int *error) {
  *error = 0;
  int sign = 1, i = 0, num = 0;
  if (str[0] == '-') {
    sign = -1;
    i++;
  }
  while (str[i]) {
    if (str[i] < '0' || str[i] > '9') {
      *error = 1;
      return 0;
    }
    num = num * 10 + str[i] - '0';
    i++;
  }
  return num * sign;
}

/**
 * Method to run the built-in exit command
 * @param words array of words
 * @param count number of words
 */
void runExit(char *words[], int count) {
  int error;
  int status = myAtoi(words[1], &error);
  if (error == 1 || count != 2) {
    printf("Invalid command\n");
    return;
  }
  exit(status);
}

/**
 * Method to run the built-in cd command
 * @param words array of words
 * @param count number of words
 */
void runCd(char *words[], int count) {
  if (count != 2 || chdir(words[1]) != 0) {
    printf("Invalid command\n");
    return;
  }
}

/**
 * Method to run any process command
 * @param words array of words
 * @param count number of words
 */
void runCommand(char *words[], int count) {
  
  int pid = fork();
  if (pid == -1) {
    printf("Could not create child process\n");
  }

  if (pid == 0) {
    int error = execvp(words[0], words);
    if (error == -1) {
      printf("Can't run command %s\n", words[0]);
    }
    exit(EXIT_SUCCESS);
  }
  
  int status = 0;
  wait(&status);
}

void runCommandBack(char *words[], int count) {
  
  int pid = fork();

  if (pid == 0) {
    words[count - 1] = NULL;
    int error = execvp(words[0], words);
    if (error == -1) {
      printf("Can't run command %s\n", words[0]);
    }
    exit(EXIT_SUCCESS);
  }


  printf("[%d]\n", pid);
}

void checkBackground() {
  int status = 0;
  int ans = waitpid(-1, &status, WNOHANG);
  if (ans > 0) {
    printf("[%d done]\n", ans);
  }
}

int main() {
  
  while (1) {
    printf("stash> "); 

    char command[COMMAND_LIMIT + 1];
    char *words[WORD_LIMIT + 1];

    int word_num = parseCommand(command, words);

    if (word_num == 0) {
      continue;
    }
    
    //cd
    if (strcmp(words[0], "cd") == 0) {
      runCd(words, word_num);
      continue;
    }
    //exit
    if (strcmp(words[0], "exit") == 0) {
      runExit(words, word_num);
      continue;
    }

    words[word_num] = NULL;

    //general 
    if (strcmp(words[word_num - 1], "&") != 0) {
      checkBackground();
      runCommand(words, word_num);
    } else {
      checkBackground();
      runCommandBack(words, word_num);
    }
  }
}
