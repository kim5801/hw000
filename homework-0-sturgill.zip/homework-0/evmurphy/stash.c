#include <stdio.h>
#include <stdbool.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include<sys/wait.h>
#include <assert.h>

int parseCommand( char *line, char *words[] )
{
    char word[1025];
    int numWords = 0, n = 0;
    while(sscanf(line, "%s %n", word, &n) == 1) {
        int len = strlen(word);
        words[numWords] = line;
        // printf("words[%d]: %s\n", numWords, words[numWords]);
        line += n;
        words[numWords][len] = '\0';
        numWords++;
        // printf("again words[%d]: %s\n", numWords - 1, words[numWords - 1]);
    }
    // for(int i = 0; i < numWords; i++) {
    //     printf("%d: %s\n", i, words[i]);
    // }
    return numWords;
}

void runExit( char *words[], int count )
{
    int status = 0;
    // printf("b\n");
    if(count != 2 || sscanf(words[1], " %d", &status) != 1) {
        printf("Invalid command\n");
    } else {
        _exit(status);
    }
}

void runCd( char *words[], int count )
{
    if(count != 2 || chdir(words[1]) < 0)
        printf("Invalid command\n");
        return;
}

void runCommand( char *words[], int count )
{
    if(strcmp(words[0], "cd") == 0) {
        if(count != 2) {
            printf("Invalid command\n");
            return;
        }
        runCd(words, count);
        return;
    }
    else if(strcmp(words[0], "exit") == 0) {
        if(count != 2) {
            printf("Invalid command\n");
            return;
        }
        runExit(words, count);
    } 

    int id = fork();

    if(id < 0) {
        printf("Can't run command ");
        for(int i = 0; i < count + 1; i++) {
            printf("%s ", words[i]);
        }
        printf("\n");
        _exit(1);
    }
    else if(id == 0) {
        int retVal = execvp(words[0], words);
        if(retVal < 0) {
            printf("Can't run command ");
            for(int i = 0; i < count + 1; i++) {
                printf("%s ", words[i]);
            }
            printf("\n");
            _exit(1);
        }
    }
    else {
        wait(NULL);
    }
}

int main()
{
    bool done = false;
    while(!done) { 

        char *store[1025], line[1025], val;
        int idx = 0;
        printf("stash> ");
        // scanf("%[^\n]s", line);

        while((val = fgetc(stdin)) != '\n' && val != EOF) {
            line[idx]= val;
            idx++;
        }

        line[idx] = '\0';
        if(line[0] == ' ' || line[0] == '\n')
            continue;
        
        int numWords = parseCommand(line, store);
        
        runCommand(store, numWords);
    }
}