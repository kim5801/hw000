#include <unistd.h>
#include <fcntl.h>

int main(int argc, char *argv[]) {

  //Check that there are 3 arugments.
  if (argc != 4) {
    write(STDERR_FILENO, "usage: exclude <input-file> <output-file> <line-number>. 1\n", 64);
    return 1;
  }

  //check that the last argument is a positive integer.
  if (argv[2] < 0) {
    write(STDERR_FILENO, "usage: exclude <input-file> <output-file> <line-number>. 2\n", 64);
    return 1;
  }

  // Open a file to read.
  int readFile = open( argv[1], O_RDONLY );

  // Check that the input file is valid.
  if ( readFile < 0 ) {
    write(STDERR_FILENO, "usage: exclude <input-file> <output-file> <line-number>. 3\n", 64);
    return 1;
  }

  // Create an output file to write to.
  int writeFile = open( argv[2], O_WRONLY | O_CREAT , 0600 );

  // Check that the output file is valid.
  if ( writeFile < 0 ) {
    write(STDERR_FILENO, "usage: exclude <input-file> <output-file> <line-number>. 4\n", 64);
    return 1;
  }

  // The number of the line that the user wants to skip:
  int skipLine = *argv[3] - 48;

  // The counter to keep track of which line is currently being read and printed:
  int lineCount = 1;

  // Create a buffer to hold up to 64 bytes of the input at a time.
  char buffer[ 64 ];
  // Read the first 64 bytes of the input
  int bufferSize = sizeof( buffer );
  int len = read( readFile, buffer, bufferSize );
  

  // Keep printing out the contents of the buffer as long as we successfully read something.
  while ( len > 0 ) {
    for ( int j = 0; j < len; j++ ) {
      if ((char) *(buffer + j) == (char) '\n') {
        lineCount++;
      }
      
      if (lineCount != skipLine) {
        write( writeFile, buffer + j , 1 );
      }
    }

    // Try to read up to 64 more bytes from the file.
    len = read( readFile, buffer, bufferSize );
  }
  close(readFile);
  close(writeFile);

}
