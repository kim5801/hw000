#include <unistd.h>
#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <sys/wait.h>

#define LINE_LENGTH 1024

// The array of pointers that will contain the individual words from the commands
char *words[513];


// Reads a line of up to 1024 characters and breaks it down into individual words, storing 
// pointers to the start of those words in the words array.
// Citation of help: Found function strtok() while looking for ways to break up lines into words, 
// and based some code off of examples from https://www.tutorialspoint.com/c_standard_library/c_function_strtok.htm
int parseCommand( char *line, char *words[] ) {
    // Read in a string of characters into the array of characters.
    fgets(line, LINE_LENGTH, stdin);
    const char delimiter[2] = " ";
    char *individualWords;

    // Use strtok to break the line of characters along a given delimeter
    // This should return just the first word in the line of input
    individualWords = strtok(line, delimiter);

    int wordCount = 0;
    char nullChar = '\0';

    // strtok will return null when there are no more tokens to be read from a line, so I
    // will be looping until the strtok function returns null, meaning I have read through the whole line.
    // As I loop, I add a pointer to each word I find to the words array.
    // Citation: this loop was inspired by the example of how to use strtok given on the website:
    // https://www.tutorialspoint.com/c_standard_library/c_function_strtok.htm
    while(individualWords != NULL) {
        strncat(individualWords, &nullChar, 1);
        words[wordCount] = malloc(strlen(individualWords) + 1);
        strcpy(words[wordCount], individualWords);
        individualWords = strtok(NULL, delimiter);
        wordCount++;
    }
    // this loop goes through the last word processed, and removes any newline characters.
    for(int i = 0; i < strlen(words[wordCount - 1]); i++) {
        if (words[wordCount - 1][i] == '\n') {
            words[wordCount - 1][i] = '\0';
        }
    }
    return wordCount;
}

// Runs the exit command, freeing the array of words before closing the shell program.
void runExit( char *words[], int count ) {
    int exitStatus = 0;
    if(strcmp(words[0], "exit") == 0) {
        if(count > 2) {
            exitStatus = -1;
        }
        else if(count == 1) {
            exit(0);
        }

        // atoi should return 0 if there are any alphanumeric characters outside of 0-9 in the given string, 
        // this should prevent user from inputting letters instead of numbers for the exit status.
        // Only potential problem is if the user wants to exit with a status of 0, I might look for another solution 
        // for that problem.
        exitStatus = atoi(words[1]);

        if (exitStatus != 0) {
            exit(exitStatus);
            
        }
        else {
            printf("Invalid command\n");
        }
    }
    else {
        printf("Invalid command\n");
    }
}

// Runs the built in cd command given by the user, as stored in the words array.
void runCd( char *words[], int count ) {
    int success =  chdir(words[1]);
    if(success == -1 || count > 2) {
        printf("Invalid command\n");
    }
}

// Runs a not built in command by creating a child process and having it call execvp() to run the given command.
void runCommand( char *words[], int count ) {
    pid_t pid = fork();

    if (pid == 0) {
        words[count] = NULL;
        int fail = execvp(words[0], words);
        if(fail == -1) {
            printf("Can't run command %s\n", words[0]);
            exit(1);
        }
    }
    else {
        wait(NULL);
    }
}


int main(int argc, char *argv[]) {

   
    int exitTime = 0;

    while(exitTime == 0) {
        // Array of characters that is up to 1024 characters long of user input.
        char *userInput = calloc(LINE_LENGTH, sizeof(char)); 

        // Print the prompt
        printf( "stash> " );

        int count = parseCommand(userInput, words);

        // Determine which command was given
        // Exit and cd are programmed in by me, while other external commands are passed to the runCommand function
        if (strcmp(words[0], "exit") == 0) {
            runExit(words, count);
        }
        else if (strcmp(words[0], "cd") == 0) {
            runCd(words, count);
        }
        else if (strcmp(words[0], "") == 0) {
            continue;
        }
        else {
            runCommand(words, count);
        }
        free(userInput);
    }   
    

}