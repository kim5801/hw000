#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>
#include <ctype.h>
#include <string.h>
#include <stdlib.h>
#include <stdio.h>

#define ARGNUM 4

/**
 * This function takes a user command (line) as input, breaks the line into
 * individual words, adds null termination between the words so each word is a separate string, and
 * it fills in a pointer in the words array to point to the start of each word. It returns the number
 * of words found in the given line. The words array should be at least 513 elements in length, so it
 * has room for the largest possible number of words that could fit in a 1024-character input line.
 * @param line line to parse
 * @param words pointer of an array of words to add to
 * @return number of words found
 */
int parseCommand( char *line, char *words[] ){
    char array[1024];
    int number = 0;
    while(*line != '\0'){
        array[number] = *line;
        line++;
        number++;
    }
    char c;
    number = 0;
    int count = 0;
    int whitespace = 0;
    while(1){
        c = array[number];
        if(c == '\0'){
            break;
        }
        if(isspace(c)){
            if(!whitespace){
                array[number] = '\0';
                number++;
                whitespace++;
            }
            else{
                number++;
            }
            continue;
        }
        else{
            whitespace = 0;
            words[count] = &array[number];
            count++;
            while(1){
                c = array[number];
                if(isspace(c)){
                    break;
                }
                else if (c == '\0'){
                    return count;
                }
                number++;
            }
        }
    }
    return count;
}

/**
 * This function performs the built-in exit command. The words array is the list of pointers to words
 * in the user’s command and count is the number of words in the array
 * @param words pointers to array of words
 * @param count number of words in array
 */
void runExit( char *words[], int count ){
    if(strcmp(words[0], "exit") == 0 && count == 2){
        int status = atoi(words[1]);
        exit(status);
    }
    else if(count == 0){
        //do nothing
    }
    else{
        fprintf(stderr, "%s", "Invalid command\n");
    }
}


/**
 * This function performs the built-in cd command. The parameters give the
 * words in the command entered by the user.
 * @param words pointers to array of words
 * @param count number of words in array
 */
void runCd( char *words[], int count ){
    if(strcmp(words[0], "cd") == 0 && count == 2){
        chdir(words[1]);
    }
    else if(count == 0){
        //do nothing
    }
    else{
        fprintf(stderr, "%s", "Invalid command\n");
    }


}

/**
 * This function runs a (non-built-in) command by creating a child process and having it call execvp()
 * to run the given command.
 * @param words pointers to array of words
 * @param count number of words in array
 */
void runCommand( char *words[], int count ){
    fork();
    if(execvp(words[0], words) == -1){
        fprintf(stderr, "%s", "Invalid command\n");
    }
}


int main( int argc, char *argv[] ) {
    char *cmd = malloc(sizeof(char) * 1024);
    char *words[513];
    int count = 0;
    while(1) {
        count = 0;
        printf("%s", "stash> ");

        scanf("%s", cmd);

        count = parseCommand(cmd, words);
        if (count == 0) {
            continue;
        }
        else if (strcmp(words[0], "exit") == 0) {
            runExit(words, count);
            free(cmd);
            return 0;
        }
        else if (strcmp(words[0], "cd") == 0) {
            runCd(words, count);
        }
        else{
            runCommand(words, count);
        }
    }
}
