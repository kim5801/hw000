#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>

#define ITERATIONS 50000
#define ARGNUM 4

int main( int argc, char *argv[] ) {

    if(argc != ARGNUM){
        char msg[] = "usage: exclude <input-file> <output-file> <line-number>\n";
        write(STDERR_FILENO, msg, sizeof(msg));
        _exit(1);
    }
    int fileInput = open(argv[1], O_RDONLY|O_CREAT, 0600);
    int fileOutput = open(argv[2], O_WRONLY|O_CREAT, 0600);
    if(fileInput < 0 || fileOutput < 0){
        char msg[] = "usage: exclude <input-file> <output-file> <line-number>\n";
        write(STDERR_FILENO, msg, sizeof(msg));
        _exit(1);
    }
    char argLineNum[sizeof(argv[ARGNUM - 1])];
    for(int i = 0; i < sizeof(argv[ARGNUM - 1]); i++){
        argLineNum[i] = argv[ARGNUM - 1][i];
    }
    int n = 0;
    while(argLineNum[n] != '\0'){
        n++;
    }
    if(n == 0){
        char msg[] = "usage: exclude <input-file> <output-file> <line-number>\n";
        write(STDERR_FILENO, msg, sizeof(msg));
        _exit(1);
    }

    int num = 0;
    int count = 1;
    for(int i = n - 1; i >= 0; i--){
        if(argLineNum[i] >= '0' && argLineNum[i] <= '9'){
            num += count * (argLineNum[i] - '0');
            count *= 10;
        }
        else{
            char msg[] = "usage: exclude <input-file> <output-file> <line-number>\n";
            write(STDERR_FILENO, msg, sizeof(msg));
            _exit(1);
        }
    }

    char buffer[64];
    int bytesRead = 0;
    int linesRead = 0;
    while(1){
        bytesRead = read(fileInput, buffer, sizeof(buffer));
        if(bytesRead == 0){
            break;
        }
        for(int i = 0; i < bytesRead; i++){
            if(buffer[i] == '\n'){
                linesRead++;
            }
            if(num - 1 != linesRead){
                write(fileOutput, (void * )&buffer[i], 1);
            }
        }

    }
//    if(num == 0){
//        while(c != '\n'){
//            read(fileInput, &c, 1);
//        }
//        while(1){
//            int bytesRead = read(fileInput, &c, 1);
//            if(bytesRead == 0){
//                break;
//            }
//            buffer[0] = c;
//            write(fileOutput, (void*)&buffer[0], 1);
//        }
//    }
//    else{
//        int linesRead = 0;
//        while(1){
//            int bytesRead = read(fileInput, &c, 1);
//            if(bytesRead == 0){
//                break;
//            }
//            if(c == '\n'){
//                linesRead++;
//            }
//            if(num - 1 != linesRead){
//                buffer[0] = c;
//                write(fileOutput, (void*)&buffer[0], 1);
//            }
//
//        }
//    }
  return 0;
}
