/**
 * Prints contents from one file to another, excluding a line from the output file
 * takes 3 command line arguments: inputFile, outputFile, lineNum
 * inputFile: file with text to transfer
 * outputFile: file to put text into
 * lineNum: line to exclude from output  
 *
 */
#include <unistd.h>
#include <fcntl.h>

#define READSIZE 64
#define ERRORMESSAGE "usage: exclude <input-file> <output-file> <line-number>\n"
#define ERRORMESSAGESIZE 56

/**
 * Handles output for invalid input from command line
 * Writes usage message to stderr
 */
static void invalidArguments() {
  write( STDERR_FILENO, ERRORMESSAGE, ERRORMESSAGESIZE );
  _exit( 1 );
}

/**
 * Turns given string into a positive integer
 * returns -1 if invalid char is detected
 */
static int strToInt( char str[], int size ) {
  int fint = 0;
  
  for( int i = 0; i < size; i++ ) {
    fint *= 10;
    switch( str[i] ) {
      case '1':
        fint += 1;
        break;
      case '2':
        fint += 2;
        break;
      case '3':
        fint += 3;
        break;
      case '4':
        fint += 4;
        break;
      case '5':
        fint += 5;
        break;
      case '6':
        fint += 6;
        break;
      case '7':
        fint += 7;
        break;
      case '8':
        fint += 8;
        break;
      case '9':
        fint += 9;
        break;
      case '0':
        break;
      default:
        return -1;
    }
  }
  
  return fint;
}
/**
 * Finds length of an input string by using null terminator
 */
static int findStrlen(char *input_string)
{
    int l;
    for( l = 0; input_string[l] != '\0'; l++);
    return l;
}

/**
 * Main body of exclude program
 */
int main(int argc, char *argv[]) {
  
  int lineExcluded;
  //Check validity of command line arguments
  if ( argc != 4 ) {
    invalidArguments();
  } else {
    //Construct and verify line number
    lineExcluded = strToInt( argv[3], findStrlen(argv[3]) );
    //If str did not produce a valid line call invalid args
    if (lineExcluded < 1) {
      invalidArguments();
    }
  }
  int fdIn  = open( argv[1] , O_RDONLY );
  int fdOut = open( argv[2] , O_WRONLY | O_CREAT | O_TRUNC, 0600 );
  if (fdIn < 0 || fdOut < 0) {
    invalidArguments();
  }
  
  char buffer[ READSIZE ];
  int currentLine = 1;
  
  //Read in first part of file and begin looping over input file
  int len = read( fdIn, buffer, READSIZE );
  while ( len > 0) {
    
    // loop over current buffer
    for ( int i = 0; i < len; i++ ) {
      //if we are not on the excluded line print the characters to fdOut
      if ( currentLine != lineExcluded ) {
        write( fdOut, &buffer[i], 1 );
      }
      //If current char is '\n' we are advancing a line
      if ( buffer[i] == '\n' ) {
        currentLine++;
      }
      
    }

    //Read in the next block of input
    len = read( fdIn, buffer, sizeof( buffer ) );
  }
  //Close files
  close( fdIn );
  close( fdOut );

  return 0;
}

