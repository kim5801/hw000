/**
 * simple toy assignment shell
 * implements a small shell enviroment
 */
#include <stdio.h>
#include <stdlib.h>
#include <sys/wait.h>
#include <unistd.h>
#include <ctype.h>
#include <stdbool.h>
#include <string.h>
#include <limits.h>

#define commandLineLength 1024
#define invalidCommandMessage "Invalid command\n"

/**
 * Breaks a line into its component words and adds null termination between them
 * fills in words array with pointers to word start
 * returns words found in line
 */
int parseCommand( char *line, char *words[] ) {
  int numWords = 0;
  if ( isalnum( line[ 0 ]) ) {
    words[ numWords++ ] = &( line[ 0 ] );
  }

  for ( int l = 1; line[ l ] != '\0'; l++ ) {
    if ( !isspace( line[ l ] ) && ( isspace( line[ l - 1 ] ) || line[ l - 1 ] == '\0' ) ) {
      words[ numWords++ ] = &( line[ l ] );
    } else if ( isspace( line [ l ] ) && !isspace( line[ l - 1 ] ) ) {
      line[ l ] = '\0'; 
    }
  }
  return numWords;
}

/**
 * validates that word can be turned into an integer
 */
static bool validInt( char *word ) {
  
  for ( int l = 0; word[ l ] != '\0'; l++ ) {
    if ( !isdigit( word[ l ] ) ) {
      return false;
    }
  }
  
  if ( strtol( word, NULL, 10 ) > INT_MAX || strtol( word, NULL, 10 ) < INT_MIN ) {
    return false;
  }
  
  return true;
}

/**
 * Handles exit command
 */
void runExit( char *words[], int count ) {
  if ( count != 2 || !validInt( words[ 1 ] ) ) {
    fprintf( stderr, invalidCommandMessage);
  } else {
    int code = atoi( words[ 1 ] );
    exit( code );
  }
}

/**
 * Handles cd command
 */
void runCd( char *words[], int count ) {
  if ( count != 2 || chdir( words[ 1 ] ) < 0 ) {
    fprintf( stderr, invalidCommandMessage );
  }
}

/**
 * runs a (non-built-in) command by creating a child process and having it call execvp()
 * to run the given command.
 */
void runCommand( char *words[], int count ) {
  
  int pid = fork();
  if ( pid == -1 ) {
     fprintf( stderr, "Can’t run command %s\n", words[ 0 ] );
  }
  
  words[ count ] = NULL;

  // Print out a report from that child or wait if parent
  if ( pid == 0 ) {
    if ( execvp( words[ 0 ], words ) == -1 ) {
      fprintf( stderr, "Can’t run command %s\n", words[ 0 ] );
      exit( 1 );
    }
  } else {
    wait( NULL );
  }
}

int main() {
  char commandLine[ commandLineLength + 1 ];
  char *words[ ( commandLineLength / 2 ) + 1 ];
  int count = 0;

  while ( true ) {
    printf( "stash> " );
    fgets(commandLine, commandLineLength + 1, stdin);
    count = parseCommand( commandLine, words );

    if ( count != 0 ) {
      if ( strcmp( words[ 0 ], "cd" ) == 0 ) {
        runCd( words, count );
      } else if ( strcmp( words[ 0 ], "exit" ) == 0 ) {
        runExit( words, count );
      } else {
        runCommand( words, count );
      }
    }
  }
  
}

