/**
 * @file stash.c
 * @author Sarvesh Somasundaram
 * This program is a simple toy shell 
 * 
 */
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <unistd.h> 
#include <sys/wait.h>
#include <sys/types.h>

// a function to return invalid command 
static void invalid() {
    fprintf(stdout, "%s", "Invalid command\n" );
}

// A function to parse the command and break the line into individual words
int parseCommand( char *line, char *words[] ) {
    // a count of words
    int count = 0;
    // original length of string
    int strLen = strlen(line);
    // a for loop to loop through the line and separate commands at the whitespace
    for( int i = 0; i < strLen; i++ ) {
        // if the current value is not a space and the previous value was, then start a new word
        if ( line[ i ] != ' ' && line [ i - 1 ] =='\0' ) {
            words[ count ] = &line[ i ];
            count++;
        }
        // if the current value is a space or a new line, add a null terminator in it's place
        else if ( line[ i ] == ' ' || line[ i ] == '\n') {
            line[i] = '\0';
        }
    }
    // add a null terminator to the end to use in run command
    words[ count ] = '\0';

    return count;
}

// A function to run the built-in exit command
void runExit( char *words[], int count ) {
    // check that there are two arguments
    if ( count != 2 ) {
        invalid();
    }
    else {
        // when a non-integer is parsed using atoi, the value 0 is returned
        // this checks that if the status is 0, but the actual given command is not 0, then return an error
        if( atoi( words [ 1 ] ) == 0 && words[1][0] != '0') {
            invalid();
        }
        else {
            exit(atoi( words [ 1 ] ));
        }
    }
}

// A function to run the cd command
void runCd( char *words[], int count ) {
    // check that there are two arguments
    if ( count != 2 ) {
        invalid();
    }
    // calls the chdir command with the given path and checks if it is a valid directory
    else if( chdir( words[ 1 ] ) != 0 ) {
        invalid();
    }
}

//a function to run a non built-in command 
void runCommand( char *words[], int count ) {
    // Make a child process
    pid_t id = fork();

    // Did the call to fork succeed?
    if ( id == -1 ) {
        invalid();
    }

    // Based on the return from fork, are we the parent or the child? 
    if ( id == 0 ) {
        // I'm the child, run the given command
        execvp( words[0], words );

        // If successful, we never get past the execl.
        fprintf( stdout, "%s %s\n", "Can't run command", words[0]);
    } else {
        // I'm the parent, wait for the child to finish.
        wait( NULL );
    }

}


// The main function
int main( int argc, char *argv[] ) {

    // for the user input
    char userIn[ 1024 ];

    // keep prompting until the exit command is used
    while ( 1 ) {
        printf("stash> ");
        fgets(userIn, 1024, stdin);


        //parse the input into words
        char *parsedIn[ 1024 ];
        int numWords = parseCommand( userIn, parsedIn );

        // check if the input is a cd command
        if (strcmp( parsedIn[0], "cd" ) == 0 ) {
            runCd( parsedIn, numWords );
        }
        // check if the input is an exit command
        else if ( strcmp( parsedIn[0], "exit" ) == 0 ) {
            runExit( parsedIn, numWords);
        }
        // if it is a blank command, continue and reprompt the user
        else if ( strcmp( parsedIn[0], "\n" ) == 0 ) {
            continue;
        }
        // if it is not any of the commands, try running execvp
        else {
            runCommand( parsedIn, numWords );
        }
    }

    exit(0);
}
