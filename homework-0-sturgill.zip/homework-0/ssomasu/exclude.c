#include <fcntl.h>
#include <unistd.h>
/**
 * A program that takes an input and returns an output excluding specific lines
 * Using system calls instead of the C standard library
 * 
 */

// This function is used to throw an error with a message whenever neccessary
static void usage()
{
    // The message to use in the error
    char message[] = "usage: exclude <input-file> <output-file> <line-number>\n";
    // The write system call to send the error to stderror
    write( STDERR_FILENO, message, sizeof(message) );
    // exit with a status of 1
    _exit( 1 );
}

// This function converts an input text of a number into an integer
static int convert( char* text ) {
    int num = 0;
    // for loop to increment the output number by parsing the integer manually without atoi()
    for( int i = 0; text[i] != '\0'; i++) {
        num = num * 10 + text[i] - '0';
    }
    return num;
}

// This function clears the input buffer by filling it with null terminators
// This is also useful later in the code so we can stop writing to the output file
// once a null terminator is reached
static void clearBuffer( char* buff ) {
    for( int i = 0; i < 64; i++ ) {
        buff[ i ] = '\0';
    }
}

// The main function
int main( int argc, char *argv[] ) {
    // A check to see if there are four arguments provided
    if ( argc != 4) {
        usage();
    }

    // a check to see if the line number argument is valid
    if ( convert(argv[3]) < 0 ) {
        usage();
    }

    // opening the read and write files using system calls
    int readFile = open( argv[1], O_RDONLY); // opening using read only
    // opening using the flags to write, to overwrite the file if it already exists and to create the file if it doesn't exist
    int writeFile = open( "output.txt", O_WRONLY | O_TRUNC | O_CREAT, 0600);
    // check if the files were opened properly
    if ( readFile < 0 || writeFile < 0 ) {
        usage();
    }

    char buf[64]; // create a buffer
    int lineNum = 1; // set the current line number

    // a while loop using the read system call to read the file into a buffer
    while ( read( readFile, buf, sizeof( buf ) ) > 0 ) {

        // for loop to go through the buffer and skip the line that's specified in the arguments
        for( int i = 0; buf[ i ] != '\0'; i++ ) {
            if ( buf[ i-1 ] == '\n' ) { // if a new line is reached add to the lineNum
                lineNum++;
            }
            if ( convert( argv[3]) != lineNum ) { // write all lines that are not the line number given as an argument
                write( writeFile, &buf[ i ], 1);
            }
            
        }
        // if the buffer happens to end on a new line make sure to add that to the line count
        if ( buf[63] == '\n' ) {
            lineNum++;
        }
        // clear the buffer before reading more values from the read file to it
        clearBuffer( buf );
    }

    _exit(0);

}