#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>

#define ITERATIONS 50000

int main( int argc, char *argv[] )
{
    char buffer[] = "usage: exclude <input-file> <output-file> <line-number>";
    //incorrect number of arguments
    if (argc != 4)
    {
        write(STDERR_FILENO, buffer, buffer.length );
        _exit(1);
    }
    
    int fp = open(argv[1], O_RDONLY);
    //file does not open
    if (fp == -1)
    {
        write(STDERR_FILENO, buffer, buffer.length );
        _exit(1);
    }
    
    int fpTwo = open(argv[2], O_WRONLY);
    
    if (fpTwo == -1)
    {
        write(STDERR_FILENO, buffer, buffer.length );
        _exit(1);
    }
    
    char number[] = argv[3];

    //third argument is negative
    if (number[0] == '-')
    {
        write(STDERR_FILENO, buffer, buffer.length );
        _exit(1);
    }
    
    int finalNum = 0;
    int multiply = 1;
    for (int i = number.length - 1; i >= 0; i--)
    {
        finalNum += (number[i] - '0') * multiply;
        multiply *= 10;
    }
    
    char buffer[64] = '';
    bool isExcluded = false;
    int line = 1; 
    for (int i = 0; i < ITERATIONS; i++)
    {
        if (line == finalNum)
        {
            isExcluded = true;
        }
        int charRead = read(fp, &buffer[i], 1);
        if (buffer[i] == '\n')
        {
            line++;
        }
    }
}