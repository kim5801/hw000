#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include<sys/wait.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>
#include <string.h> 

/*
 * Parses user input into words
 * @param line user input
 * @param words pointer char array
 * @return number of words read
 */
int parseCommand( char *line, char *words[] ) {
    int numWords = 0;
    int longerThanOne = 0;
    for (int i = 0; i < strlen(line); i++) {
        if (line[i] != ' ' && longerThanOne == 0) {
            words[numWords] = &line[i];
            numWords++;
            longerThanOne = 1;
        }
        else if (line[i] == ' ') {
            longerThanOne = 0;
        }
    }

    words[numWords] = '\0';

    for (int i = 0; i < numWords; i++) {
        for (int j = 0; j < strlen(words[i]); j++) {
            if (words[i][j] == ' ') {
                words[i][j] = '\0';
            }
        }
    }

    return numWords;
}

/*
 * Runs the exit command
 * @param words pointer char array
 * @param count number of words
 *
 */
void runExit( char *words[], int count ) {
    char error[] = "Invalid command\n";

    if (count != 2) {
        write(STDERR_FILENO, error, 16 );
    }
    else if {
        char * word = words[1];
        for (int i = 0; i < strlen(word); i++) {
            if (!(word[i] <= 57 && word[i] >= 48 )) {
                write(STDERR_FILENO, error, 16 );
            }
        }

        int exitVal = atoi(words[1]);

        exit(exitVal);
    }
}

/*
 * Runs the cd command
 * @param words pointer char array
 * @param count number of words
 *
 */
void runCd( char *words[], int count ) {
    char error[] = "Invalid command\n";

    if (count != 2) {
        write(STDERR_FILENO, error, 16 );
        wrong = 1;
    }
    else if {
        int returnValue = chdir(words[1]);

        if (returnValue == -1 && wrong == 0) {
            write(STDERR_FILENO, error, 16 );
        }
    }
}

/*
 * Runs the non built-in command
 * @param words pointer char array
 * @param count number of words
 *
 */
void runCommand( char *words[], int count ) {
    pid_t id = fork();
    if (id == 0) {
        if (execvp(words[0], words) < 0) {
            printf("Can't run command %s\n", words[0]);
        }
        else {
            wait(NULL);
        }
    }
    else if (id == -1) {
        printf("Can't run command %s\n", words[0]);
    }
}

/*
 * Main method that handles the user input
 * @return 0 for successful exit
 *
 */
int main(void) {
    char command[1024] = {0};
    char *ptr[513];
    char *line;

    while (1) {
        printf("\nstash> ");
        fgets(command, 1023, stdin);
        line = command;

        int words = parseCommand(line, ptr);       

        if (strcmp(ptr[0], "cd")) {
            runCd(ptr, words);
        }
        else if (strcmp(ptr[0], "exit")) {
            runExit(ptr, words);
        }
        else if (words != 0) {
            runCommand(ptr, words);
        }
    }

    free(ptr);
    free(line);

    return 0;
}