/**
    @file exclude.c
    @author Michael C. Wax (mcwax)
    Program reads the contents of a file and then copies the contents to an output file,
    excluding a line specified by a number in the input arguments.
  */

#include <fcntl.h>
#include <unistd.h>

/** User mode for opening file */
#define DEF_MODE 0600
/** Number of input arguments expected */
#define EXP_ARG 4
/** Error message for usage. */
#define ERR_USAGE "usage: exclude <input-file> <output-file> <line-number>\n"
/** Error message for failure to open file. */
#define ERR_OPEN "Cannot open file.\n"
/** Upper boundary ASCII value */
#define ASCII_UP 57
/** Lower boundary ASCII value */
#define ASCII_LOW 48
/** Hex value for new line character used in searching */
#define NEWLINE 0x0a
/** Amount of bytes to read for each pass */
#define BUF_BYTES 64

/**
    Function determines the length of a string using only system calls.
    @param string String to find the length of.
    @return Number of characters in the string.
*/
int lengthSystem( char string[] ) {
    // Establish variable to keep track of characters
    int count = 0;

    // Count characters until null, signifying end of string.
    while ( string[count] != '\0' ) {
        count++;
    }

    // Return index, plus 1
    return count + 1;
}

/**
    Function that takes in a string and implements ASCII offset to convert
    each character to an integer. Only for positive, nonzero integers.
    @param string String of a number to be converted to decimal
    @return Value of string. -1 if equal to or less than zero.
*/
int stringToInt( char string[] ) {
    // Iterate through string to take each digit and add it to value
    int value = 0, currDigit = 0, i = 0;
    while ( string[i] != '\0' ) {
        // Not a numerical digit (0-9)
        if ( string[i] < ASCII_LOW || string[i] > ASCII_UP ) {
            return -1;
        }

        currDigit = string[i] - ASCII_LOW;
        value = currDigit + ( value * 10 );

        i++;
    }

    // No '0' line, so return error. If not, return value.
    if ( value == 0 )
        return -1;
    else
        return value;
}

/**
    Main function that handles I/O and system calls. Will exit if incorrect amount of 
    input arguments or file cannot be read.
    @param argc Number of input arguments
    @param argv Array of input arguments
    @return Status of function once complete. ( 0 on failure, 1 on success )
*/
int main( int argc, char *argv[] ) {
    // Open file using passed argument for reading and writing
    int fr = open( argv[1], O_RDONLY );
    int fw = open( argv[2], O_WRONLY | O_CREAT, DEF_MODE );

    // Incorrect number of input arguments, exit.
    if ( argc != EXP_ARG ) {
        write( STDERR_FILENO, ERR_USAGE, lengthSystem(ERR_USAGE) );
        _exit( 0 );
    }
    // File could not be opened, exit. 
    if ( fr < 0 || fw < 0 ) {
        write( STDERR_FILENO, ERR_OPEN, lengthSystem(ERR_OPEN) );
        _exit( 0 );
    }

    // Line to be removed, from command line argument.
    int line = stringToInt( argv[3] );

    // Check if valid line
    if ( line < 0 ) {
        write( STDERR_FILENO, ERR_USAGE, lengthSystem(ERR_USAGE) );
        _exit( 0 );
    }

    // Buffer for reading and writing file, int value to keep track of newlines.
    char buffer[ BUF_BYTES ];
    int countnl = 0;

    // Read up to 64 bytes from file
    int length = read( fr, buffer, BUF_BYTES );

    // Read until end of file
    while ( length > 0 ) {
        for ( int i = 0; i < length; i++ ) {
            // Count newline occurences to keep track of current line
            if ( buffer[i] == NEWLINE ) {
                countnl++;
            }
            // NOT the line to be omitted, continue to write char by char
            if ( countnl != line - 1 ) {
                write( fw, buffer + i, 1 );
            }
        }

        // Read next 64 byte chunk
        length = read( fr, buffer, BUF_BYTES );
    }

    // Close files
    close( fr );
    close( fw );

    // Exit successfully.
    _exit( 1 );

}
