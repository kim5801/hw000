/**
  @file stash.c
  @author Michael C. Wax (mcwax)
  Shell program used for running trivial commands such as cd and ls. Program
  reads in user input and executes commands based on parsed input. Program
  also uses system calls to create additional running processes to execute
  commands.
*/

#include <fcntl.h>
#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>
#include <sys/types.h>
#include <sys/wait.h>

/** Character limit for command inputs. */
#define CHAR_LIM 1025
/** Length of words array. */
#define WORD_LIM 513
/** Expected args for cd and exit */
#define BASIC_ARGS 2

/**
  Function takes the command line and will separate each word in the line with null 
  terminator characters by looking at the spaces in between. The words will then be 
  stored in the words array. The function will return the number of words read from 
  the command line.
  @param line Command line inputted by user.
  @param words Array of pointers to the words found in command line.
  @return Number of words found in the command line.
*/
int parseCommand( char *line, char *words[] ) {

  // Keep track of index of line and number of words.
  int i = 0, count = 0;
  // Length of current word.
  int tempLoc = 0;

  // Account for empty command.
  if ( line[ i ] != '\n' ) {

    // Continue to read until null is reached (end of command)
    while ( line[ i ] != '\0' ) {
      if ( line[ i ] != ' ' ) {
        tempLoc = i;
        // Iterate through to end of word.
        while ( ( line[ i ] != ' ' ) && ( line[ i ] != '\0' ) ) {
          if ( line[ i + 1 ] == '\n' ) {
            line[ i + 1 ] = '\0';
          }
          i++;
        }

        // Add null char to end of word
        line[ i ] = '\0';

        // Add word, inc count.
        words[ count ] = &line[ tempLoc ];
        count++;
        i++;
      }
      // Skip extra spaces.
      else {
        i++;
      }
    } // End check for null

  }

  // Return words counted.
  return count;
}

/**
  Performs the built-in exit command.
  @param words Array of pointers to to the words found in command line.
  @param count Number of words in the array.
*/
void runExit( char *words[], int count ) {

  int status; // Exit status to be parsed from args

  // Check for correct number of args
  if ( count != BASIC_ARGS ) {
    printf( "Invalid command\n" );
  }
  // Good to continue with exit
  else {
    // Parse second argument as integer
    status = atoi( words[ 1 ] );

    // Check for error parsing integer
    if ( status == 0 && ( strcmp( words[ 1 ], "0" ) != 0 ) ) {
      printf( "Invalid command\n" );
    }
    // Else, perform exit
    else {
      exit( status );
    }
  }

}

/**
  Performs the built-in cd command.
  @param words Array of pointers to to the words found in command line.
  @param count Number of words in the array.
*/
void runCd( char *words[], int count ) {
  
  int status; // Status of chdir call 

  // Check for correct number of command arguments
  if ( count != BASIC_ARGS ) {
    printf("Invalid command\n");
  }
  // Good on number of arguments, continue.
  else {
    status = chdir( words[ 1 ] );

    // Failure to change directory, print error
    if ( status == -1 ) {
      printf("Invalid command\n");
    }
  }

}

/**
  Runs command that is NOT built-in by creating child process and having it 
  run execvp().
  @param words Array of pointers to to the words found in command line.
  @param count Number of words in the array.
*/
void runCommand( char *words[], int count ) {

  // Add null to last position of words for execvp
  words[ count ] = NULL;

  // Start child process to run command
  pid_t id = fork();

  // Check if current process is parent or child
  // Child
  if ( id == 0 ) {
    // Have child process execute command.
    if ( execvp( words[ 0 ], words ) == -1 ) {
      printf("Can't run %s\n", words[ 0 ] );
      exit( 1 ); // Exit child
    }
  }
  // Parent, wait for child to finish.
  else {
    wait( NULL );
  }

}

/**
  Main function that carries out function calls and user I/O.
  @param argc Number of input arguments.
  @param argv Array of pointers to command-line arguments 
  @return Exit status, 0 for failure, other for success.
*/
int main( int argc, char *argv[] ) {

  // Print initial prompt.
  printf("stash> ");

  // Pointer to point to command line inputted. Get first input line.
  char line[ CHAR_LIM ] = "";
  fgets( line, CHAR_LIM, stdin );

  // Variable number of command arguments.
  int args = 0;

  // Array of pointers for each word.
  char *words[ WORD_LIM ];

  // Cycle until exit is called.
  while ( true ) {

    // Parse input and store number of arguments
    args = parseCommand( line, words );

    // No arguments (empty line), ignore
    if ( args == 0 ) {
      // Do nothing
    }
    // cd command inputted.
    else if ( strcmp( words[ 0 ], "cd" ) == 0 ) {
      runCd( words, args );
    }
    // exit command
    else if ( strcmp( words[ 0 ], "exit" ) == 0 ) {
      runExit( words, args );
    }
    // Other, non-built-in command
    else {
      runCommand( words, args );
    }

    printf("stash> "); // Prompt again
    fgets( line, CHAR_LIM, stdin );
  }

  return 0;
}
