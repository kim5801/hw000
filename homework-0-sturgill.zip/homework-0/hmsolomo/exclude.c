/**
 * @file exclude.c
 * @author Helen Solomon (hmsolomo)
 * 
 */

#include <unistd.h>
#include <fcntl.h>

int main(int argc, char* argv[]) {

   //make sure command line arguments are valid
   if (argc != 4) {
      write(STDERR_FILENO, "usage: exclude <input-file> <output-file> <line-number>", 56);
      _exit(1);
   }
   char* lastArg = argv[3];
   //converting the last argument to int
   int lineNum = 0;
   for (int i = 0; lastArg[i] != '\0'; i++) {
      lineNum = lineNum * 10 + lastArg[i] - '0';
   }

   //if valid, start writing each line of input file
   //into the output, making sure to exclude the 3rd line

   char buffer[2];
   //read each char, overwriting buf and checking whenever there is 
   //a newline character
   int input = open(argv[1], O_RDONLY);
   int output = open(argv[2], O_RDWR | O_CREAT, 0644);
   if ( output < 0 ) {
      write(STDERR_FILENO, "Cannot open output file.\n", 25);
      _exit(1);
   }
   //keep track of lines and chars
   int currLine = 1;
   int charCount = 0;
   //continue reading until end of file
   while (read(input, buffer, 1) == 1) {
      //check if the char read is a newline char
      if (buffer[0] == '\n') {
         currLine++;
      }
      //keep going through chars if still on exempt line
      if (currLine == lineNum) {
         continue;
      }
      //write the current char to the output file
      write(output, &buffer[0], sizeof(buffer[0]));
      charCount++;
   }
}