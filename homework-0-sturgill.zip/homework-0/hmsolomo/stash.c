/**
 * @file stash.c
 * @author Helen Solomon (hmsolomo)
 * 
 * This program will allow users to enter commands using a prompt.
 *
 */

#include <unistd.h>
#include <fcntl.h>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>

/**
 * Takes in a string that holds the command line arguments.
 * This method will take the string and split the words by a null terminator.
 * 
 * 
 * @param line 
 * @param words 
 * @return int 
 */
int parseCommand(char* line, char* words[]) {
   //store number of words
   int numWords = 0;

   char* word;
   char res[1024] = "";
   //split line by spaces to find each argument
   word = strtok(line, " ");
   while (word != NULL) {
      //add word into the words array
      words[numWords] = (char*)malloc(sizeof(word));
      strcpy(words[numWords++], word);
      //add word into result array with null terminator between them
      strcat(res, word);
      //get next word
      word = strtok(NULL, " ");
   }
   //set last element to NULL to serve as end marker
   words[numWords] = NULL;
   // printf("words read = %d\n", numWords);
   strcpy(line, res);
   // printf("line read = %s\n", line);
   return numWords;
}

/**
 * Executes the built-in exit command.
 * Will terminate shell with the given integer as exit status
 * If invalid input, reprompt for another command.
 * 
 * @param words list of pointers to words in the users command
 * @param count number of words in the array
 */
void runExit(char* words[], int count) {
   //check for validity
   if (count == 2) { // example -> exit 100
      int status = atoi(words[1]);
      if (status == 0) {
         write(STDERR_FILENO, "Invalid command\n", 16);
      } else {
         wait(NULL);
         exit(status);
      }
   } else {
      write(STDERR_FILENO, "Invalid command\n", 16);
   }
}

/**
 * Executes the built-in cd command.
 * The cd command expects one argument, which will be a path.
 * Will use chdir() to determine if path is valid.
 * If invalid input, reprompt for another command.
 * 
 * @param words 
 * @param count 
 */
void runCd(char* words[], int count) {
   //check for validity
   if (count == 2) { //example: cd path
      if (chdir(words[1]) < 0) {
         write(STDERR_FILENO, "Invalid command\n", 16);
      }
   } else { //not right amount of arguments
      write(STDERR_FILENO, "Invalid command\n", 16);
   }
}

/**
 * Runs a non-built-in command by creating a child process
 * and calling execvp() to run the given command
 * 
 * @param words 
 * @param count 
 */
void runCommand(char* words[], int count) {
   int pid = fork();
   //if running child, execute commands
   if (pid == 0) {
      //start child process, process arguments
      char* args[count + 1];
      for (int i = 1; i < count; i++) {
         args[i] = (char*)malloc(sizeof(words[i]));
         strcpy(args[i], words[i]);
      }
      args[count] = NULL;
      int status = execvp(words[0], args);
      //if has return of -1, execvp has failed
      if (status < 0) {
         printf("Can't run command %s\n", words[0]);
      }
   } else {
      wait(NULL);
   }
}

int main() {

   while (1) {
      write(STDIN_FILENO, "stash> ", 7);
      //holds the whole command line
      char line[1024];
      char* out = fgets(line, 1024, stdin);
      //reading from std input
      if (out != NULL) {
         //keep going through chars until new line
         if (line[strlen(line)-1] == '\n') {
            line[strlen(line)-1] = '\0';
         }
      }
      // pass this word into the command parseCommand()
      char* words[513];
      int count = parseCommand(line, words);
      if (count == 0) {
         //there was no input from user, try again
         continue;
      }
      // printf("count=%d\n", count);
      if (strcmp(words[0], "cd") == 0) {
         runCd(words, count);
      } else if (strcmp(words[0], "exit") == 0) {
         runExit(words, count);
      } else {
         runCommand(words, count);
      }
      printf("\n");
   }

   return 0;
}
