/**
  @file exclude.c
  @author Andrew W Overby (awoverby)
  Contains the main method for the exclude operation.
 */

#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>

#define EXP_ARG 4
#define ERR_LEN 56
#define BUFFER_LEN 64

 /**
  The main method of the program that writes out the input file without the given line.
  @param argc the number of arguments provided
  @param argv a list of all provided arguments
  @return the program exit status
*/
int main( int argc, char *argv[] )
{
  // Open I/O files and check for errors.
  int fr = open( argv[ 1 ], O_RDONLY, 0600 );
  if( argc != EXP_ARG || fr < 0 ) {
    write( STDERR_FILENO, "usage: exclude <input-file> <output-file> <line-number>\n", ERR_LEN );
    _exit( 1 );
  }
  int fw = open( argv[ 2 ], O_WRONLY | O_CREAT, 0600 );
  if( argc != EXP_ARG || fw < 0 ) {
    write( STDERR_FILENO, "usage: exclude <input-file> <output-file> <line-number>\n", ERR_LEN );
    _exit( 1 );
  }
  // Find the character length of the line parameter.
  int current = 0;
  char ch = argv[ 3 ][ current ];
  int len = 0;
  while( ch != '\0' ) {
    if( ch < '0' || ch > '9' ) {
      write( STDERR_FILENO, "usage: exclude <input-file> <output-file> <line-number>\n", ERR_LEN );
      _exit( 1 );
    }
    current++;
    ch = argv[ 3 ][ current ];
    len++;
  }
  // Make the line string into an int
  int line = 0;
  current = 0;
  while( len > 0 ) {
    int tens = 1;
    for( int i = 1; i < len; i++ ) {
      tens = tens * 10;
    }
    int add = ( argv[ 3 ][ current ] - '0' ) * tens;
    line += add;
    current++;
    len--;
  }
  if( line <= 0 ) {
    write( STDERR_FILENO, "usage: exclude <input-file> <output-file> <line-number>\n", ERR_LEN );
    _exit( 1 );
  }
  // Begin reading and writing the file
  char buffer[ BUFFER_LEN ];
  int readCount = read( fr, buffer, BUFFER_LEN );
  int lineCount = 1;
  while( readCount > 0 ) {
    // Loop through each character in the buffer
    for( int i = 0; i < readCount; i++ ) {
      // If the current line should be skipped, do not write
      if( lineCount != line ) {
        write( fw, &buffer[ i ], 1 );
      }
      if( buffer[ i ] == '\n' ) {
        lineCount++;
      }
    }
    readCount = read( fr, buffer, BUFFER_LEN );
  }
  // Close files and return success
  close( fr );
  close( fw );
  _exit( 0 );
}