/**
  @file exclude.c
  @author Andrew W Overby (awoverby)
  Contains the main and various other methods for the stash shell.
 */

#include <sys/types.h>
#include <sys/wait.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <ctype.h>

#define LINE_MAX 1024
#define WORDS_MAX 513

/**
  Reads a line from standard input.
  @param str the array to store the line in
  @param n the max length to store
*/
void readLine( char str[], int n )
{
  int len = 0;
  char ch = getchar();
  while( ch != EOF && ch != '\n' ) {
    if( len < n ) {
      str[ len ] = ch;
      len++;
    }
    ch = getchar();
  }
  str[ len ] = '\0';
}

/**
  Breaks a command line into words and returns the number of words found.
  @param line the command line to break up
  @param words the list of words
  @return the number of words found
*/
int parseCommand( char *line, char *words[] )
{
  int current = 0;
  int wordCount = 0;
  char ch = line[ current ];
  words[ wordCount ] = &line[ current ];
  wordCount++;
  while( ch != '\0' ) {
    if( isspace( ch ) ) {
      line[ current ] = '\0';
      words[ wordCount ] = &line[ current + 1 ];
      wordCount++;
    }
    current++;
    ch = line[ current ];
  }
  return wordCount;
}

/**
  Executes the exit command.
  @param words the array of words in the command
  @param count the number of words in the array
*/
void runExit( char *words[], int count )
{
  if( count != 2 ) {
    printf( "Invalid command\n" );
    return;
  }
  int len = strlen( words[ 1 ] );
  int status = 0;
  int current = 0;
  while( len > 0 ) {
    if( ( words[ 1 ][ current ] < '0' || words[ 1 ][ current ] > '9' ) && words[ 1 ][ current ] != '-' ) {
      printf( "Invalid command\n" );
      return;
    }
    int tens = 1;
    for( int i = 1; i < len; i++ ) {
      tens = tens * 10;
    }
    int add = ( words[ 1 ][ current ] - '0' ) * tens;
    status += add;
    current++;
    len--;
  }
  exit( status );
}

/**
  Executes the cd command.
  @param words the array of words in the command
  @param count the number of words in the array
*/
void runCd( char *words[], int count )
{
  if( count != 2 ) {
    printf( "Invalid command\n" );
    return;
  }
  int valid = chdir( words[ 1 ] );
  if( valid < 0 ) {
    printf( "Invalid command\n" );
    return;
  }
}

/**
  Executes the given command.
  @param words the array of words in the command
  @param count the number of words in the array
*/
void runCommand( char *words[], int count )
{
  int id = fork();
  if( id != 0 ) {
    wait( NULL );
  } else {
    words[ count ] = NULL;
    int valid = 0;
    valid = execvp( words[ 0 ], words );
    if( valid < 0 ) {
      printf( "Can't run command %s\n", words[ 0 ] );
    }
    exit( 0 );
  }
}

/**
  The main method of the program that runs a command shell.
  @param argc the number of arguments provided
  @param argv a list of all provided arguments
  @return the program exit status
*/
int main( int argc, char *argv[] )
{
  char line[ LINE_MAX ];
  char *words[ WORDS_MAX ];
  while( 1 ) {
    printf( "stash> " );
    readLine( line, LINE_MAX );
    if( strcmp( line, "" ) == 0 ) {
      // Reset loop
    } else {
      int count = parseCommand( line, words );
      if( strcmp( words[ 0 ], "exit" ) == 0 ) {
        runExit( words, count );
      } else if( strcmp( words[ 0 ], "cd" ) == 0 ) {
        runCd( words, count );
      } else {
        runCommand( words, count );
      }
    }
  }
}