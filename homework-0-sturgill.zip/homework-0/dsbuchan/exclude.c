/**
 * @file exclude.c
 * @author Daniel Buchanan (dsbuchan)
 * Given an input file, will exclude the given line when writing to an output file.
 */

// to use array on heap
#include <stdlib.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>

/** The argument that is the output file in the command line*/
#define OUTPUT_ARG 2
/** The argument that is the line to omit in the command line*/
#define LINE_ARG 3
/** The number of characters to read in*/
#define READ_IN 64

int main(int argc, char* argv[])
{
  // open file entered in command line to read
  int inFile = open(argv[1], O_RDONLY);
  if(inFile == -1){
    write(STDERR_FILENO, "usage: exclude <input-file> <output-file> <line-number>", 0);
    return 1;
  }
  // open file entered in command line to write 
  int outFile = open(argv[OUTPUT_ARG], O_CREAT | O_RDWR | O_TRUNC, S_IRWXU);
  if(outFile == -1){
    write(STDERR_FILENO, "usage: exclude <input-file> <output-file> <line-number>", 0);
    return 1;
  }
  // store the number to omit in command line
  int lineNum = 0;
  // convert string to int
  if(argv[LINE_ARG]){
    int digits = 0;
    char ch = argv[LINE_ARG][digits];
    while(ch >= '0' && ch <= '9'){
      lineNum *= 10;
      lineNum += ch - '0';
      digits++;
      ch = argv[LINE_ARG][digits];
    }
    // if exit character is not whitespace
    if(ch != '\0' && ch != ' ' && ch != '\n' && ch != '\t' && ch != '\v' && ch != '\r' && ch != '\f'){
      write(STDERR_FILENO, "usage: exclude <input-file> <output-file> <line-number>", 0);
      return 1; 
    }
 
  } else {
    write(STDERR_FILENO, "usage: exclude <input-file> <output-file> <line-number>", 0);
    return 1;
  }
  // read from input file 
  int bufferSize = 0;
  int bufferCapacity = READ_IN;
  char * content = (char *)malloc(bufferCapacity * sizeof(char));
  int bytesRead = 0;
  int iterate = read(inFile, content, READ_IN);
  while(iterate > 0){
    
    bytesRead += iterate;
    bufferSize += iterate;
    // resize buffer
    if(bufferSize >= bufferCapacity){
      bufferCapacity *= 2;
      char * newCont = (char *)malloc(bufferCapacity * sizeof(char));
      for(int i = 0; i < bufferSize; i++){
        newCont[i] = content[i];
      } 
      free(content);
      content = newCont;
      
    }
    iterate = read(inFile, content + bufferSize, READ_IN);
  }
  // mark end of array
  *(content + bytesRead) = '\0';

  int currLine = 0;
  size_t bytesWrite = 0;
  while(bytesWrite < bytesRead){
    // search for newline character in array, and write until that line
    size_t initial = bytesWrite;
    size_t i = bytesWrite;
    while(content[i] != '\n' && content[i] != '\0'){
      i++;
    }
    // update where iterator is
    currLine++;
    i++;
    
    // write if it is not the wrong line
    if(currLine != lineNum){
      write(outFile, content + initial, (i - bytesWrite) * sizeof(char));
    } 
    bytesWrite += i - bytesWrite;
    
  }
  
  // close all files
  close(inFile);
  close(outFile);
  return 0;
}