/**
 * @file stash.c
 * @author Daniel Buchanan (dsbuchan)
 * Shell program that reads and executes user commands.
 */
// to use array on heap
#include <stdlib.h>
// to compare strings
#include <string.h>
// for while loop
#include <stdbool.h>
#include <stdio.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <unistd.h>
/** Number of characters to read in*/
#define READ_IN 1024

int parseCommand( char *line, char *words[] );
void runExit( char *words[], int count );
void runCd( char *words[], int count );
void runCommand( char *words[], int count );

int main(int argc, char* argv[])
{
  // when shell starts, need to continusously ask user
  while(true){
    fprintf(stdout, "stash> ");
    fflush(stdout);
    char * buffer = (char *)malloc(sizeof(char) * (READ_IN + 1));
    int charRead = read(0, buffer, READ_IN);
    if(charRead <= 0){
      return 1;
    }
    // point to string with array of pointers
    char ** words = (char **)malloc(sizeof(char *) * (READ_IN / 2 + 1));
    int numWords = parseCommand(buffer, words);


    if(numWords > 0 && !strcmp("cd", words[0])){
      runCd(words, numWords);
    } else if(numWords > 0 && !strcmp("exit", words[0])){
      runExit(words, numWords);
      // check that a command was given
    } else if (numWords > 0 && words[0]){
      runCommand(words, numWords);
    } 

  }
  return 0;
}

/**
 * Breaks user command into individual words, and returns
 * the number of words given in the command
 * 
 * @param line user command
 * @param words the array containing pointers to point to words
 * @return int the number of words in the command
 */
int parseCommand( char *line, char *words[] )
{
    int numCmds = 0;
    int startCmd = 0;
    // read until the end of a line
    int i = 0;
    bool moreLine = true;
    // until end of command
    while(moreLine){
      i++;
      // if character is whitespace
      if(line[i] == ' ' || line[i] == '\n'){
        if(line[i] == '\n'){
          moreLine = false;
        }
        line[i] = '\0';
        words[numCmds] = line + startCmd;
        numCmds++;
        startCmd = i + 1;
      }
    }
    return numCmds;
}

/**
 * Performs the built-in exit command
 * 
 * @param words list of pointers to words in the user's command
 * @param count the number of words in the array
 */
void runExit( char *words[], int count )
{
  // parse integer
  // exit with that integer
  if(count != 2 ){
    printf("Invalid command\n");
  } else {
    char ch = words[1][0];
    int exitStatus = 0;
    int i = 0;
    bool isValid = true;
    while(ch != '\0'){
      exitStatus *= 10;
      if(ch < '0' || ch > '9'){
        isValid = false;
        printf("Invalid command\n");
      }
      exitStatus += ch - '0';
      i++;
      ch = words[1][i];
    }
    // will not execute if exit status entered is not an integer
    if(isValid){
      free(words[0]);
      free(words);
      exit(exitStatus);
    }
 
  }
}

/**
 * Performs the built-in cd command
 * 
 * @param words list of pointers to words in the user's command
 * @param count number of words in the array
 */
void runCd( char *words[], int count )
{
  if(count > 2){
    printf("Invalid command\n");
  } else {
    int val = chdir(words[1]);
    if (val != 0){
      printf("Invalid command\n");
    }
  }
}

/**
 * Runs a command by creating a child process, and running the given
 * command
 * 
 * @param words list of pointers to words in the user's command
 * @param count number of words in the array
 */
void runCommand( char *words[], int count )
{
  // create child process
  words[count] = NULL;
  int child = fork();
  if(child == 0){
    int retVal = execvp(words[0], words);
    if(retVal == -1){
      printf("Can't run command %s\n", words[0]);
    }
    exit(0);
  } else {
    wait(NULL);
  }
}