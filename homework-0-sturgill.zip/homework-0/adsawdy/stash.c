/** 
 * @file stash.c
 * @author Alex Sawdy (adsawdy)
 * simple toy assignment shell
 */
#include <stdio.h>
#include <stdbool.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <sys/wait.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>

/**
 * breaks the line into
 * individual words, adds null termination between the words so each word is a separate string, and
 * it fills in a pointer in the words array to point to the start of each word.
 * @param line user input
 * @param words additional command elements, at least 513 elements in length (1024-character input line)
 * @return the number of words found in the given line
 */
int parseCommand( char *line, char *words[] )
{
  int wordIdx = 0;
  bool inspace = true;
  for (char *i = line; *i; i++) {
    if (isspace(*i)) {
       if (!inspace) {
         *i = '\0';
         inspace = true;
       }
    } else {
      if (inspace) {
        words[wordIdx] = i;
        wordIdx++;
        inspace = false;
      }
    }
  }
  return wordIdx;
}

/**
 * performs the built-in exit command
 * @param words additional command elements
 * @param count number of words in array
 */
void runExit( char *words[], int count )
{
  if (count != 2) {
    printf("Invalid Command\n");
    return;
  }
  // get last command line as integer  1 2 3 '/0'
  char *ptr = words[1];
  int digitCounter = 1;
  int excludeLine = 0;
  // until null character
  while (*ptr) {
    ptr++;
  }
  // at last number
  ptr--;
  for (char* i = ptr; i >= words[1]; i--) {
    if (*i < '0' || *i > '9') {
      printf("Invalid Command\n");
      return;
    }
    excludeLine += (*i - '0') * digitCounter;
    digitCounter *= 10;
  }
  // makes sense to me
  exit(excludeLine);
}

/**
 * performs the built-in cd command
 * @param words additional command elements
 * @param count number of words in array
 */
void runCd( char *words[], int count )
{
  if (count != 2) {
    printf("Invalid Command\n");
    return;
  }
  int i = chdir(words[1]);
  if (i < 0) {
    printf("Invalid Command\n");
    return;
  }
}

/**
 * performs the built-in cd command
 * @param words all command elements
 * @param count number of words in array
 */
void runCommand( char *words[], int count )
{
  pid_t id = fork();
  
  if ( id == -1 ) {
    printf("fork failure\n");
    return;
  }
  // Based on the return from fork, are we the parent or the child?
  if ( id == 0 ) {
    int i = execvp(words[0], words);
    if (i == -1) {
      printf("Can't run command %s\n", words[0]);
    }
  } else {
    // I'm the parent, wait for the child to finish.
    wait( NULL );
  }
}

/**
 * Main method
 * @param number of arguments
 * @param string list of arguments
 * @return exit status
 */
int main( int argc, char *argv[] )
{
  int i = 0;
  
  char* words[513];
  
  // one extra char (aside null) should make certain that words larger than 5 letters?
  char line[ 1025 ];
  
  while (true) {
    memset(words, 0, 513);
    printf("stash> ");
    // grabs 1024 characters to prevent overflow
    fgets(line, 1024, stdin);
    
    i = parseCommand(line, words);
    
    /**
    for (int j = 0; j < i; j++) {
      printf("%d: %s\n", j, words[j]);
    }
    */
    
    if (!i) {
      // lol
    } else if ((strcmp(words[0], "cd")) == 0) {
      runCd(words, i);
    } else if ((strcmp(words[0], "exit")) == 0) {
      runExit(words, i);
    } else {
      runCommand(words, i);
    }
  }
  
  exit(0);
}