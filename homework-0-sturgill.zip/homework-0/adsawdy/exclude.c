/** 
 * @file exclude.c
 * @author Alex Sawdy (adsawdy)
 * Reads and writes using only system commands and excluding specific line(s)
 */
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>


/**
 * Main method
 * @param number of arguments
 * @param string list of arguments
 * @return exit status
 */
int main( int argc, char *argv[] )
{
  // check for invalid command line arguments (includes command name, unalive you C)
  if (argc != 4) {
    _exit(1);
  }
  
  // get last command line as integer  1 2 3 '/0'
  char *ptr = argv[3];
  int digitCounter = 1;
  int excludeLine = 0;
  // until null character
  while (*ptr) {
    ptr++;
  }
  // at last number
  ptr--;
  for (char* i = ptr; i >= argv[3]; i--) {
    if (*i < '0' || *i > '9') {
      // not a number
      _exit(1);
    }
    excludeLine += (*i - '0') * digitCounter;
    digitCounter *= 10;
  }

  // open file for reading w/ first command line variable
  int fdr = open(argv[1] , O_RDONLY);
  if (fdr <= 0) {
    _exit(1);
  }
  
  // open file for writing w/ second command line variable
  int fdw = open(argv[2] , O_CREAT|O_WRONLY, 0600);
  if (fdw <= 0) {
    close(fdr);
    _exit(1);
  }
  
  int currentLine = 1;
  
  int bufferSize = 64;
  char buffer[bufferSize];
  int len = read( fdr, buffer, 64 );
  
  // write byte by byte, unless during exclude line
  while (len > 0) {
    for (int i = 0; i < len; i++) {
      if (buffer[i] == '\n') {
        currentLine++;
      }
      if (currentLine != excludeLine) {
        write(fdw, &(buffer[i]), 1);
      }
    }
    
    len = read(fdr, buffer, 64);
  }
  
  close(fdr);
  close(fdw);
  _exit(0);
}