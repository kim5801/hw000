#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>
#include <stdlib.h>

int main(int argc, char *argv[]) {
    char *line = argv[3];

    //find string line length
    int count = 0;
    for (int i = 0; line[i] != '\0'; i++) {
        count++;
    }

    //convert string line to decimal number
    int place = 1;
    int num = 0;
    for (int i = count - 1; i >= 0; i--) {
        num += ((int)(line[i]) - 48) * place;
        place *= 10;
    }

    int fileD = open(argv[0], S_IRUSR);


    char *buf = (char *)malloc(64);
    int i = 2;
    int lineCount = 0;
    int startI = 0;
    int endI = 0;
    //read in file while counting and keeping track of current line
    int byteCount = read(fileD, buf, 64);
    int countB = 0;
    while (byteCount != 0) {
        while(byteCount > 0) {
            if (buf[countB] == 0x0a) {
                lineCount++;
                if (lineCount == num - 1) {
                    startI = countB + 1;
                }
                if (lineCount == num) {
                    endI = countB;
                    //break;
                }
            }
            countB++;
            byteCount--;
        }
        buf = realloc(buf, 64 * i);
        i++;
        byteCount = read(fileD, buf + (64 * i), 64);
    }
     

    //write to output file all lines except for line from argument 3
    int fileDO = open("output.txt", O_EXCL | O_CREAT | S_IRWXU, 00700);

    int currC = write(fileDO, buf, startI - 1);

    int newCount = countB - currC;
    newCount = newCount - (endI - startI);
    write(fileDO, buf + (endI + 1), newCount);
    free(buf);
    close(fileD);
    close(fileDO);
    return 0;
}