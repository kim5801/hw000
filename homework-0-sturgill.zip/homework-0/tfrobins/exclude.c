//Neccessary libraries for the system calls
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>

/**
Main exclusion program where user input excludes the given line from the output
*/
int main(int argc, char **argv)
{
    //Check to ensure user has 4 arguments
    if(argc !=4){
        write(STDERR_FILENO, "usage: exclude <input-file> <output-file> <line-number>\n", 56);
        return 1;
    }

    //if number is not a positive integer
    if(converter(argv[3]) <= 0){
        write(STDERR_FILENO, "Invalid number", 14);
        return 1;
    }

    //create the output file
    int output = open(argv[2], O_WRONLY|O_CREAT, 0600);
    //open the input file
    int input = open(argv[1], O_RDONLY|O_CREAT);

    //if output cannot be opened
    if(output < 0){
        write(STDERR_FILENO, "Can't open file", 15);
        return 1;
    }

    //create buffer to read to and write from
    char buffer[64];
    
    //counter for determining line
    int line = 1;

    //buffer that will be printed in the write
    char print[64];

    //inputs the file handler into a buffer
    //TODO: Fix while loop
    while(read(input, buffer, 64) > 0){
        //cursor to help with the skipped line offset
        int cursor = 0;

        //while buffer can be read in
        //check for a newline in the buffer
        for(int i=0; buffer[i]; i++){
            if(buffer[i] == '\n'){
                //go down the line by one
                line++;
            }
            //skip the line being written to output
            if(line == converter(argv[3])){
                continue;
            }
            //write the buffer to the printed buffer
            print[cursor] = buffer[i];
            //shift the cursor forward
            cursor++;
        }
        //write to output file;
        write(output, print, 64);
    }

    //close out the output
    close(output);
    //close the input
    close(input);
    //program success
    return 0;
}

/**
Coverter for the string number to an int
*/
int converter(char *input)
{
    //create the output integer and len counter
    int output = 0;
    int len = 0;
    //count the places in the number
    for(int i=0; input[i]; i++){
        len++;
    }
    //create a changable length int for digit position
    int place = len;
    for(int i=0; i<len; i++){
        //convert the integer
        int convert = input[i];
        convert = convert - 48;
        //check if digit is a valid number
        if(convert < 0 || convert > 9){
            //digit is not a valid number
            return -1;
        }
        //add to output given digit position
        output += (convert * ((place-1) * 10));
        if(place == 1){
            //add the ones place into output
            output += convert;
        }
        //decrease digit postition
        place--;
    }
    //returns the parsed number
    return output;
}