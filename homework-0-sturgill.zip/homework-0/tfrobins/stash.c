//Necessary Standard Libraries
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <stdbool.h>
//for exec system calls
#include <unistd.h>
#include <sys/types.h>

//Main running stach program
int main(int argc, char **argv)
{
    //the input buffer for the user line input
    char input[1024];
    //individual parsed commands
    char *commands[513];

    //will keep running until broken out of
    while(true){
        //empty the input buffer
        memset(input, '\0', sizeof(input));
        //default command line
        printf("stash> ");
        //read user input
        fgets(input, sizeof(input), stdin);
        //parse command to retreive command words
        //determine number of args
        int args = parseCommand(input, commands);
        //if the user entered an exit command
        if(strcmp(commands[0], "exit") == 0){
            //enter the runexit function
            runExit(commands, args);
            //jump to beginning
            continue;
        }
        //if the user entered a cd command
        if(strcmp(commands[0], "cd") == 0){
            //enter the cd function
            runCd(commands, args);
            //jump to beginning
            continue;
        }
        //the user entered nothing
        if(strcmp(commands[0], "") == 0){
            //jump to the beginning
            continue;
        }
        runCommand(commands, args);
    }
    return 0;
}

//function for parsing commands and putting them into words with the number of words found
int parseCommand(char *line, char *words[])
{
    //variable to count the number of words found
    int found = 0;

    //marker for the beginning or a word
    int start = 0;

    //look for each whitespace in the line
    for(int i=0; line[i]; i++){
        if(line[i] == ' '){
            //found the end of a word
            if(line[i+1] != ' ')
            //replace whitespace with null terminator
            line[i] = '\0';
            //put line segment into a word element
            words[found] = line + start;
            //move start marker forward
            start = i + 1;
            //make sure user didn't enter multiple spaces
            found++;
            //jump to next char in line
            continue;
        }
        //special case for end of line if needed
        if(line[i] == '\0'){
            //put the final word into the words array
            //offset from starting cursor
            words[found] = line + start;
            //final word in the line
            found++;
        }
        //if last char is a newline instead of null terminated
        else if(line[i] == '\n'){
            //set the newline to a null terminator
            line[i] = '\0';
            //put final word into words array
            //offset from start cursor
            words[found] = line + start;
            //increment one more word
            found++;
        }
    }
    //add a NULL to the last element in words
    words[found] = NULL;
    //return number of found words
    return found;
}

//performs the exit command
void runExit(char *words[], int count)
{
    //ensure valid number or arguments
    if(count != 2){
        printf("Invalid command\n");
    }
    else{
        //make sure the second arg is numbers
        if(atoi(words[1]) == 0 && strcmp(words[1], "0") != 0){
            printf("Invalid command\n");
        }
        else{
            //convert char to int
            int rtn = atoi(words[1]);
            //exit with given code
            exit(rtn);
        }
    }
}

//runs the change directory command
void runCd(char *words[], int count)
{
    //count number of arguments
    if(count != 2){
        printf("Invalid command\n");
    }
    else{
        //perform executive action
        chdir(words[1]);
    }
}

//creates a child proccess to run the given command
void runCommand(char *words[], int count)
{
    //create a child process
    pid_t id = fork();
    if(id == 0){
        //child process is running
        //execute command from user
        execvp(words[0], words);
        //execvp failed
        printf("Can't run command %s\n", words);
        //kill child process
        exit(0);
    }
    else{
        //parent process running
        //allow child command to run
        wait(NULL);
    }
}