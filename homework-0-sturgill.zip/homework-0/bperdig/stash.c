#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <stdbool.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>

#define MAX_COMMAND 1024
#define MAX_WORD 513
#define ERR_CHILD_SIZE 30
#define DECIMAL_PLACE_SHIFT 10

int parseCommand(char *line, char *words[])
{
    int count = 1;
    int max = strlen(line);

    if (line[0] == '\n')
        return 0;

    words[0] = line;

    for (int i = 0; i < max; i++) {
        if (line[i] == ' ') {
            line[i] = '\0';
            words[count] = line + i + 1;
            count++;
        }
    }

    words[count - 1][strlen(words[count - 1]) - 1] = '\0';
    words[count] = NULL;

    return count;
}


void runExit(char *words[], int count)
{
    if (count != 2)
        printf("Invalid command\n");

    else {
        int status = 0;
        bool invalid = false;
        for (int i = 0; (i < strlen(words[1])) && !invalid; i++) {
            if (words[1][i] < '0' || words[1][i] > '9')
                invalid = true;

            else {
                status *= DECIMAL_PLACE_SHIFT;
                status += words[1][i] - '0';
            }
        }

        if (invalid)
            printf("Invalid command\n");

        else {
            exit(status);
        }
    }
}


void runCd(char *words[], int count)
{
    if (count != 2 || chdir(words[1]) < 0)
        printf("Invalid command\n");
}


void runCommand(char *words[], int count)
{
    if (strcmp(words[0], "exit") == 0)
        runExit(words, count);

    else if (strcmp(words[0], "cd") == 0) {
        runCd(words, count);
    }

    else {
        if (count != 0) {
            int id = fork();

            if (id < 0) {
                write(2, "Error: Could not create child.", ERR_CHILD_SIZE);
                exit(1);
            }

            else if (id == 0) {
                //Later change this to support external commands with execvp
                if (execvp(words[0], words) == -1) {
                    printf("Can’t run command %s\n", words[0]);
                    exit(0);
                }
                exit(0);
            }
            else {
                wait(NULL);
            }
        }
    }
}


int main(int argc, char const *argv[]) {

    char *words[MAX_WORD];
    char command[MAX_COMMAND];
    int count;

    while (true) {
        write(STDOUT_FILENO, "stash> ", 7);
        fgets(command, MAX_COMMAND, stdin);
        count = parseCommand(command, words);
        runCommand(words, count);
    }
    return 0;
}
