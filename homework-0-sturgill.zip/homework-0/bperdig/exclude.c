#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>

#define MAX_SIZE 64
#define MIN_ARGS 4
#define LINE_NUMBER 3
#define USAGE_ERROR_SIZE 56
#define DECIMAL_PLACE_SHIFT 10

void print_error()
{
    write(2, "usage: exclude <input-file> <output-file> <line-number>\n", USAGE_ERROR_SIZE);
    _exit(1);
}

int main(int argc, char const *argv[])
{

    if (argc != MIN_ARGS) {
        print_error();
    }

    int input = open(argv[1], O_RDONLY);
    if (input < 0)
        print_error();

    int output = open(argv[2], O_WRONLY | O_CREAT | O_TRUNC, 0600);
    if (output == -1) {
        close(input);
        print_error();
    }

    int target = 0;
    int count = 0;

    while (argv[LINE_NUMBER][count] != '\0') {
        if (argv[LINE_NUMBER][count] < '0' || argv[LINE_NUMBER][count] > '9')
            print_error();
        target *= DECIMAL_PLACE_SHIFT;
        target += argv[LINE_NUMBER][count] - '0';
        count++;
    }

    unsigned char buffer[MAX_SIZE];
    unsigned char out[MAX_SIZE];
    size_t bufferSize = 0;
    size_t outSize = 0;
    int lineCount = 1;
    _Bool skip = 0;

    while (bufferSize = read(input, buffer, MAX_SIZE), bufferSize > 0) {

        count = 0;
        outSize = 0;

        for (int i = 0; i < bufferSize; i++) {
            if (lineCount == target) {

                skip = 1;

                while (buffer[i] != '\n' && i < bufferSize)
                    i++;

                if (i < bufferSize && buffer[i] == '\n') {
                    i++;
                    lineCount++;
                    skip = 0;
                }
            }

            if (!skip) {
                if (buffer[i] == '\n')
                    lineCount++;

                out[count] = buffer[i];
                outSize++;
                count++;
            }
        }

        write(output, out, outSize);

    }
    close(input);
    close(output);
    return 0;
}
