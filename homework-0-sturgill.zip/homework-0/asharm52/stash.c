/**
 * @file stash.c
 * @author Arul Sharma (asharm52)
 * This program simulates a shell using system calls
 */

#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <stdbool.h>
#include <unistd.h> 
#include <sys/types.h> 
#include<sys/wait.h>

/**
 * this function takes a user input and parses it with null terminators
 * @param line user input
 * @param words an array of pointers
 * @return number of words in input
 */
int parseCommand( char *line, char *words[] ) {
    bool spaces = true;
    int wordCounter = 0;
    int len = strlen(line);
    for (int i = 0; i < len; i++) {
        //printf("%c\n", line[i]);
        if (line[i] != ' ' && spaces == true) {
            spaces = false;
            words[wordCounter] = &line[i];
            wordCounter++;
        }
        if (line[i] == ' ') {
            spaces = true;
            line[i] = '\0';
        }
        if (line[i] == '\n') {
            line[i] = '\0';
        }
    }
    line[strlen(line)] = '\0';

    return wordCounter;
}

/**
 * this function exits the program using the exit status given by the user
 * @param count the number of words in the command given by the user
 * @param words an array of pointers
 */
void runExit( char *words[], int count ) {
    if (count != 2 ) {
        fprintf(stdout, "%s", "Invalid command\n");
    } else {
        int number = atoi(words[1]);
        if (words[1][0] != '0' && number == 0) {
            fprintf(stdout, "%s", "Invalid command\n"); 
        } else {
            exit(number);
        }
    }

}

/**
 * this function runs the cd command by changing directory to what the user commands
 * @param count the number of words in the command given by the user
 * @param words an array of pointers
 */
void runCd( char *words[], int count ) {
    if (count != 2 ) {
        fprintf(stdout, "%s", "Invalid command\n");
    } else {
        int ret = chdir(words[1]);
        //printf("%s\n", getcwd(s, 100));
        if (ret != 0) {
            fprintf(stdout, "%s", "Invalid command\n"); 
        }
    }

}

/**
 * this function runs any other commands other than cd and exit
 * uses forks and execvp to run commands
 * @param count the number of words in the command given by the user
 * @param words an array of pointers
 * @return number of words in input
 */
void runCommand( char *words[], int count ) {
    words[count] = NULL;
    pid_t pid = fork();

    if ( pid == -1 ) {
        fprintf(stdout, "%s", "Invalid command\n"); 
    }

    if (pid == 0) {
        if (execvp(words[0], words) == -1) {
            
            fprintf(stdout, "%s %s\n", "Can’t run command", words[0]); 
        }
        exit(0);
    } else {
        wait(NULL);
    }
}

/**
 * this main function reads user inputs and sends them to the appropriate function to get processed
 * constantly asks the user for a command until exit is called
 * @return int exit status
 */
int main()
{

    while(1) {
        char input[1024];
        char *words[1024];
        printf("stash> ");
        fgets(input, 1024, stdin);

        if (strcmp(input, "\n") != 0) {

            int commands  = parseCommand(input, words);

            if (strcmp(words[0], "cd") == 0) {
                runCd(words, commands);
            } else if (strcmp(words[0], "exit") == 0) {
                runExit(words, commands);
            } else {
                runCommand(words, commands);
            }


            for (int i = 0; i < 1024; i++) {
                input[i] = '\0';
                words[i] = NULL;
            }
        }
    }
}