/**
 * @file exclude.c
 * @author Arul Sharma (asharm52)
 * This program reads input from a file and outputs to a file
 * a user can specify a certain line to be skipped when printing to a file
 */

#include <unistd.h>
#include <fcntl.h>
#include <stdbool.h>

/**
 * this function takes a string and converts it to an int
 * used to convert the line number given by the user into an int
 * @param arg the string of the line number given by the user
 * @return int stirng converted to int
 */
static int convertToInt(char* arg) {
    int final = 0;

    for (int i = 0; arg[i] != '\0'; ++i) {
        final *= 10;
        final += arg[i] - '0';
    }

    return final;
}

/**
 * this main function reads text from a file and outputs it to another file
 * if the user specifies a line to be skipped when outputting, then that line is skipped
 * @param argc the number of arguments given when the program is initially run
 * @param argv pointer to an array of all the arguments that were given by the user when running the program
 * @return int exit status
 */
int main(int argc, char *argv[]) {

    // making sure correct number of arguments were given
    if (argc < 4 || argc > 4) {
        write(STDERR_FILENO, "usage: exclude <input-file> <output-file> <line-number>\n", 56);
        _exit(1);
    }

    // convert line number to int
    int line = convertToInt(argv[3]);

    if (line < 0) {
        write(STDERR_FILENO, "usage: exclude <input-file> <output-file> <line-number>\n", 56);
        _exit(1);
    }

    // opening input and output file and making sure they are valid
    int inputFile = open( argv[1], O_RDONLY);
    int outputFile = open( argv[2], O_WRONLY | O_CREAT | O_TRUNC, 0600);
    if (inputFile < 0 || outputFile < 0) {
        write(STDERR_FILENO, "usage: exclude <input-file> <output-file> <line-number>\n", 56);
        _exit(1);
    }

    int lineCounter = 1;
    bool boole = false;
    char buffer[64];
    // this while loop interates and prints chars to an output file until a null terminator is met, at which it quits iterating and stops printing
    while(1) {
        read(inputFile, buffer, 64);
        //interating through every char in the buffer
        for (int i = 0; i < 64; i++) {
            // if a null terminator is met, go to the end of the program
            if (buffer[i] == '\0') {
                goto done;
            }
            // if a newline is met, increase the line counter to tell the program what line we are currently printing to
            if (buffer[i] == '\n') {
                lineCounter++;
                if (lineCounter == 2) {
                    boole = true;
                } else {
                    boole = false;
                }
            }
            //as long as the current line is not equal to the line to skip specified by the user, then print chars out
            if (line != lineCounter) {
                if (boole && line == 1) {
                    if (buffer[i] != '\n') {
                        write(outputFile, &buffer[i], 1);
                    }
                } else {
                    write(outputFile, &buffer[i], 1);
                }
            }
        }
        //reset the buffer
        for (int i = 0; i < 64; i++) {
            buffer[i] = '\0';
        }
    }
// the program jumps here when a null terminator is met
done:
    _exit(0);
}