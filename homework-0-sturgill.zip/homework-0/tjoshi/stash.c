/**
 * 
 * This program reads in command line arguments and executes them
 * 
 * @file exclude.c
 * @author Tej Joshi (tjoshi@ncsu.com)
 * 
 */
#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
#include <sys/wait.h>
#include <sys/types.h>
#include <string.h>
#include <stdbool.h>
#include <fcntl.h>
#include <unistd.h>

#define MAXWORDLEN 1024
#define MAXWORDS 513


/**
 * This function takes a user command (line) as input. As described above it breaks the line into
 * individual words, adds null termination between the words so each word is a separate string, and
 * it fills in a pointer in the words array to point to the start of each word. It returns the number
 * of words found in the given line. The words array should be at least 513 elements in length, so it
 * has room for the largest possible number of words that could fit in a 1024-character input line.
 * 
 * @param line the line input
 * @param words the words that are put in
 * @return int the number of words
 */
int parseCommand( char *line, char *words[] ) {
    if (strlen(line) == 0) {
        return 0;
    }
    int count = 1;
    int wordCharCount = 0;
    char word[MAXWORDS][MAXWORDLEN];
    // the character array wasn't clearing from the last commandso had to clear it manually.
    for (int i = 0; i < 513; i++) {
        for (int j = 0; j < 1024; j++) {
            word[i][j] = 0;
        }
    }
    int start = 0;
    // skips over front whitespace
    while (line[start] == ' ') {
        start++;
    }
    int consecutiveSpaceCount = 0;
    for(int i = start; i < strlen(line); i++) {
        //checks for space
        if (line[i] == ' ') {
            consecutiveSpaceCount++;
            // continues if there are more than 1 space back to back
            if (consecutiveSpaceCount > 1) {
                continue;
            }
            // does normal action for space handling
            word[count - 1][wordCharCount] = '\0';
            count++;
            wordCharCount = 0;
            continue;
        }
        // code when there isn't a space
        else {
            consecutiveSpaceCount = 0;
            word[count - 1][wordCharCount] = line[i];
            wordCharCount++;
        }
    }
    word[count - 1][wordCharCount] = '\0';
    // if there isn't any letters in the first string of the array, the count is 0
    if (strlen(word[0]) == 0) {
        count = 0;
    }
    // initialized words array skipping over any empty strings in the array
    for (int i = 0; i < count; i++) {
        if (word[i][0] == 0) {
            count--;
            continue;
        }
        words[i] = word[i];
    }
    words[count] = NULL;
    return count;
}


/**
 * This function performs the built-in exit command. The words array is the list of pointers to words\
 * in the user’s command and count is the number of words in the array.

 * 
 * @param words the character array of the line input
 * @param count number of words in the array
 */
void runExit( char *words[], int count ) {
    if (count != 2) {
        fprintf(stderr, "Invalid command\n");
    } else {
        int status;
        int matches = sscanf(words[1], "%d", &status);
        if (matches != 1) {
            fprintf(stderr, "Invalid command\n");
        } else {
            exit(status);
        }
    }
}


/**
 * This function performs the built-in cd command. As with runExit(), the parameters give the
 * words in the command entered by the user.
 * 
 * @param words 
 * @param count 
 */
void runCd( char *words[], int count ) {
    int status = chdir(words[1]);
    if (status < 0) {
        fprintf(stderr, "Invalid command\n");
    }
}

/**
 * This function runs a (non-built-in) command by creating a child process and having it call execvp()
 * to run the given command.
 * 
 * Used the following code to help implement this method https://pages.github.ncsu.edu/engr-csc246-staff/web/sample/chapter01/forkExecWait.c
 * 
 * @param words 
 * @param count 
 */
void runCommand( char *words[], int count ) {
    char *argStrings[count + 1];
    for (int i = 0; i <= count; i++) {
        argStrings[i] = words[i];
    }
    // initializing child process
    pid_t id = fork();
    // if child process fails
    if ( id == -1 ) {
        fprintf( stderr, "Can't create child");
        exit(1);
    }
    // when child process is in the front of the queue, then execute
    if ( id == 0 ) {
        execvp(words[0], argStrings);
        fprintf(stderr, "Can’t run command %s\n", words[0]);
    } else {
        wait(NULL);
    }
}

int main() {
    int running = 0;
    // main while loop where decision structure is 
    while (running == 0) {
        char line[MAXWORDLEN] = "";
        char *words[MAXWORDS];
        printf("stash> ");
        char character = getchar();
        int lineCount = 0;
        // gets the line from user input and puts it into a string
        while (character != EOF && character != '\n') {
            line[lineCount] = character;
            character = getchar();
            lineCount++;
        }
        line[lineCount] = '\0';
        int count = parseCommand(line, words);
        // if count is 0 then skip
        if (count == 0) {
            continue;
        }
        // if first element is cd, execute runCd
        if (strcmp(words[0], "cd") == 0) {
            runCd(words, count);
        }
        // if first element is exit, execute runExit
        else if(strcmp(words[0], "exit") == 0) {
            runExit(words, count);
        }
        // if its not exit and not cd, then run runCommand
        else {
            runCommand(words, count);
        }
    }
    return EXIT_SUCCESS;
    

}



