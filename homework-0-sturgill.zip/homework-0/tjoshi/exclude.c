/**
 * 
 * This program uses unix commands to read from a file and exclude
 * certain lines based on command line prompts
 * 
 * @file exclude.c
 * @author Tej Joshi (tjoshi@ncsu.com)
 * 
 */
#include <fcntl.h>
#include <unistd.h>
//number of characters in the error message from args
#define ERRORMESSAGEIO 56
//number of characters in error message if the last argument isn't a number
#define ERRORMESSAGENUM 26
//the base of the number we are converting
#define DECIMAL 10
/**
 * If a string is an integer, it converts the string to an integer. Otherwise it writes an error message to terminal/errorfile
 * 
 * @param input the character array that contains the number
 * @return int the number
 */
int atoi(char input[]) {
    // the counter for index in the while loop of input
    int i = 0;
    //the output number
    int number = 0;
    // if first value is negative, switch the value to negative one so we can multiply that value at the end to convert the value to a negative number
    while (input[i] != '\0') {
        if (input[i] < '0' || input[i] > '9') {
            //error message if the string contains any non integers and exits
            write(STDERR_FILENO, "usage: exclude <input-file> <output-file> <line-number>\n", ERRORMESSAGEIO);
            _exit(1);
        }
        //operation to add the consecutive digits of the number (first part multiplies the existing number by 10 to clear a space in the ones space)
        // second part converts the input number into an ascii value and adds it to the existing number (filling the number in the ones place)
        number = number * DECIMAL + (input[i] - '0');
        i++;
    }
    return number;
}



/**
 * This main function takes the input file, output file, and line number needed to be deleted and prints all of the lines from input into output 
 * without the excluded line number defined in the arguments
 * 
 * @param argc number of arguments
 * @param args array of arguments passed in
 * @return int the exit status
 */
int main (int argc, char *argv[]) {
    //error checking if number of args
    if (argc != 4) {
        write(STDERR_FILENO, "usage: exclude <input-file> <output-file> <line-number>\n", ERRORMESSAGEIO);
        _exit(1);
    }
    int in = open( argv[1], O_RDONLY );
    //These flags were found off of the man pages for the open function in linux manual
    // the O_TRUNC opens an existing file and if it contains content, it truncates the file length to 0, effectively clearing the file
    int out = open(argv[2], O_CREAT | O_WRONLY | O_TRUNC, 0600);
    int line = atoi(argv[3]);
    // error checking if all files successfully open and last parameter is a positive number
    if (in < 0 || out < 0 ) {
        write(STDERR_FILENO, "usage: exclude <input-file> <output-file> <line-number>\n", ERRORMESSAGEIO);
        _exit(1);
    }
    char inputChar = ' ';
    int lineNumber = 1;
    int notLine = 0;
    int tooManyNewLine = 0;
    // reads in one character of the file at a time using a character variable
    read(in, &inputChar, 1);
    // while loop to read in each character
    while (inputChar != '\0') {
        // checks if the input char is a new line so it can increment the lineCount and check if the current line is the next line
        if (inputChar == '\n') {
            lineNumber++;
            // this variable is used to check if there are 2 consecutive new line characters back to back
            tooManyNewLine = 1;
            if (lineNumber == line) {
                notLine = 1;
            }
            else {
                notLine = 0;
            }
        }
        else {
            //updates if there isn't a new line
            tooManyNewLine = 0;
        }
        if (notLine == 0) {
            write(out, &inputChar, 1);
        }
        read(in, &inputChar, 1);
        //checks if there isn't 2 newlines back to back, if there is, it terminates the while loop
        if (inputChar == '\n' && tooManyNewLine == 1) {
            inputChar = 0;
        }
    }
    close(in);
    close(out);
    return 0;
}