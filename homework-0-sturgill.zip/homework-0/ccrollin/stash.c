/** 
    @file stash.c
    @author Caleb Rollins (ccrollin)
    This program is an attempt at making a shell (lite) that is similar to the Linux shell.
    There are built-in commands such as cd and exit (along with handling when no command is input).
    This program delegates to the exec system call for external commands that are not within the scope
    of this program. A child process is created to execute the command and the parent waits for it to complete.
*/

#include <stdlib.h>
#include <stdio.h>
#include <stdbool.h>
#include <string.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>

/**
    This function parses the string from the command-line input and breaks it up into
    individual words/pieces that are then filled in with null-terminators to separate each word.
    An array of pointers called the words array is used to locate each word that was processed.

    @param line the entire line of command-line input that was read
    @param words the array of pointers to each individual word on the line
    @return the number of words that were read
*/
int parseCommand( char *line, char *words[] )
{
    // maintain counter for the position in the line that we are processing
    int i = 0;
    // maintain counter for the position to place the next character in the line during processing
    int j = 0;
    int countWords = 0;
    bool inWord = false;
    bool placedNullTerminator = false;

    // first iteration of processing the line to determine a starting state
    char currentChar = *( line + j );
    if ( currentChar != ' ' && currentChar != '\n' && currentChar != EOF ) {
        inWord = true;
        *( line + i ) = currentChar;
        i++;
    }
    j++;

    // until we read the end of file or a new line character, continue processing
    while ( currentChar != '\n' && currentChar != EOF ) {
        currentChar = *( line + j );

        // if the current character is not whitespace and a null-terminator was previously placed on the last iteration
        // then set the pointer in the words array to point to the beginning of a new word
        if ( placedNullTerminator && currentChar != ' ' ) {
            words[countWords] = line + i;
            placedNullTerminator = false;
        }

        // if we are currently processing a word, and we see that the next character ahead is a whitespace or end of line
        // then place a null terminator to indicate that the word is complete
        if ( inWord && ( currentChar == ' ' || currentChar == '\n' || currentChar == EOF )) {
            *( line + i ) = '\0';
            countWords++;
            i++;
            placedNullTerminator = true;
        }

        // if the current character being processed in the line is a non-whitespace character
        // then set the state that we are in a word and add the current character to the position in the line indicated by i
        if ( currentChar != ' ' ) {
            inWord = true;
            *( line + i ) = currentChar;
            i++;
        }

            // otherwise we are processing whitespace. therefore we should ignore these characters and
            // set our state variable to indicate we are no longer inside a word.
        else {
            inWord = false;
        }
        j++;
    }
    // the edge case is that the first pointer in the words array should just point to the front of line
    words[0] = line;
    return countWords;
}

/**
    This is a helper function originally used my exclude.c that is designed to convert a set of
    characters to its actual integer value for the a command-line argument. This works
    by the understanding that all the ASCII characters as just encoded integers and because
    all the ASCII digit character as one sequence you can just subtract an offset to get the
    desired integer value of the character literal. Lastly, increasing powers of ten that follow
    the string length determine the placement of each number in the various 1s, 10s, 100s, ... places.

    @param chars a reference to the set of characters to parse
    @param numChars the length of the set of characters to parse
    @return the integer value representation of the ASCII character literals
*/
static int charsToInt( char *chars, int numChars )
{
    int intValue = 0;
    for ( int i = numChars; i >= 1; i-- ) {
        if ( *chars >= '0' && *chars <= '9' ) {
            int currentDigit = ( *chars ) - 48;
            int powerOfTen = 1;
            for ( int j = 1; j <= i - 1; j++ ) {
                powerOfTen = powerOfTen * 10;
            }
            intValue = intValue + ( currentDigit * powerOfTen );
        }
        else {
            intValue = -1;
            break;
        }
        chars++;
    }
    return intValue;
}

/**
    This function handles one of our built-in commands to exit the stash.
    If the wrong number of parameters are passed to the function or the second parameter
    cannot be parsed as a number, then this will print the proper error messaged to standard output
    and reprompt.

    @param words the array of character pointers read in
    @param count the number of words that are read in
*/
void runExit( char *words[], int count )
{
    if ( count == 2 ) {
        int exitStatus = charsToInt( words[1], strlen( words[1] ));
        if ( exitStatus != -1 ) {
            exit( exitStatus );
        }
        else {
            printf( "%s", "Invalid command\n" );
        }
    }
    else {
        printf( "%s", "Invalid command\n" );
    }
}

/**
    This function handles another one of our built-in commands to change the current working directory.
    The system called named chdir() is used to facilitate this operation successfully.
    Again, if the wrong number of parameters are passed to the function or the second parameter is not a valid
    directory that can be changed into, then this will print the proper error message to standard output
    and reprompt.

    @param words the array of character pointers that holds the words processed
    @param count the number of words that were processed when read in
*/
void runCd( char *words[], int count )
{
    if ( count == 2 ) {
        int result = chdir( words[1] );
        if ( result == -1 ) {
            printf( "%s", "Invalid command\n" );
        }
    }
    else {
        printf( "%s", "Invalid command\n" );
    }
}

/**
    This function handles the case of when an external command is needed to be called. The system
    call fork() is used to create a child process that will call execvp() with the words array to execute
    the command. execvp() knows the directories in your $PATH already so there is nothing more to do with the
    words array before calling it. Once the child is finished the parent will finish as well.

    @param words the array of pointers to the words processed when reading from the terminal
    @param count the number of words that were processed
*/
void runCommand( char *words[], int count )
{
    int processID = fork();
    if ( processID != 0 ) {
        wait( NULL );
    }
    else {
        int returnVal = 0;
        returnVal = execvp( words[0], words );

        // handle the case of if execvp has issues running command
        if ( returnVal == -1 ) {
            printf( "Can't run command %s\n", words[0] );
            exit( EXIT_FAILURE );
        }
        exit( EXIT_SUCCESS );
    }
}

/**
    This is the entry-point where our stash program will being execution.
    In the code below, a rare case of a while-true loop is used with the understanding
    that when the user issues the exit command that the stash program will terminate that way.
    Otherwise, the user will continue to receive stash> prompts. This method has the logic for
    determining what functions to delegate to. Whether it be an built-in command, external, or nothing.

    @return theoretically this function is supposed to return a exit code, but the infinite loop will never
    allow the line of code to return to be reached, instead exit in other functions will end the program
*/
int main()
{
    while ( true ) {

        // the words array is length 513 to account for the max number of words that could be made with 1024 characters (512)
        // plus one more element to hold a NULL pointer required for execvp()
        char *wordsArray[513];

        // the line array is length 1026 because the max number of characters is 1024
        // plus the null terminator and the new-line character
        char line[1026];

        printf( "%s", "stash> " );
        fgets( line, 1026, stdin );
        int wordsRead = parseCommand( line, wordsArray );

        if ( strcmp( wordsArray[0], "cd" ) == 0 ) {
            runCd( wordsArray, wordsRead );
        }
        else if ( strcmp( wordsArray[0], "exit" ) == 0 ) {
            runExit( wordsArray, wordsRead );
        }
        else if ( wordsRead == 0 ) {
            continue;
        }
        else {
            wordsArray[wordsRead] = NULL;
            runCommand( wordsArray, wordsRead );
        }
    }
    return EXIT_SUCCESS;
}
