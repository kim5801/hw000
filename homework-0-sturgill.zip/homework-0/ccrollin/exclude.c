/** 
    @file exclude.c
    @author Caleb Rollins (ccrollin)
    This C program uses Unix system calls instead of the C standard library to
    read in from the user-desired text file and copy the contents of the file to
    another output file with the exception of a user-defined line of the input file
    that will be excluded from the copying process.
*/

#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>

/**
    This is a helper function that uses the fact that the strings being passed are
    all null-terminated. With this understanding, this function traverses character
    by character of the string while incrementing a counter variable until the
    null-terminator character is encountered. This exists because the typical string
    length method is from the C standard library (which is not allowed for this assignment).

    @param buffer a buffer of characters making a string to examine for its length
    @return the count of how long the string passed is
*/
static int myStringLength( char *buffer )
{
    int len = 0;
    while ( *buffer != '\0' ) {
        buffer++;
        len++;
    }
    return len;
}

/**
    This is a helper function that handles the case of when a user has incorrectly
    run the exclude program due to invalid command-line arguments being passed.
    This function when called will terminate the program after printing a usage message.
*/
static void invalidArguments()
{
    char message[] = "usage: exclude <input-file> <output-file> <line-number>\n";
    write( STDERR_FILENO, message, myStringLength( message ));
    _exit( 1 );
}

/**
    This is a helper function that is designed to convert a set of characters/string
    literal to its actual integer value for the last command-line argument. This works
    by the understanding that all the ASCII characters as just encoded integers and because
    all the ASCII digit character as one sequence you can just subtract an offset to get the
    desired integer value of the character literal. Lastly, increasing powers of ten that follow
    the string length determine the placement of each number in the various 1s, 10s, 100s, ... places.

    @param lastArg a reference to the last argument encountered in the command-line
    @param lastArgLen the length of the last argument encountered in the command-line
    @return the integer value representation of the ASCII character literals
*/
static int charsToInt( char *lastArg, int lastArgLen )
{
    int intValue = 0;
    for ( int i = lastArgLen; i >= 1; i-- ) {
        if ( *lastArg >= '0' && *lastArg <= '9' ) {
            int currentDigit = ( *lastArg ) - 48;
            int powerOfTen = 1;
            for ( int j = 1; j <= i - 1; j++ ) {
                powerOfTen = powerOfTen * 10;
            }
            intValue = intValue + ( currentDigit * powerOfTen );
        }
        else {
            invalidArguments();
        }
        lastArg++;
    }
    return intValue;
}

/**
    The entry-point for execution of the exclude program. See the in-line comments
    inside the body of this function for more information about what occurs in main.

    @param argc the count of how many command-line arguments are passed in
    @param argv the vector (array) of all the command-line arguments passed in
    @return the exit status of running the program
*/
int main( int argc, char *argv[] )
{
    // if the amount of command-line arguments is not exactly four (too few or too many), then handle invalid arguments scenario
    if ( argc != 4 ) {
        invalidArguments();
    }

    // open the file (using system call) specified with command-line argument and attempt to use it in read-only mode
    int filedescr = open( argv[1], O_RDONLY );

    // if there is an issue opening the file handle invalid arguments scenario
    if ( filedescr == -1 ) {
        invalidArguments();
    }

    // open the file (using system call) specified with command-line argument and attempt to use it in write-only mode
    // if the file does not already exist create a new file with the desired name and give it appropriate permissions
    int outputfd = open( argv[2], O_WRONLY | O_CREAT | O_TRUNC, 0600 );

    // if there is an issue opening the file handle invalid arguments scenario
    if ( outputfd == -1 ) {
        invalidArguments();
    }

    // use other helper methods to obtain the line to ignore from the command-line argument now interpreted as an integer
    int ignoreLine = charsToInt( argv[3], myStringLength( argv[3] ));

    // reading in intervals of 64 bytes according to instructions
    char currentBlock[64];

    int lineNum = 1;
    int readInNum;

    do {
        readInNum = read( filedescr, currentBlock, 64 );
        for ( int k = 0; k < readInNum; k++ ) {
            // only write to output file if the line currently being processed is not the line to skip
            if ( lineNum != ignoreLine ) {
                write( outputfd, &currentBlock[k], 1 );
            }
            // increment the counter variable for keeping up with the line number when a new-line character is encountered
            if ( currentBlock[k] == '\n' ) {
                lineNum++;
            }
        }
    }
    while ( readInNum > 0 ); // repeat until the end of file is reached

    close( outputfd );
    close( filedescr );

    return 0;
}
