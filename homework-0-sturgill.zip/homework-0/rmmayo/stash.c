#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>

/**
 * Max length of a user command
 * 
 */
#define MAX_SIZE 1024


/**
 * Converts a string to a positive integer
 * 
 * @param st a string
 * @return The result of the conversion to a positive int, or -1 if the input string has any non-number characters (including "-").
 */
static int stringToInt(const char* st){
    int ret = 0;
    for(int i = 0; st[i] != '\0'; i++){
        if(st[i] > '9' || st[i] < '0'){
            return -1;
        }
        ret = ret*10 + (st[i] - '0');

    }
    return ret;
}

/**
 * Takes a string and parses it for each word seperated by whitespace and newlines.
 * 
 * @param line The string to be parsed
 * @param words Fills this array with pointers to the begining of each word, marked at the end by a NULL pointer.
 * @return The number of words read from the line. Will return 1 if the line is a single newline character.
 */
static int parseCommand(char *line, char *words[]){
    int len = strlen(line);
    for(int i = 0; i < len; i++){
        if(line[i] == '\n' || line[i] == ' '){
            
            line[i] = '\0';
        }
    }
    int j = 0;
    words[j] = line;
    
    for(int i = 0; i < len; i++){
        if(line[i] == '\0'){
            words[++j] = line + (i + 1);
        }
    }
    words[j] = NULL;
    return j;
}


/**
 * Runs the shells exit command. If the number of args is not 2, the command is invalid
 * 
 * @param words The command and its arguments
 * @param count the number of args in the words array
 */
static void runExit(char *words[], int count) {
    if(count != 2){
        printf("Invalid Command\n");
        return;
    }
    
    int status = stringToInt(words[1]);

    if(status < 0) {
        printf("Invalid Command\n");
        return;
    }
    free(words);
    exit(status);


}

/**
 * Runs the shell's cd command. If the number of args is not 2, the command is invalid
 * 
 * @param words The command and its arguments
 * @param count the number of args in the words array
 */
static void runCd(char *words[], int count) {
    if(count > 2){
        printf("Invalid Command\n");
        return;
    }

    
    int result = chdir(words[1]);

    if(result < 0) {
        printf("Invalid Command\n");
        return;
    }
    
}

/**
 * Runs a shell command by forking a process and using the execvp system call to run any command in this systems PATH.
 * If exexcvp cannot run a command, an error message is printed
 * 
 * @param words The command and its arguments
 * @param count the number of args in the words array
 */
static void runCommand(char *words[], int count) {

    int pid = fork();

    if(pid < 0){
        printf("Invalid Command\n");
        return;
    }

    if(pid == 0){//Child
        int st = execvp(words[0], words);
        if(st < 0) {
            printf("Can’t run command %s\n", words[0]);
            exit(1);
        }
        exit(0);
    }

    else{//parent
        wait(NULL);
    }

}

/**
 * Main function of the program, handles function calls.
 * 
 * @return int 
 */
int main(void){
    
    char cmd[MAX_SIZE + 1];
    char **words = (char**)malloc(sizeof(char*) * 514);

    
    while(1){
        printf("stash> ");
        fgets(cmd, MAX_SIZE, stdin);

        int wordCount = parseCommand(cmd, words);
        
        if(strcmp(words[0], "") != 0){
            if(strcmp(words[0], "cd") == 0){
                runCd(words, wordCount);
            }
            else if(strcmp(words[0], "exit") == 0){
                runExit(words, wordCount);
            }
            
            else{
                runCommand(words, wordCount);
            }
        }
        

    }

    return 0;
}