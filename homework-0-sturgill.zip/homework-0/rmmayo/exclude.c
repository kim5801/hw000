#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>

/**
 * Function that simply prints a message to standard error and exits
 * 
 */
static void errOut(){
    char msg[] = "usage: exclude <input-file> <output-file> <line-number>\n";
    write(STDERR_FILENO, msg, 56);
    _exit(1);
}

/**
 * Converts a string to a positive integer
 * 
 * @param st a string
 * @return The result of the conversion to a positive int, or -1 if the input string has any non-number characters (including "-").
 */
static int stringToInt(const char* st){
    int ret = 0;
    for(int i = 0; st[i] != '\0'; i++){
        if(st[i] > '9' || st[i] < '0'){
            return -1;
        }
        ret = ret*10 + (st[i] - '0');

    }
    return ret;
}

/**
 * Main function, handles IO
 * 
 * @param argc number of arguments read from command line
 * @param argv array of arguments read from the command line
 * @return 0 on successful execution.
 */
int main(int argc, char *argv[]) {
    
    if(argc != 4){  
        errOut();
    }


    int fdRead = open(argv[1], O_RDONLY); //open input file
    if(fdRead < 0){  //exit if the file couldn't be opened
        errOut();
    }

    int fdWrite = open(argv[2], O_CREAT|O_APPEND|O_RDWR, 0x0700); //open output file
    if(fdWrite < 0){ //exit if the file couldn't be opened
        close(fdRead);
        errOut();
    }

    int skip = stringToInt(argv[3]); //convert the 3rd argument to a positive int

    if(skip < 0){ //exit if the number was invalid
        close(fdRead);
        close(fdWrite);
        errOut();
    }

    char buffer[10000]; //string buffer of arbituary size

    int charCount = 0; //count of characters read

    char flag = 1; //flag to track the status of read()
    int skipCount = 0; //counts line number
    char curr = 0; //currently read character
    int skipFlag = 0; //flag to mark the current line to be skipped

    while(flag == 1){ //read each character and track the number of newline characters then skip the marked line, otherwise save it to the buffer.
        flag = read(fdRead, &curr, 1);
        if(skipFlag == 0){
            buffer[charCount++] = curr;
            if (curr == '\n'){
                skipCount++;
            }

            if(skipCount == skip - 1){
                skipFlag = 1;
                skipCount++;
            }
        }
        else if(skipFlag == 1 && curr == '\n'){
            skipFlag = 0;
        }

    }
    
    for(int i = 0; i < charCount - 1; i++){ //write the contents of the buffer to the output file
        write(fdWrite, buffer + i, 1);
    }


    close(fdRead); //close open files
    close(fdWrite);

    return 0;
}