#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <ctype.h>


//code doesn't work because tokenization takes into account new line characters 
//within this method
int parseCommand(char *line, char *words[])
{
    int wordCount = 0;
    int i = 1;
    //delimit and parse into tokens by spaces
    char *cmd = strtok(line, " ");
    words[0] = cmd;
    //continue to tokenize and populate words array
    while (cmd != NULL) {
        wordCount++;
        cmd = strtok('\0', " ");
        words[i++] = cmd;
        
    }
    return wordCount;
}

void runExit(char *words[], int count)
{
    //if invalid number of commands
    if (count != 2) {
        fprintf(stdout, "Invalid command\n");
    }
    else {
        exit(atoi(words[1]));
    }
}

void runCd(char *words[], int count)
{
    // check to see if command line arg amount is accurate
    if (count != 2) {
        fprintf(stdout, "Invalid command");
    }
    // change directory with system call
    int cd = chdir(words[1]);

    // if invalid change print error
    if (cd == -1) {
        fprintf(stdout, "Invalid command");
    }
}

void runCommand(char *words[], int count) {
    //fork child from parent
    pid_t pid = fork();
    //if successful
    if (pid == 0) {
        //run command
        int exec = execvp(words[0], &words);
        //if unsuccessful
        if (exec == -1) {
            printf("%s %s", "Can't run command", words[0]);
        }
    }
    //parent waits for child to execute command
    else {
        wait();
    }
}



int main(int argc, char const *argv[]) {
    char cmd[1025];
    char *words[513];
    int tf = 1;
    int i = 0;
    //loop through and reprompt until exited
    while (tf) {
        printf("stash> ");
        char ch = getchar();

        cmd[i] = ch;
        while (ch != '\n') {
            i++;
            ch = getchar();
            cmd[i] = ch;
        }
        int count = parseCommand(cmd, words);

        //run into exit command if command matches
        if (strcmp(words[0], "exit") == 0) {
            runExit(words, count);
            tf = 0;
        }

        //run into cd command if command matches
        if (strcmp(words[0], "cd") == 0) {
            runCd(words, count);
        }
        
        //run external commands for anything else
        else {
            runCommand(words, count);
        }
    }
    exit(EXIT_SUCCESS);
}