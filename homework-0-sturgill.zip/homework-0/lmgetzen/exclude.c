#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>

/**
 * fail message
 */
static void fail( char *msg ) {
    write(STDERR_FILENO, msg, 56);
    _exit(2);
}

/**
 * converts string to integer
 */
int strToInt(const char str[])
{
    int i = 0;
    int ans = 0;
    ans = ans * 10 + ((int)str[i] - 48); 
    return ans;
}

int main(int argc, char const *argv[]) {
    int input = open(argv[1], O_RDONLY);
    int output = open(argv[2], O_WRONLY | O_CREAT | O_TRUNC, 0600);

    //error message for invalid command lines
    char msg[] = ("usage: exclude <input-file> <output-file> <line-number>\n");

    //handles invalid argument count and failure to open files
    if (argc != 4 || !input || !output) {
        fail(msg);
    }

    //handles a negative argument 4
    int arg3 = strToInt(argv[3]);
    if (arg3 < 0) {
        fail(msg);
    }
    

    

    int nLCount = 0;
    char buffer[64];
    //read 64 bytes from input into the buffer
    int len = read( input, buffer, sizeof(buffer));

    //loop until we read and write everything into the buffer and erase the line
    while (len > 0) {
        //loop through the file read
        for (int i = 0; i < len; i++) {
            if (nLCount == arg3 - 1) {
                
                //check for newlines
                if (buffer[i] == '\n' && i < len) {
                    nLCount++;
                }
               
            }
            
            
            else {
                if (buffer[i] == '\n') {
                    nLCount++;
                }
                //write to output file with characters removed one at a time
                write(output, buffer + i, 1);
            }
        }
        
        
        
        


        len = read( input, buffer, len);

    }

    
    
    close(input);
    close(output);
    return 0;
}