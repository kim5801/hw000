/**
  @file exclude.c
  @author Cade Cuddy (cjcuddy)
  This program copies text from a file
  to another, excluding a line given by
  user input.
*/
#include <unistd.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/stat.h>

#define ASCII_NUM_START '0'
#define ASCII_NUM_END '9'
#define POWER_OF_TEN 10
#define REQUIRED_ARGS 4
#define BYTE_READ_INTERVAL 64

/**
 * Closes the program with a failing status code (1).
 */
static void fail()
{
  char message[] = "usage: exclude <input-file> <output-file> <line-number>\n";
  write(STDERR_FILENO, message, sizeof(message));
  _exit(1);
}

/**
 * Converts positive string number values to integers.
 *
 * @return integer representation of string, -1 if str is negative or not an int
 */
static int myAtoi(char *str)
{
  int len = 0;
  while (*str != '\0')
  {
    if (*str < ASCII_NUM_START || *str > ASCII_NUM_END)
    {
      len = -1;
      break;
    }
    int x = *str - ASCII_NUM_START;
    len = (len * POWER_OF_TEN) + x;
    str++;
  }

  return len;
}

/**
 * Start of the program, verifies user
 * has given the appropriate args and writes
 * the new file without the excluded line.
 *
 * @return run status of program
 */
int main(int argc, char **argsv)
{
  if (argc != REQUIRED_ARGS)
  {
    fail();
  }

  // Read all the args, attempt to open the files provided by input
  int readFile = open(argsv[1], O_RDONLY);
  int writeFile = open(argsv[2], (O_WRONLY | O_CREAT | O_TRUNC), S_IRWXU);
  int excludedLine = myAtoi(argsv[3]);
  // Error checking for args
  if (readFile == -1 || writeFile == -1 || excludedLine < 1)
  {
    close(readFile);
    close(writeFile);
    fail();
  }

  char buffer[BYTE_READ_INTERVAL];
  int currentLine = 1, bytesRead = 0;
  // Read the file 64 bytes at a time
  while ((bytesRead = read(readFile, buffer, BYTE_READ_INTERVAL)) > 0)
  {
    for (int i = 0; i < bytesRead; i++)
    {
      // Skip all characters on the excluded line
      if (currentLine == excludedLine && buffer[i] != '\n')
        continue;
      else if (currentLine == excludedLine && buffer[i] == '\n')
        currentLine++;
      // Write all characters on non-excluded lines to output file
      else
      {
        write(writeFile, &buffer[i], 1);
        // Keep track of what line we're on
        if (buffer[i] == '\n')
          currentLine++;
      }
    }
  }

  close(readFile);
  close(writeFile);
  _exit(0);
}
