/**
  @file stash.c
  @author Cade Cuddy (cjcuddy)
  This program is a tiny shell that's
  able to execute most UNIX commands, as well
  as some onboard ones.
*/
#include <stdlib.h>
#include <stdio.h>
#include <stdbool.h>
#include <unistd.h>
#include <fcntl.h>
#include <string.h>
#include <sys/types.h>
#include <sys/wait.h>

#define LINE_BUFFER_MAX 1024
#define MAX_WORDS 513
#define POWER_OF_TEN 10
#define ASCII_NUM_START '0'
#define ASCII_NUM_END '9'

// Lets the user know they're wrong
static void invalidCommand()
{
  char message[] = "Invalid command\n";
  write(STDOUT_FILENO, message, sizeof(message));
}

// Converts positive string number values to integers.
// Same atoi I wrote in exclude.c
static int myAtoi(char *str)
{
  int atoi = 0;
  while (*str != '\0')
  {
    if (*str < ASCII_NUM_START || *str > ASCII_NUM_END)
    {
      atoi = -1;
      break;
    }
    int x = *str - ASCII_NUM_START;
    atoi = (atoi * POWER_OF_TEN) + x;
    str++;
  }

  return atoi;
}

/**
 * Terminates the calling process (the program) with a status code. Ensures
 * that the user has input a status code, converts it to an integer with a
 * atoi helper.
 *
 * @param words array of user inputted words, with the first being the desired command
 * @param count number of words from user input (command included)
 */
void runExit(char *words[], int count)
{
  if (count != 2)
  {
    invalidCommand();
    return;
  }
  int status = myAtoi(words[1]);
  if (status == -1)
  {
    invalidCommand();
    return;
  }
  _exit(status);
}

/**
 * Changes the directory to the specific path arg. This command expects exactly 1
 * path argument, and if it's invalid or missing the user will be notified.
 *
 * @param words array of user inputted words, with the first being the desired command
 * @param count number of words from user input (command included)
 */
void runCd(char *words[], int count)
{
  if (count != 2)
  {
    invalidCommand();
    return;
  }
  int status = chdir(words[1]);
  if (status == -1)
  {
    invalidCommand();
    return;
  }
}

/**
 * Runs external commands as separate programs. A child process is created, and the
 * command (first word in user input) is called with as many or as few args input by
 * the user. Errors are reported.
 *
 * @param words array of user inputted words, with the first being the desired command
 * @param count number of words from user input (command included)
 */
void runCommand(char *words[], int count)
{
  int pid = fork();
  if (pid == 0)
  {
    // Attempt to execute command
    execvp(words[0], words);
    // If command not able to run, let 'em know
    char messageHeader[] = "Can't run command ";
    write(STDERR_FILENO, messageHeader, sizeof(messageHeader));
    write(STDERR_FILENO, words[0], strlen(words[0]));
    write(STDERR_FILENO, "\n", 1);
    exit(1);
  }
  else
  {
    wait(NULL);
  }
}

/**
 * Parses the user input string for words. When a word
 * is found, a pointer entry is added to the 'words' array
 * pointing the word's first character. Once the end of a word is reached,
 * a null terminator is added. This is repeated until the end of the line.
 *
 * @param line user input from shell
 * @param words array of pointers that'll point to each word in line
 * @return number of words parsed from user input, including command + args
 */
int parseCommand(char *line, char *words[])
{
  int wordCount = 0;
  while (*line != '\0' && *line != '\n')
  {
    // Non-whitespace, start of a word found
    if (*line != ' ')
    {
      // New entry pointing to start of word
      words[wordCount++] = &(*line);
      // Skip through word until whitespace (end of word) reached
      while (*line != ' ' && *line != '\0' && *line != '\n')
      {
        line++;
      }
      // Set end of word null terminator
      *line = '\0';
    }
    line++;
  }
  // Add null pointer for execvp
  words[wordCount + 1] = NULL;

  return wordCount;
}

/**
 * Main loop for the shell. Will prompt
 * user for commands until exit command is given.
 *
 * @return run status of program
 */
int main()
{
  char shellPrompt[] = "stash> ";
  while (true)
  {
    char lineBuffer[LINE_BUFFER_MAX];
    memset(lineBuffer, '\0', LINE_BUFFER_MAX);
    write(STDOUT_FILENO, shellPrompt, sizeof(shellPrompt));
    read(STDIN_FILENO, lineBuffer, LINE_BUFFER_MAX);

    char *parsedWords[MAX_WORDS];
    memset(parsedWords, '\0', MAX_WORDS);
    int wordCount = parseCommand(lineBuffer, parsedWords);
    char *command = parsedWords[0];

    // If the command entered was blank, skip it
    if (wordCount == 0)
      continue;
    // Determining which command to run
    if (strcmp(command, "cd") == 0)
    {
      runCd(parsedWords, wordCount);
    }
    else if (strcmp(command, "exit") == 0)
    {
      runExit(parsedWords, wordCount);
    }
    else
    {
      runCommand(parsedWords, wordCount);
    }
  }
}