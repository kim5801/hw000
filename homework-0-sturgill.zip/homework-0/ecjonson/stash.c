/**
    @file stash.c
    @author Evan Jonson (ecjonson)
    This is an exercise on creating a basic shell program. Stash stands
    for "simple toy assignment shell". There are a couple of built in commands
    (cd, exit), everything else gets run through a child process using execvp().
*/

#include <stdlib.h>
#include <stdio.h>
#include <stdbool.h>
#include <ctype.h>
#include <string.h>
#include <unistd.h>
#include <sys/wait.h>
#include <sys/types.h>

/** The maximum allowed number of characters in a command */
#define MAX_CMD_LEN 1024

/** The maximum number of words in the pointer array */
#define MAX_WORDS 513

/**
    Parses the given command. Each string in the given line is terminated
    and pointed to by the given pointer array. Returns the number of words
    parsed.
    @param line The given line to parse.
    @param words The given pointer array to update.
    @return The number of parsed words.
*/
static int parseCommand( char *line, char *words[] ) {
    // tracks the number of words
    int count = 0;
    
    // true if a word has been found, useful for skipping whitespace
    bool found = false;
    
    // loop through each character in the given line
    for ( int i = 0; line[ i ] != '\0'; ++i ) {
        
        // if we're in a word
        if ( found ) {
            // and whitespace is found
            if ( isspace( line[ i ] ) ) {
                
                // terminate the word
                line[ i ] = '\0';
                
                // mark found as false until the next word is found
                found = false;
            }
        }
        // we're looking for the next word
        else {
            // if non-whitespace is found
            if ( !isspace( line[ i ] ) ) {
                
                // update the pointer array and increment the count
                words[ count++ ] = &line[ i ];

                // mark found as true
                found = true;
            }
        }
    }

    return count;
}

/**
    Parses an integer from string from to int. Returns -1 if the given
    string does not represent a valid positive integer.
    @param str The given string to parse.
    @return The int representation of the given string, or -1.
*/
static int strToInt( char *str ) {
    // tracks the integer total
    int total = 0;
    
    // get the length of the string
    int len = strlen( str );
    
    // tracks the current character in the string
    char c;
    
    // tracks the current rank of the integer
    int rank = 1;
    
    // loop through the string starting from the right
    for ( int i = len - 1; i >= 0; --i ) {
        
        // get the current character in decimal
        c = str[ i ] - 48;
        
        // if this character is not valid, return -1
        if ( c < 0 || c > 9 )
            return -1;
        
        // add the current digit times its rank
        total += c * rank;
        
        // increase the rank
        rank *= 10;
    }
    
    return total;
}

/**
    Runs the built-in exit command. Parses the given command to exit
    with the appropriate exit code, or prints "Invalid command".
    @param words The pointer array representing the command.
    @param count The number of given commands.
*/
static void runExit( char *words[], int count ) {
    // check for valid input
    if ( count == 2 ) {
        
        // the exit status parsed from words
        int status = strToInt( words[ 1 ] );
        
        // exit with the appropriate status
        if ( status != -1 )
            exit( status );
    }
    
    // input was invalid
    printf ( "Invalid command\n" );
}

/**
    Runs the built-in cd command. uses chdir() to change directories
    if the given command is valid.
    @param words The given command.
    @param count The number of command line arguments.
*/
static void runCd( char *words[], int count ) {
    // check for valid input
    if ( count == 2 ) {
        
        // attempt to change directory
        if ( !chdir( words[ 1 ] ) )
            return;
    }
    
    // invalid input
    printf( "Invalid command\n" );
}

/**
    Runs all external commands using a fork() and execvp(), while
    The parent process waits.
    @param words The given command.
    @param count The number of command line arguments.
*/
static void runCommand( char *words[], int count ) {
    // make a child process
    pid_t id = fork();
    
    // add NULL for execvp()
    words[ count ] = NULL;

    // call execvp with the appropriate command in the child process
    if ( id == 0 ) {
        // attempt to run the command
        execvp( words[ 0 ], words );
        
        // command failed if this point is reached
        printf( "Can't run command %s\n", words[ 0 ] );
        
        // terminate the failed child process
        exit( 0 );
    }
    // the parent waits for the child to finish
    else
        wait( NULL );
}

/**
    Program starting point. Loops through user input to mimic a
    basic shell program.
    @return The exit status.
*/
int main() {
    // an array of pointers to words of the command
    char *words[ MAX_WORDS ];
    
    // holds the current user command
    char cmd[ MAX_CMD_LEN + 1 ];
    
    // loop through user input
    while ( true ) {
        // print the prompt
        printf( "stash> " );
    
        // get the command
        fgets( cmd, MAX_CMD_LEN + 1, stdin );
    
        // parse the command
        int numCmds = parseCommand( cmd, words );
        
        // empty, just continue
        if ( numCmds == 0 )
            continue;
        
        // built in cd
        else if ( strcmp( words[ 0 ], "cd" ) == 0 )
            runCd( words, numCmds );
        
        // built in exit
        else if ( strcmp( words[ 0 ], "exit" ) == 0 )
            runExit( words, numCmds );
 
        // external commands
        else
            runCommand( words, numCmds );
    }
    
    return EXIT_SUCCESS;
}
