/**
    @file exclude.c
    @author Evan Jonson (ecjonson)
    This is an excercise on system calls. Copies the given input file to the given
    output file, excluding the given line number, without using any C library functions.
*/

#include <unistd.h>
#include <fcntl.h>

/**
    Returns the length of the given string.
    @param str The string to measure.
    @return The length of the given string.
*/
static int strLen( char *str ) {
    // tracks the length of the string
    int len = 0;
    
    // loop until the string terminator is reached
    while ( str[ len ] != '\0' )
        ++len;
    
    // return the string length
    return len;
}

/**
    Converts an integer from string from to int. Returns -1 if the given
    string does not represent a valid positive integer.
    @param str The given string to convert to int.
    @return The int representation of the given string.
*/
static int strToInt( char *str ) {
    // tracks the integer total
    int total = 0;
    
    // get the length of the string
    int len = strLen( str );
    
    // tracks the current character in the string
    char c;
    
    // tracks the current rank of the integer
    int rank = 1;
    
    // loop through the string starting from the right
    for ( int i = len - 1; i >= 0; --i ) {
        
        // get the current character in decimal
        c = str[ i ] - 48;
        
        // if this character is not valid, return -1
        if ( c < 0 || c > 9 )
            return -1;
        
        // add the current digit times its rank
        total += c * rank;
        
        // increase the rank
        rank *= 10;
    }
    
    return total;
}

/**
    Prints a usage message to the error output stream and exits
    unsuccessfully.
*/
static void usage() {
    // usage message
    char msg[] = "usage: <input-file> <output-file> <line-number>\n";
    
    // write the usage message to the error output stream
    write ( STDERR_FILENO, &msg, strLen( msg ) );
    
    // exit failure
    _exit( 1 );
}

/**
    Program starting point. Copies the given input file to the given output file,
    excluding the given line number.
    @param argc The number of command line arguments.
    @param argv The command line arguments.
    @return The exit status.
*/
int main( int argc, char *argv[] ) {
    // the line number to exclude
    int excludeLine;

    // check the number of command line arguments and the line number to exclude
    if ( argc != 4 || ( excludeLine = strToInt( argv[ 3 ] ) ) == -1 )
        // print the usage message and exit
        usage();

    // open input file for reading
    int fdIn = open( argv[ 1 ], O_RDONLY );
    
    // check that the input file opened
    if ( fdIn == -1 )
        // print the usage message and exit
        usage();
    
    // open the output file for writing, creating it if necessary
    int fdOut = open( argv[ 2 ], O_CREAT | O_WRONLY | O_TRUNC , 0600 );
    
    // check that the output file opened
    if ( fdOut == -1 ) {
        // close the input file
        close( fdIn );
        
        // print the usage message and exit
        usage();
    }
    
    // a buffer that can hold 64 bytes
    char buffer[ 64 ];
    
    // read the first 64 bytes, if there are that many
    int len = read( fdIn, buffer, 64 );
    
    // the current line
    int line = 1;
    
    // keep printing contents of the buffer to the output file until eof
    while ( len > 0 ) {
        
        // print characters one byte at a time, while counting the lines
        for ( int i = 0; i < len; ++i ) {
            
            // write all lines except the exclude line
            if ( line != excludeLine )
                write( fdOut, &buffer[ i ], 1 );
            
            // increment the line counter if necessary
            if ( buffer[ i ] == '\n' )
                ++line;
        }
        
        // read the next 64 bytes
        len = read( fdIn, buffer, 64 );
    }
    
    // close the files
    close( fdIn );
    close( fdOut );

    // exit success
    return 0;
}
