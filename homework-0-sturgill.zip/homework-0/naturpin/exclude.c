#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>

// Number of command-line arguments the program expects
#define NUM_ARGS 4

// Number of bytes to be read
#define NUM_BYTES 64

// The base of the number system being used. For decimal, that's 10
#define BASE 10

// A quick little function that converts an ASCII string to a decimal. In this program, 
// it's used for the command-line argument that specifies which line to delete
int argToDecimal( char *lineNumber ) {

    // The total number to be returned
    int total = 0;

    // The current digit we're converting
    int current = 0;

    // Go through each character, convert to decimal, and add it to the total
    int i = 0;
    while ( lineNumber[ i ] >= '0' && lineNumber[ i ] <= '9' ) {

        current = lineNumber[ i ] - '0';
        total = total * BASE;
        total = total + current;

        // Don't forget to increment i
        i++;
    }

    // When we're done, return the total
    return total;
}

int main( int argc, char *argv[] ) {

  // Create input and output files for reading and writing
  int fr = open( argv[ 1 ], O_RDONLY);
  int fw = open( argv [ 2 ], O_WRONLY | O_CREAT, 0600 );

  // Create a buffer array we can use to transfer bytes between the two files
  char buffer[ NUM_BYTES + 1 ];

  // Keep track of what line we're on currently
  int currentLine = 1;

  // Convert given line number from ASCII to decimal
  int deleteLine = argToDecimal( argv [ 3 ] );

  // Error handling for (a) a file can't be read and (b) invalid arguments are given (including negative line numbers)
  if ( fr < 0 || fw < 0 || argc != NUM_ARGS || deleteLine <= 0 ) {
    write( STDERR_FILENO, "usage: exclude <input-file> <output-file> <line-number>\n", NUM_BYTES );
    _exit( 1 );
  }
  
  // To see when we've run out of characters to read
  int charsRead = NUM_BYTES;

  // To distinguish between the number of chars we've read and how many we actually want to output
  int charsWrote = 0;

  // Do the reading and writing as long as there's more stuff to read and write. Since we're
  // doing that in increments of 64, we know we've reached the end if we ever find less that
  // 64 bytes to read and write
  while ( charsRead == NUM_BYTES ) {

    // Flush the buffer with a character we know not to read. That way, if we read in less than 64 bytes,
    // We won't have old characters filling the remaining bytes
    for (int i = 0; i <= NUM_BYTES; i++) {
        buffer[ i ] = '\0';
    }

    // Read in the next block, keeping track of how many chars we've read
    charsRead = read( fr, buffer, NUM_BYTES );
    charsWrote = charsRead;

    // Check the buffer for a newline character
    for ( int i = 0; i < charsRead; i++ ) {

        // If one exists, we know we're on to the next line
        if ( buffer[ i ] == 0x0a ) {
            currentLine++;

            // I've designed this loop to remove the newline from the line before the deleted line, rather than 
            // the newline on the deleted line itself. For the first line of the file, this is a problem. So, for this 
            // particular case, we'll delete the newline on the deleted line
            if ( deleteLine == 1 && currentLine == 2 )
                goto delete;

            if ( currentLine == deleteLine && charsRead < NUM_BYTES )
                continue;
        }

        // Now, if we're on the line we want to delete, we have to iterate through our whole buffer
        // and shift everything over by 1, effectively deleting one character from the buffer.
        if ( currentLine == deleteLine && buffer[ i ] != '\0' ) {
            delete:
                for ( int j = i; j < charsRead; j++ ) {
                    buffer[ j ] = buffer[ j + 1 ];
                }

                // Once we've done so, we need to inform the writer to write less stuff. Otherwise, we'll 
                // get a bunch of null characters at the end of our 64 byte block
                charsWrote--;
                // Also, since we've just moved all the characters forward by 1, we want to continue reading 
                // in the same spot we were just at. This line just nullifies the increment that would occur anyway
                i--;
        }
    }

    // As long as we're not on the line we need to delete, write the buffer to output
    write( fw, buffer, charsWrote );

  }

  // Close the files and exit.
  close( fr );
  close( fw );
  return 0;
}
