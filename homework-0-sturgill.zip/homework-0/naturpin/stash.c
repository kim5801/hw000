#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>

#define LINE_MAX 1024
#define WORD_MAX 513

// A small method that checks a command for the correct number of arguments
static bool checkArgs( int count, int target ) {
    if (count != target) {
        printf( "Invalid command\n" );
        return false;
    }

    return true;
}

// Fun fact: running atoi() on a string will return 0. Since something like "exit bad-argument" isn't meant to be valid, 
// we need to check that the argument is actually comprised of all digits before we run atoi(). This function does that for us
static bool isDigitsOnly( char * word ) {
    for (int i = 0; word[i] != '\0'; i++) {
        if( !isdigit(word[i]))
            return false;
    }

    return true;
}

// Takes a string, the command line, and separates it into an array of words
int parseCommand( char *line, char *words[] ) {

    // Number of words in the line and, consequentially, the words array
    int numWords = 0;

    // The delimiters used by strtok(). Should cover every whitespace character
    char delim[] = " \t\r\n\v\f";

    // A variable to hold each "token" of the command string. We'll be using strtok() to 
    // chop up the string using spaces as our delimiter
    char * token = (char *)malloc(LINE_MAX * sizeof(char));

    for (numWords = 0; ; numWords++, line = NULL) {
        token = strtok(line, delim);
        words[ numWords ] = token;
        // If our token is ever NULL, we know we've reached the end of the string
        if(token == NULL)
            break;
    }

    // Don't forget to free the space we allocated
    free(token);

    // Then we return the number of words we read, to use later
    return numWords;
}

// Handles the exit command
void runExit( char *words[], int count ) {
    // Make sure we have the correct number of arguments, then run exit with the given status
    if ( checkArgs( count, 2 ) && isDigitsOnly( words[ 1 ] ) )
        exit( atoi( words[1] ) );
}

// Handles the cd command
void runCd( char *words[], int count ) {
    // Make sure we have the correct number of arguments, then run cd with the given path
    if ( checkArgs( count, 2 ) )
        chdir( words[1] );
}

// For running external commands
void runCommand( char *words[], int count ) {
    // fork the process, keeping track of the id of the child
    int pid = fork();

    // Assuming we only have one child process, its pid will be zero. So, if the process is the child, run this code
    if ( pid == 0 ) {
        // Make sure the last element in the array is NULL, so execvp() knows when to stop
        words[ count ] = NULL;
        // Then, run the command
        int ret = execvp( words[0], words );

        // If something goes wrong, let the user know and terminate the child
        if ( ret == -1 ) {
            printf( "Can't run command %s\n", words[ 0 ] );
            exit(1);
        }

        // Don't forget to terminate the child
        exit(0);
        
    } else {
        // Otherwise, if the process is the parent, just wait
        wait(NULL);
    }
}

int main( int argc, char *argv[] ) {

    // Prompt a command from the user
    printf("%s", "stash> ");

    // A string to store user-inputted commands
    char * cmd = (char *)malloc(LINE_MAX * sizeof(char));
    fgets(cmd, LINE_MAX, stdin);

    // An array of words used to parse commands
    char ** words;

    // The length of the word array, or the number of words
    int len = 0;

    // We want this loop to run until the user chooses to exit
    // Since that's handled inside the loop, we don't really have a conditional to predicate
    // the loop on. So, we'll just loop indefinitely
    while( true ) {

        // Allocate space for the words array
        words = (char **)malloc(WORD_MAX * sizeof(char));

        // Parse the command, keeping track of how many words we've read
        len = parseCommand( cmd, words );

        // Check which command we should run
        if( words[0] == NULL ) {
            // Case 1: an empty command. Just skip this
        } else if( strcmp( words[0], "exit" ) == 0 ) {
            // Case 2: exit command
            runExit( words, len );
        } else if( strcmp( words[0], "cd" ) == 0 ) {
            // Case 3: cd command
            runCd( words, len );
        } else {
            // Case 4: external commands
            runCommand( words, len );
        }

        // Prompt the user again
        printf("%s", "stash> ");

        // Reset the memory for our command by freeing and reallocating it
        free(cmd);
        cmd = (char *)malloc(LINE_MAX * sizeof(char));
        fgets(cmd, LINE_MAX, stdin);
    }
    
}