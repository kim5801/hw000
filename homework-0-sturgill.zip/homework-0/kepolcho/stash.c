/**
 * Program prompts user for a command and then execute
 * said commmand using passed arguments
 */

#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h>
#include <sys/wait.h>

#define MAX_WORDS 513
#define MAX_WORD_LENGTH 1024

/**
 * Take user command as input (line). Break up the passed line
 * into individual words, each with a null terminator (\0). First
 * word is the command, following words are arguments for the command. 
 */
int parseCommand(char *line, char *words[]) {
    // extract words from line and malloc appropriate size
    char *token = strtok(line, " ");
    int count = 0;
    while (token != NULL) {
        strcpy(words[count], token);
        token = strtok(NULL, " ");
        count++;
    }
    
    // replace spaces with null character
    for (int i = 0; i < strlen(line); i++) {
        if (isspace(line[i]) == 0) {
            line[i] = '\0';
        }
    }
    // return words in line
    return count;
}

/**
 * Performs the exit command. Worqds is the words in 
 * command, count is the number of words in array
 */
void runExit(char *words[], int count) {
    // get value from words
    int status = -1;
    sscanf(words[1], "%d", &status);

    // check for invalid argument
    if (count != 2 || status < 0) {
        printf("Invalid command\n");
    }
    else {
        if (status > 256) {
            status = status % 256;
        }
        exit(status);
    }
}

/**
 * Performs the cd command, same parameters as runExit function
 */
void runCd(char *words[], int count) {
    // first word is cd, second word is argument
    // error checking first, execute after
    if (count != 2) {
        printf("Invalid command\n");
    }
    else {
        // pass path string to chdir
        int invalid = chdir(words[1]);
        if (invalid) {
            printf("Invalid command\n");
        }
    }    
}

/**
 * run passed command using a child process. Child will call
 * execvp() to execute the command. Handles commands not built-in
 */
void runCommand(char *words[], int count) {
    // make fork
    pid_t pid = fork();

    if (pid == 0) {
        words[count] = '\0';
        int status = execvp(words[0], words);
        
        if (status == -1) {
            printf("Can't run command %s\n", words[0]);
            _Exit(EXIT_FAILURE);
        }
    }
    else {
        wait(NULL);
    }
}

int main (int argc, char *argv[]) {   

    while(1) {
        char *line = (char *) calloc(MAX_WORD_LENGTH, sizeof(char));

        // make double array of words
        char **words = (char**) calloc(MAX_WORDS, sizeof(char*));

        // allocate words array
        for (int i = 0; i < MAX_WORDS; i++) {
            words[i] = (char*) calloc(MAX_WORD_LENGTH, sizeof(char));
        }    
        
        printf("stash> ");
        // read in line of user input
        fgets(line, MAX_WORDS, stdin);
        // add null terminator to end
        line[strlen(line) - 1] = '\0';

        // parse the user command
        int count = parseCommand(line, words);

        // check what command to run
        if (strcmp(words[0], "cd") == 0) {
            runCd(words, count);
        }
        else if (strcmp(words[0], "exit") == 0) {
            runExit(words, count);
        }
        else {
            runCommand(words, count);
        }          

        // free memory
    
        // for (int i = 0; i < MAX_WORDS; i++) {
        //     free(words[i]);
        // } 
        // free(words);

        // free(line);
    } 
    

    //exit successfully
    return 0;
}