/** 
 * goal of program is to take the input, 
 * remove the indicated line, and then put it into the
 * output file without using C standard library functions
 */

#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>

int main (int argc, char *argv[]) {
// accepted input would be "input-file output-file omit-line"
// so $ ./exclude input-1.txt output.txt 3 would be accepted

    // check if arguments are valid
    if (argc != 4 || (*argv[3] - '0') < 1) {
        // open the error file
        
        // print error message
        write(STDERR_FILENO, "useage: exclude <input-file> <output-file> <line-number>\n", 58);
        // exit w/ status
        _exit(1);
    }

    // open file to read
    int input = open(argv[1], O_RDONLY);

    // open the file using passed output name
    int output = open(argv[2], O_CREAT | O_WRONLY | O_TRUNC, 0700);

    // what line to omit
    int omitLine = *argv[3] - '0';
    // make buffer to hold file
    char buffer[10] = "";
    int lineNum = 1;

    // count number of lines, write to correct index in output buffer
    int ch = 0;
    // read to end of file (denoted by 0) and read each line
    // into the output buffer
    while ((ch = read(input, buffer, sizeof buffer)) > 0) {   
        int runNum = 1;
        for (int i = 0; i < ch; i++) {
            if (lineNum != omitLine) {
                write(output, &buffer[i], sizeof(char));
            }
            if (buffer[i] == '\n') {
                lineNum++;
            }
        }
        runNum++;
    }

    // close files
    close(input);
    close(output);

    // exit successful!
    _exit(0);
}