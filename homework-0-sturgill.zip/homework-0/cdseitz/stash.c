#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>

//max number of characters that a user can type on a line for a command
#define CHAR_LIMIT 1024

//max number of words possible for a command given the character limit constant 
#define WORDS_LIMIT 513

//given existing character array and pointer array
//updates line array with null characters instead of spaces
//and updated words to point to start of each word in line
//returns number of words
int parseCommand( char *line, char *words[] ) {

    //index of the line array
    int i = 0;

    //get the first character from input
    int ch = getchar();
    int numWords = 0;
    //keep adding characters as long as there are characters
    while (ch != -1 && ch != '\n') {
        line[i] = ch;
        i++;
        ch = getchar();
    }

    //go thru the line and count the number of words
    for (int j = 0; j <= i; j++ ) {
        //case 0: index is at start of array so can't check behind it
        if (j == 0) {
            if (line[j] != ' ' && line[j] != '\0') {
                numWords++;
            }
        //for everything else, make sure character before is a space
        } else {
            if((line[j - 1] == ' ' && (line[j] != ' ' && line[j] != '\0'))) {
                numWords++;
            }
        }
        
    }

    //replace all spaces with null characters in line
    for (int j = 0; j <= i; j++ ) {
        if (line[j] == ' ') {
            line[j] = '\0';
        }
    }

    //index for words array of pointers
    int k = 0;
    
    //go through line and words, making words[k] a pointer
    //to the first character of each word in line
    for (int j = 0; j <= i; j++ ) {
        //case 0: index is at start of array so can't check behind it
        if (j == 0) {
            if (line[j] != ' ' && line[j] != '\0') {
                words[k] = &line[j];
                k++;
            }
        //for everything else, make sure character before is a space
        } else {
            if((line[j - 1] == '\0' && (line[j] != ' ' && line[j] != '\0'))) {
                words[k] = &line[j];
                k++;
            }
        }

    }
    return numWords;
}

//given the words pointer array and number of words
//runs the exit command
void runExit(char *words[], int count) {
    if (count != 2) {
        printf("Invalid command\n");
    } else {
        //status number to be exited with
        int status;
        //read in the string to become an integer
        int numMatches = sscanf(words[1], "%d", &status);
        // if no matches, couldn't be parsed as an int
        if (numMatches == 0) {
            printf("Invalid command\n");
        //exit with the correct status
        } else {
            exit(status);
        }
    }
}

//given the words pointer array and number of words
//runs the cd command
void runCd(char *words[], int count) {
    //expects 2 params
    if (count != 2) {
        printf("Invalid command\n");
    } else {
        int status = chdir(words[1]);
        //-1 status means it wasn't a valid path
        if (status == -1) {
            printf("Invalid command\n");
        }
    }
}

//runs external command with count and words arrays
void runCommand( char *words[], int count ) {
    int pid = fork();
    //fork failure
    if (pid == -1) {
        printf("Can't run command %s\n", words[0]);

    //child process
    } else if (pid == 0) {
        //make an array to hold the other words needed for command
        char *paramArray[count + 1];
        for (int i = 0; i < count; i++) {
            paramArray[i] = words[i];
        }
        //needs to be null terminated
        paramArray[count] = NULL;
        //run command and mark its status
        int status = execvp(words[0], paramArray);
        //command couldn't be parsed
        if (status == -1) {
            printf("Can't run command %s\n", words[0]);
        }
        exit( EXIT_SUCCESS );
    //parent process waits
    } else {
        wait(NULL);
    }
}

//start of program with continuous loop of prompting
int main() {
    //keep reprompting user in a loop til exit
    while (1 == 1) {
        //prompt user
        printf("stash> ");
        //array that stores the entire line of input with room for null ending
        char line[CHAR_LIMIT + 1] = {};

        //words array of pointers
        char *words[WORDS_LIMIT];

        //update line array and words array and return number of words found
        int numWords = parseCommand(line, words);

        //if there are no words, just skip and prompt again
        if (numWords > 0) {

            //cd command
            if (strcmp(words[0], "cd") == 0) {
                runCd(words, numWords);
            }
        
            //exit command
            else if (strcmp(words[0], "exit") == 0) {
                runExit(words, numWords);
            }

            //try running it as external command
            else {
                runCommand(words, numWords);
            }
        } 
        
    }
}