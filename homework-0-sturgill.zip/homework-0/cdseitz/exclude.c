#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>

//number of bytes to read the file as chunks
#define BLOCK_SIZE 64

//Ascii decimal value for digit 0
#define ASCII_0 48

//Ascii decimal value for digit 9
#define ASCII_9 57

//takes in pointer to char array and returns the length
//of it (minus the null termination)
int findStrLen (char *str) {
    int count = 0;
    int i = 0;
    do {
        char curr = str[i];

        //this is only possible if the first character is null
        //so return 0
        if (curr == '\0') {
            return count;
        }
        //increase count each loop
        count++;
        i++;

    //exits if it reaches null character and doesn't add it count
    } while(str[i] != '\0');
    return count;
}

//write to std error with usage statement
static void fail() {
    char *message = "usage: exclude <input-file> <output-file> <line-number>\n";
    //get str length and write each character one by one
    for (int i = 0; i < findStrLen(message); i++) {
        write( STDERR_FILENO, &message[ i ], 1 );
    }
}

//given pointer to char in array, return the integer representation of it
int getLineToSkip(char *str) {
    //get length of string without null termination
    int strLen = findStrLen(str);
    //keeps track of current base-10 integer value
    int currValue = 0;
    //keep track of what place value we are at
    int currMultiplier = 1;
    for (int i = strLen - 1; i >= 0; i--) {
        int currDigit = str[i];
        //adjust from ASCII to digit
        if (currDigit >= ASCII_0 && currDigit <= ASCII_9) {
            currDigit = currDigit - ASCII_0;
        }
        //if it's not in that ASCII range, it's invalid
        else {
            fail();
            _exit(1);
        }
        //update current value and multiplier
        currValue = currValue + currDigit * currMultiplier;
        currMultiplier = currMultiplier * 10;
        
    }
   
    return currValue;
}

int main( int argc, char *argv[] ) {
    //invalid number of parameters, fail it
    if (argc != 4) {
        fail();
        _exit(1);
    }

    //open input file or fail it
    int fdi = open( argv[1], O_RDONLY);
    if ( fdi == -1 ) {
        fail();
        _exit( 1 );
    }
    //open output file or fail it
    int fdo = open( argv[2], O_WRONLY | O_CREAT | O_TRUNC, 0600);
    if ( fdo == -1 ) {
        fail();
        _exit( 1 );
    }

    //which line will not be printed
    int lineToSkip = getLineToSkip(argv[3]);

    //keep track of which line is being read, starting at 1
    int currLine = 1;

    //64 byte character buffer for reading into 
    char buffer[ BLOCK_SIZE ]  = {};
    //read 64 bytes into buffer from input file
    int len = read( fdi, buffer, sizeof( buffer ) );
    while ( len > 0 ) {
        //go through each byte written in and if the current
        //line isn't the one to skip, write to output
        for ( int i = 0; i < len; i++ ) {
            if (currLine != lineToSkip) {
                write( fdo, &buffer[ i ], 1 );
            }

            //update which line it's on after outputting
            if (buffer[i] == '\n') {
                currLine++;
            }
        }
        
        //update len with new read in (could be less than buffer size)
        len = read( fdi, buffer, sizeof( buffer ) );
    }

    //close read and write files
    close(fdi);
    close(fdo);
    return 0;

}
