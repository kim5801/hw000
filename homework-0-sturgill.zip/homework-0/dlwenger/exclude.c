/**
 * @file exclude.c
 * @author Daniel Wenger (dlwenger@ncsu.edu)
 * This program omits a line from a text file and saves it in another file. The user specifies the input and output file names and
 * the line that will be omitted.
 *
 */
#include <fcntl.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <unistd.h>

/** The number of command line arguments needed */
#define CORRECT_ARGS 4
/** The user permissions that will be given to the new file */
#define USR_PERMISSIONS 0600
/** The size of the buffer that will will store the bytes as they are processed */
#define BUFFER_SIZE 64
/** The index of the line argument in the argv array */
#define LINE_ARG 3
/** The index of the name of the in-file in the argv array */
#define INFILE_ARG 1
/** The index of the name of the out-file in the argv array */
#define OUTFILE_ARG 2

/**
 * Helper function for converting the line number argument to an integer
 *
 * @param num the number that will be the base of the exponent
 * @param power the number that will be the exponent
 * @return the result of the operation
 */
int power(int num, int power)
{
    int retval = 1;
    for (int i = 0; i < power; i++) {
        retval *= num;
    }
    return retval;
}
/**
 * Function for handling an error in formatting.
 *
 */
void error()
{
    write(STDERR_FILENO, "usage: exclude <input-file> <output-file> <line-number>\n", 57);
    _exit(1);
}

/**
 * Function for parsing the line number from the command line argument. Converts the number from a string to an integer.
 *
 * @param line the string that contains the line number
 * @param numOfDigits the length of the string
 * @return the line number in an integer format
 */
int lineNumParser(char *line, int numOfDigits)
{
    int lineNum = 0;
    for (int i = 0; i < numOfDigits; i++) {
        if (line[i] < '0' || line[i] > '9') {
            error();
        }
        lineNum += (line[i] - '0') * power(10, numOfDigits - (i + 1));
    }
    if (lineNum == 0) {
        error();
    }
    return lineNum;
}

/**
 * Determines the amount of digits in the line number
 *
 * @param str the string that represents the line number
 * @return int the amount of digits in the string
 */
int stringlen(char *str)
{
    int num = 0;
    while (str[num] != '\0') {
        num++;
    };
    return num;
}

/**
 * The main function of the program. This function contains the code for reading the input file and copying it to
 * the output file with the specified line removed.
 *
 * @param argc The number of command line arguments
 * @param argv An array of pointers to the command line argument strings
 * @return The exit status of the program
 */
int main(int argc, char *argv[])
{
    if (argc != CORRECT_ARGS) {
        error();
    }

    int lineLen = stringlen(argv[LINE_ARG]);
    int lineNum = lineNumParser(argv[LINE_ARG], lineLen);

    int readFile = open(argv[INFILE_ARG], O_RDONLY);
    // in the open man page, it specifies that the creat() function is equivalent to open() with O_WRONLY, O_CREAT, and O_TRUNC flags
    int writeFile = creat(argv[OUTFILE_ARG], USR_PERMISSIONS);
    if (readFile == -1 || writeFile == -1) {
        error();
    }

    int lineProgress = 1;
    int lineFlag = lineNum == 1 ? 1 : 0;
    // Buffer where read in bytes will be stored
    char buff[BUFFER_SIZE];
    int readStatus = 1;
    // read the file in 64-byte groups and check for the specified line, then write to outfile
    while ((readStatus = read(readFile, buff, BUFFER_SIZE)) && readStatus != -1 && readStatus != 0) {
        // Buffer where bytes that will appear in the outfile will be stored
        char buffCpy[BUFFER_SIZE];
        int buffCpyIdx = 0;
        for (int i = 0; i < readStatus && buff[i] != 0; i++) {
            if (buff[i] == '\n') {
                // Removed line starts
                if (lineProgress == lineNum - 1) {
                    lineProgress++;
                    lineFlag = 1;
                    buffCpy[buffCpyIdx] = buff[i];
                    buffCpyIdx++;
                }
                // Removed line ends
                else if (lineProgress == lineNum) {
                    lineProgress++;
                    lineFlag = 0;
                }
                else {
                    lineProgress++;
                    buffCpy[buffCpyIdx] = buff[i];
                    buffCpyIdx++;
                }
            }
            else if (!lineFlag) {
                buffCpy[buffCpyIdx] = buff[i];
                buffCpyIdx++;
            }
        }
        // Write out temporary buffer to outfile
        write(writeFile, buffCpy, buffCpyIdx);
    }

    close(readFile);
    close(writeFile);
    return 0;
}
