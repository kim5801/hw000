/**
 * @file stash.c
 * @author Daniel Wenger (dlwenger@ncsu.edu)
 * The stash shell (simple toy assignment shell) is a shell that contains 3 built-in functions and a way to run other
 * programs through child processes.
 *
 */

#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <unistd.h>

/** The size of the buffer that will store the characters of the line that the user entered */
#define CHAR_AMOUNT 1025
/** The size of the buffer that will store the words that the user entered */
#define WORD_AMOUNT 513

/**
 * Takes the user command as input and breaks that line into individual words separated by null terminator characters.
 * Fills the words array with pointers to the start of each line.
 *
 * @param line The user command
 * @param words An array that will hold pointers to the words in the user commands
 * @return int the number of words found in the command
 */
int parseCommand(char *line, char *words[])
{
    int wordIdx = 0;
    char *wordPtr = line;
    int lineLen = strlen(line);
    for (int i = 0; i < lineLen; i++) {
        if (line[i] == ' ') {
            line[i] = '\0';
            words[wordIdx] = wordPtr;
            if (line[i + 1] != ' ') {
                wordPtr = &line[i + 1];
                wordIdx++;
            }
        }
    }
    words[wordIdx] = wordPtr;
    words[wordIdx + 1] = NULL;
    return wordIdx + 1;
}
/**
 * Performs the built-in exit command.
 *
 * @param words the array of pointers to the words given in the user command
 * @param count the number of words given in the user command
 */
void runExit(char *words[], int count)
{
    if (count != 2) {
        printf("Invalid command\n");
        return;
    }
    for (int i = 0; i < strlen(words[1]); i++) {
        if (words[1][i] > '9' || words[1][i] < '0') {
            printf("Invalid command\n");
            return;
        }
    }
    exit(atoi(words[1]));
}
/**
 * Function that performs the built in cd command that will change the current directory of the shell.
 *
 * @param words the array of pointers to the words given in the user command
 * @param count the number of words given in the user command
 */
void runCd(char *words[], int count)
{
    if (count != 2 || chdir(words[1]) == -1) {
        printf("Invalid command\n");
        return;
    }
}
/**
 * Function for running any non-built-in commands by creating a child process
 *
 * @param words the array of pointers to the words given in the user command
 * @param count the number of words given in the user command
 */
void runCommand(char *words[], int count)
{
    pid_t child = fork();
    bool andFlag = false;

    if (strcmp(words[count - 1], "&") == 0) {
        words[count - 1] = '\0';
        andFlag = true;
    }

    if (child == 0) {
        if (execvp(words[0], words) == -1) {
            if (!andFlag) {
                printf("Can't run command %s\n", words[0]);
            }
            exit(0);        
            
        }
    }
    else {
        if (andFlag) {
            printf("[%d]\n", child);

            return;
        }
        pid_t possibleChild = wait(NULL);
        while (child != possibleChild) {
            printf("[%d done]\n", possibleChild);
            possibleChild = wait(NULL);
        }
    }
}

/**
 * The main function of the stash shell.
 *
 */
int main()
{
    while (true) {
        char command[CHAR_AMOUNT] = {};
        int idx = 0;
        printf("%s", "stash> ");
        char c;
        while ((c = getchar()) != '\n') {
            command[idx] = c;
            idx++;
        }
        char *words[WORD_AMOUNT] = {};
        int count = parseCommand(command, words);
        if (strcmp(words[0], "exit") == 0) {

            runExit(words, count);
        }
        else if (strcmp(words[0], "cd") == 0) {
            runCd(words, count);
        }
        else if (strcmp(words[0], "") == 0) {
            continue;
        }
        else {
            runCommand(words, count);
        }
    }
}
