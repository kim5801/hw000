/**
 * @file stash.c
 * @author Bagya Maharajan
 * stash is a shell program that makes system or library calls to behave like a shell
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <stdbool.h>
#include <unistd.h>
#include <sys/wait.h>
#include <sys/types.h>

/** Max Length of a command excluding any terminators */
#define CMD_LENGTH 1024
/** max number of words allowed based on the limit on line length */
#define WORDS_LENGTH 513


/**
 * Breaks down a line into separate words. Word array points to start of each word.
 * @param line is the command to be parsed
 * @param words is the pointer array that points to each word in the command
 * @return number of words in the line(or cmd)
 */
int parseCommand( char *line, char *words[] )
{
    int word_count = 0;
    int j = 0;

    //parsing through the line
    for( int i = 0; line[i]; i++) {
        
        if( line[i] == ' ' ) {
            line[i] = '\0';

            if(line[i+1] == ' ') continue;
            
            if( line[i + 1] == '\0') return word_count;
            words[j] = &(line[i+1]);
            j++; 
            word_count++; 
        }

        if( j == 0) {
            words[j] = &(line[i]);
            j++;
            word_count++;
        }
    }

    return word_count;
}

/**
 * Uses the built-in exit command to exit with mentioned status
 * @param words is an array of pointers to words in the cmd
 * @param count - word count
 */
void runExit( char *words[], int count )
{
    if( count != 2) {
        printf("Invalid command\n");
        return;
    }

    char exit_str[CMD_LENGTH];
    int idx = 0;
    for(int i = 0; words[1][i]; i++) {
        if(isalpha(words[1][i])) {
            printf("Invalid command\n");
            return;
        }
        exit_str[idx] = words[1][i];
        idx++;
    }
    exit_str[idx] = '\0';
    int x = atoi(exit_str);

    exit(x);
}

/**
 * Performs the built-in cd command
 * @param words is an array of pointers to words in the cmd
 * @param count - word count
 */
void runCd( char *words[], int count )
{
    if( count != 2) {
        printf("Invalid command\n");
        return;
    }

    char path[CMD_LENGTH];
    int i = 0;
    for(i = 0; words[1][i]; i++) {
        path[i] = words[1][i];
    }
    path[i] = '\0';

    int ret_value = chdir(path);

    if(ret_value == -1) {
        printf("Invalid command\n");
    }
}

/**
 * Runs  a non-built-in command by using fork() and execvp()
 * Source: use of pid_t and its header from stack overflow
 * @param words is an array of pointers to words in the cmd
 * @param count - word count
 */
void runCommand( char *words[], int count )
{
    //finding the command
    char curr_cmd[CMD_LENGTH + 1];
    int idx = 0;
    for(int i = 0; words[0][i]; i++) {
        curr_cmd[idx] = words[0][i];
        idx++; 
    }
    curr_cmd[idx] = '\0';

    pid_t pid = fork();

    if(pid == 0) { //child        
        
        int r1 = execvp(curr_cmd, words); 

        if(r1 == -1) {
            printf("Can't run command %s\n", curr_cmd);
        }

        
    }

    if(pid > 0) {
        int status;
        pid = wait(&status); 
        
    }
    

}

/**
 * Main method receives commands to process
 */
int main(){

    char command[CMD_LENGTH + 1]; //1024 + 1

    bool loop = true;
    int ampersand = 0;
    pid_t bgc = 0;
    int done = 0;
    int stash_prompt = 0;

    while(loop) {
        char *words[WORDS_LENGTH];//513

        if(stash_prompt != 2) {
            fprintf(stdout, "%s", "stash> ");
        }

        int len = 0;
        int ch = fgetc(stdin);
        while(ch != '\n') {
            if(ch == '&') {
                ampersand = 1;
                ch = '\0';
                continue;
            }
            command[len] = ch;
            len++;
            ch = fgetc(stdin);
        }
        command[len] = '\0';
        if(len == 0) continue;    
        
        int word_count = parseCommand(command, words);

        char curr_cmd[CMD_LENGTH + 1];
        int idx = 0;
        for(int i = 0; words[0][i]; i++) {
            curr_cmd[idx] = words[0][i];
            idx++; 
        }
        curr_cmd[idx] = '\0';
        
        //built-in cmds
          //exit
        if(strcmp(curr_cmd, "exit") == 0) {
            runExit(words, word_count);
        }
          //cd
        else if(strcmp(curr_cmd, "cd") == 0) {
            runCd(words, word_count);
        }

        else {
            words[word_count] = NULL; //for execvp
            
            if(bgc != 0 && done == 1) {
                printf("[%d done]\n", bgc);
                done = 0;
                bgc = 0;
                stash_prompt = 0;

            }
            
            if(ampersand == 1) {
                
                ampersand = 0;
                pid_t child = fork();
                

                if(child == 0) {	
                    bgc = getpid();	  
                    
                    if(fork() == 0) {
                        runCommand(words, word_count);
                        
                        done = 1;
                        stash_prompt = 2;
                        
                        
                    }

                    int stat;
                    wait(&stat);
                    
                }

                else {
                    
                    printf("[%d]\n", child);
                    bgc = child;                                    

                }
                
                    
                
            }

            else { //no ampersand
                runCommand(words, word_count);                
                            
            }

        }
                

    }

    return EXIT_SUCCESS;
}