/**
 * @file exclude.c
 * @author Bagya Maharajan
 * Program to exclude a specified line while printing from an input file to an output file.
 */

#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>

/** exit status for an error */
#define FAILED 1
/** maximum arguments */
#define ARGUMENTS 4
/** ascii value of zero used to convert a value from string to int */
#define ASCII_0 48
/** Maximum bytes to read form a file */
#define READ_BYTES 64

/**
 * Finds length of a string
 * @param string to find length for
 * @return length of string
 */
int strlength(char const string[])
{
    int length = 0;
    for(int i = 0; string[i]; i++) {
        length = i;
    }

    return length + 1;
}

/**
 * Converting string to int
 * @param string to convert to int
 * @return int value of the string
 * Source: HW0 description and stackoverflow 
 */
int strtoint(char const string[])
{
    int num = 0;
    int length = strlength(string);

    for(int i = 0; i < length; i++) {
        num = num * 10 + (string[i] - ASCII_0);
    }

    return num;
}

/**
 * Prints error message and exits
 */
void error()
{
    char msg[] = "usage: exclude <input-file> <output-file> <line-number>\n";
    int count = strlength(msg);
    write(STDERR_FILENO, msg, count); 
    _exit(FAILED);
}

/**
 * Main method to perform i/o functionality
 * @param argc #args
 * @param argv command line args
 */
int main( int argc, char *argv[]) 
{
    //invalid #arguments
    if (argc < ARGUMENTS) error();

    //non-positive iint
    int num_line_given = strtoint(argv[3]);
    if(num_line_given <= 0) error();

    int in_fd = open(argv[1], O_RDONLY);
    
    //unable to open file to read
    if(in_fd < 0) {
        close(in_fd);
        error();
    }

    int out_fd = open(argv[2], O_CREAT | O_WRONLY | O_TRUNC, 0600);
    
    //unable to open file to write to
    if(out_fd < 0) {
        close(in_fd);
        error();
    }

    char buf[READ_BYTES + 1]; //65
    int byte_read = read(in_fd, buf, READ_BYTES);
    buf[byte_read] = '\0'; //prevents memory leak
    
    int line_found = 1;

    while(byte_read > 0) {

        for(int j = 0; j < byte_read; j++) {

            //storing one byte
            char *buf_one = &buf[j];

            if(buf[j] == '\n') { //newline found
                line_found++;
            }

            if(line_found != num_line_given) {
                write(out_fd, buf_one, 1);
            }

        }

        byte_read = read(in_fd, buf, READ_BYTES);
        buf[byte_read] = '\0';
        
    }

    //closing input and output file fds
    close(in_fd);
    close(out_fd);

}
