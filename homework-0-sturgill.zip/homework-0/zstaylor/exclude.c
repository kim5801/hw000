/**
 * @file exclude.c
 * @author Zachary Taylor (zstaylor)
 * Exclude takes in 2 file names and a line number, and puts the contents of the first file into the second
 * excluding the specified line by the line number.
 */
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>

int parseline(char* in);

/**
 * Main function, reads in file and outputs it without the specified line number
 * @param argc Argument count
 * @param argv Argument array
 * @return Exit status
 */
int main(int argc, char* argv[]) {

    //check for invalid arguments
    if(argc != 4) {
        char errmsg[] = "usage: exclude <input-file> <output-file> <line-number>\n";
        write(STDERR_FILENO, errmsg, sizeof(errmsg) - 1);
        _exit(1);
    }

    //parse line number into integer
    int lineNumber = parseline(argv[3]);

    //open input and output files and get file descriptors
    int inputfd = open(argv[1], O_RDONLY);
    int outputfd = open(argv[2], O_WRONLY | O_CREAT | O_TRUNC, 0600);

    //ensure both files were opened correctly, exit if not
    if(inputfd == -1 || outputfd == -1) {
        char errmsg[] = "usage: exclude <input-file> <output-file> <line-number>\n";
        write(STDERR_FILENO, errmsg, sizeof(errmsg) - 1);
        _exit(1);
    }

    //set the current line number
    int currLine = 1;

    //boolean loop, exit when EOF reached
    int reading = 1;
    while(reading) {

        //create buffer to read into
        char buffer[64] = {};
        size_t count = read(inputfd, buffer, 64);


        for (int i = 0; i < count; i++) {

            //precautionary break if reached null somehow
            if(buffer[i] == '\0') {
                break;
            }

            if (buffer[i] == '\n' ) {

                //write a newline if it is one side of the removed line, or if it is not at all
                if(currLine != lineNumber) {
                    currLine += 1;
                    write(outputfd, buffer + i, 1);

                }
                else {
                    currLine += 1;
                }

            } else if (currLine != lineNumber) {
                write(outputfd, buffer + i, 1);

            }
        }

        if(count == 0 || count < 64) {
            reading = 0;
        }

    }

    //close output files
    close(inputfd);
    close(outputfd);

    return EXIT_SUCCESS;
}

/**
 * Parses a line number from a character pointer
 * @param in Input character pointer
 * @return Integer conversion of input
 */
int parseline(char* in) {

    //check for invalid negative line number
    if(in[0] == '-') {
        char errmsg[] = "usage: exclude <input-file> <output-file> <line-number>\n";
        write(STDERR_FILENO, errmsg, sizeof(errmsg) - 1);
        _exit(1);
    }

    int result = 0;

    //calculate result, take each number and add to result. if there is another, mult by 10 first to move places
    for(int i = 0; in[i] != '\0'; i++) {

        if(in[i] >= '0' && in[i] <= '9') {
            result = result * 10;
            result += in[i] - '0';
        }
    }

    return result;
}