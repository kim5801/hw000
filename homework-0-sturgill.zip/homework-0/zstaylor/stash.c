/**
 * Stash is a basic shell program, with offerings of 2 built in commands and ability
 * to run any other command via forked process.
 * @file stash.c
 * @author Zach Taylor (zstaylor)
 */

#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <setjmp.h>
#include <string.h>

#include <sys/types.h>
#include <sys/wait.h>
#include <unistd.h>

int parseCommand(char* line, char* words[]);
void runExit(char* words[], int count);
void runCd(char* words[], int count);
void runCommand(char* words[], int count);
int parseInt(char* input, jmp_buf env);

/**
 * Program entry point, defines shell loop
 * @return Exit status
 */
int main() {

    //setup loop
    int running = 1;
    while(running) {

        printf("stash> ");

        //setup buffer for input
        char buffer[1025] = {};
        int buffCount = 0;

        //get input into buffer
        for(int i = 0; i < 1024; i++) {

            char in = getchar();

            if(in != '\n') {
                buffer[buffCount] = in;
                buffCount += 1;
            }
            else {
                buffer[buffCount] = '\0';
                break;
            }
        }

        //parse buffer into commands
        char* wordsBuff[513] = {};
        int words = parseCommand(buffer, wordsBuff);

        //skip empty commands
        if(words != 0) {

            if(strcmp(wordsBuff[0], "cd") == 0) {
                runCd(wordsBuff, words);

            }
            else if (strcmp(wordsBuff[0], "exit") == 0) {
                runExit(wordsBuff, words);

            }
            else {
                runCommand(wordsBuff, words);

            }

        }

        printf("\n");

    }

    return EXIT_SUCCESS;
}

/**
 * Parses the given line into separate word tokens, and puts them into the specified
 * char pointer array. Returns the number of tokens read.
 * @param line Raw input line
 * @param words Array of tokenized words
 * @return Number of words
 */
int parseCommand(char* line, char* words[]) {


    //start of command could be arbitrarily far from start of array,
    //step through array, looking for a whitespace. replace said whitespace
    //with a null, and set flag for next iteration. If flag is set and a nonwhitespace
    //character is found, set that character to the next wordidx position. If whitespace
    //is found while the flag is set, continue with the flag set to the next element

    int wordsidx = 0;
    bool whitespaceFlag = true; //initially set whitespace flag so that if the first item is
                                //non white space then the first element will be selected for
                                //the first words entry

    for(int i = 0; line[i] != '\0'; i++) {

        if(whitespaceFlag) {
            if(line[i] != ' ') {
                words[wordsidx] = line + i;
                wordsidx += 1;
                whitespaceFlag = false;
            }
            else {
                line[i] = '\0';
            }
        }
        else {
            if(line[i] == ' ') {
                whitespaceFlag = true;
                line[i] = '\0';
            }
        }

    }


    return wordsidx;
}

/**
 * Runs the build in exit command with the specified status.
 * @param words Input command
 * @param count Number of tokens in words
 */
void runExit(char* words[], int count) {

    jmp_buf env; //setup nonlocal jump back from integer parse function

    //jmp from parseint
    if(setjmp(env) == 0 && count == 2) {

        int status = parseInt(words[count - 1], env);
        exit(status);
    }
    else {
        printf("Invalid command\n");
    }



}

/**
 * Runs the built in cd command with the specified file path
 * @param words Input command
 * @param count Number of tokens in words
 */
void runCd(char* words[], int count) {

    //ensure 2 tokens
    if(count != 2) {
        printf("Invalid command\n");
    }
    else {

        int result = chdir(words[1]);

        if(result != 0) {
            printf("Invalid command\n");
        }

    }
}

/**
 * Runs any command using execvp, forks to child process to execute.
 * @param words Input command
 * @param count Number of tokens in words
 */
void runCommand(char* words[], int count) {

    pid_t pid = fork();

    if(pid == 0) { //child

        //make new array with null at end
        char* wordsNull[count + 1];

        for(int i = 0; i < count; i++) {
            wordsNull[i] = words[i];
        }

        wordsNull[count] = NULL;

        if(strcmp(wordsNull[count - 1], "&") == 0) {
            wordsNull[count - 1] = '\0';
        }

        //execute
        execvp(words[0], wordsNull);

        printf("Can't run command %s\n", words[0]);
        exit(EXIT_FAILURE);
    }
    else {//parent

        /*if(strcmp(words[count - 1], "&") == 0) {
            printf("[%d]\n", pid);
        }
        else {*/
            wait(NULL);
        //}
    }

}

/**
 * Parses an integer from the given input, if possible. Invalid input will return
 * to caller via nonlocal jump.
 * @param input Input string
 * @param env Nonlocal jump buffer
 * @return Parsed integer
 */
int parseInt(char* input, jmp_buf env) {

    int total = 0;

    for(char* current = input; *current != '\0'; current++) {
        if(*current >= '0' && *current <= '9') {
            total = total * 10;
            total += *current - '0';
        }
        else { //longjmp back to caller if nondigit values are present
            longjmp(env, 1);
        }
    }


    return total;
}
