/**
 * This program is a new stash that can execute commands
 * such as ls, cd, exit, and mkdir. It uses a fork call in the
 * command method to complete all other commands in execvp method.
 * @author Arnav Sharma
 * @file stash.c
 *
 */
#include <fcntl.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/wait.h>
#include <unistd.h>
#define LINELENGTH 1024
#define WORDLENGTH 513

/**
 * replaces the spaces with null terminators.
 * words points to commands.
 * @param line commands list
 * @param words pointer to those commands
 *
 */
int parseCommand(char *line, char *words[])
{
    bool checks = true;
    int wordfirstletter = 0;
    int amount = strlen(line);
    // iterates through the line by character
    for (int i = 0; i < amount; i++) {
        // change null terminator with a space
        if (line[i] == ' ' || line[i] == '\n') {
            line[i] = '\0';
            checks = true;
        } else {
            // if first character after a space
            if (checks == true) {
                // points words to the first characters
                words[wordfirstletter] = &line[i];
                wordfirstletter++;
            }
            checks = false;
        }
    }
    line[strlen(line)] = '\0';
    return wordfirstletter;
}

/**
 * exits wth given exit status
 * checks for right amount of arguments
 * @param words arrays pointing to commands
 * @param count int how many commands in line
 *
 */
void runExit(char *words[], int count)
{
    // convert string to int for command then stores
    int status = atoi(words[1]);
    // checks if correct amount of arguments
    if (count != 2) {
        printf("Invalid command\n");
    } else {
        exit(status);
    }
}

/**
 * runs cd using chdir with the given inputs
 * checks for right amount of arguments
 * @param words arrays pointing to commands
 * @param count int how many commands in line
 *
 */
void runCd(char *words[], int count)
{
    // checks if correct amount of arguments
    if (count != 2) {
        printf("Invalid command\n");
    } else {
        // use chdir when inputing
        int num = chdir(words[1]);
        // case errors
        if (num != 0) {
            printf("Invalid command\n");
        }
    }
}

/**
 * runs all other commands using execvp
 * uses fork to see if id returns and uses cases if execvp should be
 * called
 * @param words arrays pointing to commands
 * @param count int how many commands in line
 *
 */
void runCommand(char *words[], int count)
{
    // use the fork to make processes
    int newCmd = fork();
    // when not returned successfully
    if (newCmd != 0) {
        wait(NULL);
    }
    // when it is returned
    if (newCmd == 0) {
        char *last = NULL;
        words[count] = last;
        int num = 0;
        // runs execvp, change the words parameter if its not working
        num = execvp(words[0], words);
        // checking error
        if (num != 0) {
            printf("Invalid command\n");
        }
        exit(0);
    }
}

/**
 * main method chekcs for user input and responds
 * @param argc argument count
 * @param argv[] string in argument line
 * @return exit id
 *
 */
int main(int argc, char *argv[])
{
    // awlays will be true unless I find out if not later
    bool loop = true;
    // infinite loop until it is done
    while (loop == true) {
        char lineUser[LINELENGTH];
        // make a line of null terminators because it adds garbage values when
        // it is not
        char *word[WORDLENGTH] = {'\0'};
        // put together
        printf("stash> ");
        // allocate 1024 character array
        fgets(lineUser, 1024, stdin);
        // pointers for the words
        int amountWords = parseCommand(lineUser, word);
        // when its exit case
        if (strcmp("exit", word[0]) == 0) {
            // if (digitCalc(word[1]) == true) {
            runExit(word, amountWords);
            //}
        }
        // when its cd case
        else if (strcmp("cd", word[0]) == 0) {
            runCd(word, amountWords);
        }
        // other cases
        else {
            runCommand(word, amountWords);
        }
    }
}