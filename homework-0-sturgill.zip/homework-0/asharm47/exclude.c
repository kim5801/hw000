/**
 * This program reads the input file and outputs without
 * the excluded line using system calls, handles special case also
 * @author Arnav Sharma
 * @file exclude.c
 *
 */
#include <fcntl.h>
#include <string.h>
#include <unistd.h>

/**
 * Converts string to int (basically an atoi replacement)
 * @param num[] string of number
 * @return convertion into
 */
int string_to_int(char num[])
{
    int conversion = 0;
    int count = 0;
    while (num[count] != '\0') {
        conversion = conversion * 10 + (num[count] - '0');
        count++;
    }
    return conversion;
}

/**
 * main method goes through line by line and write
 * when the correct amount of '\n' is counted
 * @return exit
 */
int main(int argc, char *argv[])
{
    int fp_read = open(argv[1], O_RDONLY, 0600);
    int fp = open(argv[2], O_WRONLY | O_CREAT, 0600);
    if (argc > 4 || argc < 4 || string_to_int(argv[3]) < 1) {
        write(
            fp, "usage: exclude <input-file> <output-file> <line-number>",
            strlen("usage: exclude <input-file> <output-file> <line-number>"));
        _exit(1);
    }
    char buffer[64];
    if (fp_read < 0 || fp < 0) {
        write(
            fp, "usage: exclude <input-file> <output-file> <line-number>",
            strlen("usage: exclude <input-file> <output-file> <line-number>"));
        _exit(STDERR_FILENO);
    }
    int count = 0;
    int flag = 0;
    int reader = 0;
    while (flag == 0) {
        // if you can read in 64 bytes
        if ((reader = read(fp_read, buffer, 64)) > 0) {
            // you store the buffer with bytes
            for (int i = 0; i < reader; i++) {
                // needs special case for first line
                if (1 != string_to_int(argv[3])) {
                    if (buffer[i] == '\n') {
                        count++;
                    }
                    if (count + 1 != string_to_int(argv[3])) {
                        write(fp, &buffer[i], 1);
                    }
                } else {
                    if (buffer[i] == '\n') {
                        count++;
                    }
                    if (count == 1 && buffer[i] != '\n') {
                        write(fp, &buffer[i], 1);
                    }
                    if (count + 1 != 1 && count > 2) {
                        write(fp, &buffer[i], 1);
                    }
                }
            }

        } else {
            flag = 1;
        }
    }
    close(fp_read);
    close(fp);
    return 0;
}