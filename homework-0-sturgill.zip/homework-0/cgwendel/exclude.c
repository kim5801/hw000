#include <fcntl.h>
#include <unistd.h>

// Number of arguments required //
#define NUM_ARGS 4

// Maximum line size allowed //
#define LINE_SIZE 64

/**
 *  The main method is responsible for opening the input and output files, reading in 
 *  all of the lines from the input file, and writing all lines except for the one specified 
 *  to the output file
 **/
int main( int argc, char *argv[] ) {
    // Invalid argument message
    char invalid[] = "usage: exclude <input-file> <output-file> <line-number>\n";
    //char invalid2[] = "poop\n";
    
    // Check that the number of arguments passed in is correct
    if ( argc != NUM_ARGS ) {
        write( STDERR_FILENO, invalid, sizeof( invalid ) - 1 );
        _exit( 1 );
    }
    
    // Open input file, exit if unsuccessful
    int input = open( argv[ 1 ], O_RDONLY );
    if ( input == -1 ) {
        write( STDERR_FILENO, invalid, sizeof( invalid ) - 1 );
        close( input );
        _exit( 1 );
    }
    
    // Open output file
    int output = open( argv[ 2 ], O_WRONLY | O_CREAT | O_TRUNC, 0600 );
    if ( output == -1 ) {
        write( STDERR_FILENO, invalid, sizeof( invalid ) - 1 );
        close( input );
        close( output );
        _exit( 1 );
    }
    
    // Converting last argument to integer
    int noPrint = 0;
    int tenPow = 1;
    char c = *argv[ 3 ];
    int idx = 0;
    
    // Checking that there is at least one number on the argument line
    if ( c == ' ' || c == '\0' ) {
        write( STDERR_FILENO, invalid, sizeof( invalid ) - 1 );
        close( input );
        close( output );
        _exit( 1 );
    }
    
    // Ensuring that the last argument is a valid number
    while ( c != ' ' && c != '\0' ) {
        if ( c < '0' || c > '9' ) {
            write( STDERR_FILENO, invalid, sizeof( invalid ) - 1 );
            close( input );
            close( output );
            _exit( 1 );
        }
        idx++;
        c = *( argv[ 3 ] + idx );
    }
    idx--;
    
    // Converting the last argument from a string into an integer
    for ( int i = idx; i >= 0; i-- ) {
        noPrint += ( ( *( argv[ 3 ] + i ) - 48 ) * tenPow );
        tenPow *= 10;
    }
    
    // Read in bytes from input file
    char line[] = "";
    int bytes = read( input, line, LINE_SIZE );
    int lines = 1;
    
    // Output each byte to file
    while ( bytes > 0 ) {
        for ( int i = 0; i < bytes; i++ ) {
            if ( line[ i ] == '\n' ) {
                lines++;
            }
            if ( lines != noPrint ) {
                write( output, line + i, 1 );
            }
        }
        bytes = read( input, line, LINE_SIZE );
    }
    
    close( input );
    close( output ); 
    return 0;
}
