#include <unistd.h>
#include <sys/wait.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

// Maximum size the line can be //
#define ARRAY_SIZE 1025

/**
 *  The readLine function takes in a file pointer as its parameter and reads the first 
 *  line before a newline character is found. It then returns a pointer to the beginning 
 *  character of the line, and each character can be accessed with pointer arithmetic 
 *
 *  @param fp the file pointer to read from
 *  @return a pointer to the first character in the line
 **/
char *readLine( FILE *fp )
{
    printf("stash>");
    char c;
    int i = 0;
    
    // Checking that it isn't an empty file
    c = fgetc( fp );
    if ( c == EOF || c == '\n' ) {
        return NULL;
    }

    char *str = malloc( ARRAY_SIZE * sizeof( char ) ); 

    // Reads through until a newline character or the end of file is reached
    while ( ( c != EOF ) && ( c != '\n' ) ) {
        if ( c == '\0' ) {
            c = ' ';
        } 
        str[ i ] = c;
        c = fgetc( fp );
        i++;
    }
    
    if ( strlen( str ) == 0 ) {
        free( str );
        return NULL;
    }
    str[ i ] = '\0';
    return str;
}

/**
 *  The parseCommand function takes in the line to be separated, and parses each 
 *  individual word. It then adds each of these words to the array of pointers that is also 
 *  passed in, each pointer pointing at the beginning of each word
 *  
 *  @param line the line to parse
 *  @param words the array to add words to
 *  @return the number of words found in the line
 **/
int parseCommand( char *line, char *words[] ) {
    char c;
    int charIdx = 0;
    int nullIdx = 0;
    int wordIdx = 0;
    
    if ( !line ) {
        return 0;
    }
    
    c = line[ charIdx ];
    
    words[ wordIdx ] = line;
    
    /* Goes through the line and changes each item in the array of pointers to point to 
    the beginning of each word. Adds in a null terminator after each word to separate 
    them */
    while ( c != EOF && c != '\n' && c != '\0' ) {
        if ( isspace( c ) ) {
            words[ wordIdx ][ nullIdx ] = '\0';
            wordIdx++;
            while ( isspace( c ) ) {
                charIdx++;
                c = line[ charIdx ];
            }
            words[ wordIdx ] = line + charIdx;
            nullIdx = -1;
            charIdx--;
        }
        charIdx++;
        nullIdx++;
        c = line[ charIdx ];
    }
    words[ wordIdx ][ charIdx ] = '\0';
    wordIdx++;
    return wordIdx;
}

/**
 *  Runs the exit command for the user with the specified arguments 
 *  
 *  @param words the array to read arguments from
 *  @param count the number of arguments on the line
 **/
void runExit( char *words[], int count ) {
    if ( count == 1 ) {
        exit( 0 );
    } else if ( count > 2 || !isdigit( *words[ 1 ] ) ) {
        printf("Invalid command\n");
    } else {
        exit( atoi( words[ 1 ] ) );
    }
}

/**
 *  Runs the change directory system call using the arguments provided by the user
 *
 *  @param words the array to read arguments from
 *  @param count the number of arguments on the line
 **/
void runCd( char *words[], int count ) {
    if ( count < 2 ) {
        printf("Invalid command\n");
    }
    int val = chdir( *( words + 1 ) );
    if ( val == -1 ) {
        printf("Invalid command\n");
    }
}

/**
 *  Runs any command other than exit or cd through system calls using arguments provided 
 *  by the user
 *
 *  @param words the array to read arguments from
 *  @param count the number of arguments on the line
 **/
void runCommand( char *words[], int count ) {
    words[ count ] = NULL;
    if ( fork() == 0 ) {
        int result = execvp( words[ 0 ], words );
        if ( result == -1 ) {
            printf( "Can’t run command %s\n", words[ 0 ] );
            exit( EXIT_FAILURE );
        } else {
            exit( EXIT_SUCCESS );
        }
    }
    wait( NULL );
}

/**
 *  Runs the driver for the user command line, prompting the user for new commands and 
 *  running the appropriate function depending on user input
 **/
int main( int argc, char *argv[] ) {
    int count = 0;
    char *line;
    char **words = malloc( sizeof( char * ) * 513 );

    while ( count >= 0 ) {
        line = readLine( stdin );
        count = parseCommand( line, words );
        if ( count == 0 ) {
            continue;
        } else if ( strcmp( words[ 0 ], "cd" ) == 0 ) {
            runCd( words, count );
        } else if ( strcmp( words[ 0 ], "exit" ) == 0 ) {
            runExit( words, count );
        } else {
            runCommand( words, count );
        }
    }
    return 0;
}
