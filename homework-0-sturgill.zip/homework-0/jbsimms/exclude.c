#include <fcntl.h>
#include <unistd.h>

//Value used to convert ascii code to digit
#define ASCII 48
//Line number index in array of arguments
#define LNI 3
//How many bytes to read at a time
#define CHUNK 64

//Main function
int main ( int argc, char *argv[] ) {

	//Error check
	if ( argc != 4 ) {
		write( STDERR_FILENO, "usage: exclude <input-file> <output-file> <line-number>\n", 56 );
		_exit( 1 );
	}

	//Converts last command-line argument from a string to an int
	int lineToDel = 0;
	for ( int i = 0; argv[LNI][i] != '\0'; i++ ) {

		int digit = argv[LNI][i] - ASCII;

		//Error check
		if ( !(digit >= 0 && digit <= 9) ) {
			write( STDERR_FILENO, "usage: exclude <input-file> <output-file> <line-number>\n", 56 );
			_exit( 1 );
		}

		lineToDel *= 10;
		lineToDel += digit;
	}

	//Opens files for IO
	int inputID = open( argv[1], O_RDONLY );
	int outputID = open( argv[2],  O_WRONLY );

	//Error check
	if ( (inputID == -1) || (outputID == -1) ) {
		write( STDERR_FILENO, "usage: exclude <input-file> <output-file> <line-number>\n", 56 );
		_exit( 1 );
	}

	//Reads input and writes to output excluding specified line
	int lines = 0;
	int bytesRead = -1;
	char bytes[CHUNK];
	while ( bytesRead != 0 ) {
		bytesRead = read( inputID, bytes, CHUNK );

		//Iterates through the chunk of bytes read
		for ( int i = 0; i < bytesRead; i++ ) {

			//Keeps track of the line
			if (bytes[i] == '\n')
				lines++;

			//Write bytes to output
			if ( lines != lineToDel - 1 ) {
				write( outputID, bytes + i, 1 );
			}
		}
	}

	//Closes files
	close( inputID );
	close( outputID );
}
