#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/wait.h>

#define MAX_CHARS 1024
#define MAX_WORDS 513
#define ASCII 48

//Parses a string into an int
int parseInt( char string[] ) {

	int result = 0;
	for ( int i = 0; string[i] != '\0'; i++ ) {
		int digit = string[i] - ASCII;

		//Error check
		if ( !(digit >= 0 && digit <= 9) )
			return -1;

		result *= 10;
		result += digit;
	}

	return result;
}

//Exit command
void runExit( char *words[], int count )
{
	int status = parseInt( words[1] );

	//Error checks, runs if all good
	if ( count != 2 || status == -1 )
		printf( "Invalid command\n" );
	else
		exit( status );
}

//Cd command
void runCd( char *words[], int count )
{
	//Runs command and error checks all in one :D
	if ( count != 2 || chdir( words[1] ) == -1 )
		printf( "Invalid command\n" );
}

//Creates a child to call execvp()
void runCommand( char *words[], int count )
{
	//Gives birth
	int id = fork();

	//Splits instructions for child and parent
	if ( id == 0 ) {
		words[count] = NULL;
		if ( execvp( words[0], words ) == -1 ) {
			printf( "Can't run command %s\n", words[0] );
			exit(0);
		}
		else
			exit(0);
	} else
		wait( NULL );
}

//This function takes a command line and breaks it into
//null terminated words. Returns the word count.
int parseCommand( char *line, char *words[] )
{
	int wordCount = 0;
	words[0] = &line[0];
	if ( strcmp( words[0], "" ) != 0 )
		wordCount++;
	
	//Loops through chars of line
	for ( int i = 0; line[i] != '\0'; i++ ) {

		//At end of word, null terminates and adds to array
		if ( line[i] == ' ' ) {
			line[i] = '\0';
			words[wordCount] = &line[i + 1];
			wordCount++;
		}
	}

	return wordCount;
}

//Main function
int main()
{
	//Loop for each command line
	while ( 1 == 1 ) {
		printf( "stash> " );

		//Reads line
		char line[MAX_CHARS];
		int chars = 0;
		for ( int c = getchar(); c != '\n'; c = getchar() ) {
			line[chars] = c;
			chars++;
		}
		line[chars] = '\0';

		char *words[MAX_WORDS];
		int wordCount = parseCommand( line, words );

		//Finds the right command and calls the
		//function for it
		if ( strcmp( words[0], "cd" ) == 0 )
			runCd( words, wordCount );
		else if ( strcmp( words[0], "exit" ) == 0 )
			runExit( words, wordCount );
		else if ( strcmp( words[0], "" ) == 0 ) {}
		else
			runCommand( words, wordCount );

	}
}
